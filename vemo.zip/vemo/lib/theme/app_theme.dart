import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// 0-Blur Hard Shadow tokens for low-end GPU fill-rate optimization & tactile retro styling.
class VemoShadows {
  static const BoxShadow tactileSmall = BoxShadow(
    color: Color(0xFF000000),
    offset: Offset(0, 2),
    blurRadius: 0,
    spreadRadius: 0,
  );

  static const BoxShadow tactileCard = BoxShadow(
    color: Color(0xFF000000),
    offset: Offset(3, 3),
    blurRadius: 0,
    spreadRadius: 0,
  );

  static const BoxShadow tactileCardActive = BoxShadow(
    color: Color(0xFF000000),
    offset: Offset(5, 5),
    blurRadius: 0,
    spreadRadius: 0,
  );

  static const BoxShadow tactilePressed = BoxShadow(
    color: Color(0xFF000000),
    offset: Offset(1, 1),
    blurRadius: 0,
    spreadRadius: 0,
  );

  static const BoxShadow tactileModal = BoxShadow(
    color: Color(0xFF000000),
    offset: Offset(0, 8),
    blurRadius: 0,
    spreadRadius: 0,
  );
}

class AppTheme {
  // ─── Chassis Base & Surface Tokens (Dark OLED Neutral) ───────────────────
  static const Color chassisVoid = Color(0xFF0A0A10);
  static const Color chassisMatte = Color(0xFF0D0E15);
  static const Color chassisElevated = Color(0xFF141420);
  static const Color chassisCard = Color(0xFF1E1E2E);
  static const Color chassisBorderLight = Color(0xFF2D3045);
  static const Color chassisBorderDark = Color(0xFF08090D);

  // Aliases for backwards compatibility
  static const Color backgroundDeep = chassisVoid;
  static const Color backgroundCard = chassisCard;
  static const Color backgroundElevated = chassisElevated;

  // ─── Signature Brand Accent Tokens ───────────────────────────────────────
  static const Color accentAmber = Color(0xFFF5A623);
  static const Color accentAmberGlow = Color(0xFFFFBE4D);
  static const Color accentAmberPressed = Color(0xFFD48810);
  static const Color accentAmberDim = Color(0xFFB07A00);
  static const Color accentTeal = Color(0xFF00E5FF);
  static const Color accentTealDim = Color(0xFF00B4D8);

  // ─── Status & Feedback Tokens ────────────────────────────────────────────
  static const Color ledPowerOn = Color(0xFF00E676);
  static const Color ledSaveActive = Color(0xFFFFD600);
  static const Color ledAlertDanger = Color(0xFFFF1744);

  // ─── Neutral Text & Content Tokens ───────────────────────────────────────
  static const Color textPrimary = Color(0xFFFFFFFF);
  static const Color textSecondary = Color(0xFFA0A0B2);
  static const Color textMuted = Color(0xFF505064);

  // ─── Dual-Border Bevel Stroke Tokens ─────────────────────────────────────
  static const Color borderHard = Color(0xFF333348);
  static const Color borderBevelTop = Color(0xFF3A3A52);
  static const Color borderBevelBottom = Color(0xFF050508);

  // ─── Platform Signature Accent Tokens ────────────────────────────────────
  static const Color badgeNES = Color(0xFFFF5252);
  static const Color badgeSNES = Color(0xFF7C4DFF);
  static const Color badgeGBA = Color(0xFFAB47BC);
  static const Color badgeGenesis = Color(0xFF26A69A);
  static const Color badgeGB = Color(0xFF66BB6A);
  static const Color badgeArcade = Color(0xFFFFA726);

  // ─── Retro Typography Helpers ──────────────────────────────────────────
  static TextStyle get logoStyle => GoogleFonts.pressStart2p(
    color: accentAmber,
    fontSize: 16,
    fontWeight: FontWeight.w400,
    letterSpacing: 1.0,
  );

  static TextStyle get pixelBadgeStyle => GoogleFonts.pressStart2p(
    color: textPrimary,
    fontSize: 8,
    letterSpacing: 0.5,
  );

  static ThemeData get darkTheme {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: chassisVoid,
      colorScheme: const ColorScheme.dark(
        primary: accentAmber,
        secondary: accentAmberDim,
        surface: chassisElevated,
        onPrimary: chassisVoid,
        onSecondary: textPrimary,
        onSurface: textPrimary,
      ),
      textTheme: GoogleFonts.spaceGroteskTextTheme(
        ThemeData.dark().textTheme,
      ).copyWith(
        displayLarge: GoogleFonts.spaceGrotesk(
          color: textPrimary,
          fontSize: 24,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.5,
        ),
        headlineLarge: GoogleFonts.spaceGrotesk(
          color: textPrimary,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
        headlineMedium: GoogleFonts.spaceGrotesk(
          color: textPrimary,
          fontSize: 16,
          fontWeight: FontWeight.w600,
        ),
        titleLarge: GoogleFonts.spaceGrotesk(
          color: textPrimary,
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        bodyMedium: GoogleFonts.spaceGrotesk(
          color: textSecondary,
          fontSize: 13,
          height: 1.4,
        ),
        bodySmall: GoogleFonts.spaceGrotesk(
          color: textMuted,
          fontSize: 11,
          height: 1.3,
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: chassisVoid,
        elevation: 0,
        titleTextStyle: GoogleFonts.spaceGrotesk(
          color: textPrimary,
          fontSize: 18,
          fontWeight: FontWeight.w700,
          letterSpacing: 0.5,
        ),
        iconTheme: const IconThemeData(color: accentAmber),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: accentAmber,
          foregroundColor: chassisVoid,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          textStyle: GoogleFonts.spaceGrotesk(
            fontWeight: FontWeight.w700,
            fontSize: 13,
            letterSpacing: 0.5,
          ),
        ),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: chassisCard,
        selectedColor: accentAmber.withValues(alpha: 0.18),
        labelStyle: GoogleFonts.spaceGrotesk(
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
        side: const BorderSide(color: borderHard, width: 1.5),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: CupertinoPageTransitionsBuilder(),
        },
      ),
    );
  }

  static Color platformColor(String platform) {
    switch (platform.toUpperCase()) {
      case 'GBA':
        return badgeGBA;
      case 'SNES':
        return badgeSNES;
      case 'NES':
        return badgeNES;
      case 'GENESIS':
      case 'MD':
        return badgeGenesis;
      case 'GB':
      case 'GBC':
        return badgeGB;
      case 'PCE':
      case 'PCENGINE':
        return const Color(0xFFFF7043);
      case 'ARCADE':
      case 'MAME':
      case 'NEOGEO':
      case 'CPS':
        return badgeArcade;
      default:
        return accentAmber;
    }
  }
}
