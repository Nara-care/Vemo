import 'dart:convert';

/// Exception thrown when a picked ROM has an unsupported format or invalid header.
class UnsupportedRomException implements Exception {
  final String message;
  const UnsupportedRomException(this.message);
  @override
  String toString() => message;
}

/// Represents a single game in the Vemo user library.
class Game {
  final String id;
  final String title;
  final String platform; // "GBA" | "SNES" | "NES" | "GENESIS"
  final String core;     // Libretro core identifier (fceumm, mgba, snes9x, genesis_plus_gx)
  final String romPath;  // legacy — empty for user-added games
  final String boxartPath; // empty for user-added games
  final String description;
  final String tips;
  final int romSizeMB;
  final String aspectRatio; // "4/3" for most, "3/2" for GBA
  final String? localRomPath; // absolute path to ROM file in app storage

  const Game({
    required this.id,
    required this.title,
    required this.platform,
    required this.core,
    this.romPath = '',
    this.boxartPath = '',
    this.description = '',
    this.tips = '',
    this.romSizeMB = 0,
    this.aspectRatio = '4/3',
    this.localRomPath,
  });

  /// Maps legacy or short platform core names to valid Libretro core identifiers.
  static String normalizeCore(String core) {
    switch (core.toLowerCase()) {
      case 'nes':
      case 'fceux':
        return 'fceumm';
      case 'gba':
      case 'gbc':
      case 'gb':
        return 'mgba';
      case 'snes':
      case 'snes9x2010':
        return 'snes9x';
      case 'genesis':
      case 'segamd':
      case 'sega_md':
      case 'md':
      case 'sms':
      case 'gg':
        return 'genesis_plus_gx';
      case 'pce':
      case 'pce_fast':
      case 'pcengine':
        return 'beetle_pce_fast';
      case 'ps1':
      case 'psx':
      case 'playstation':
      case 'duckstation':
      case 'swanstation':
      case 'pcsx_rearmed':
      case 'pcsx':
      case 'beetle_psx':
      case 'beetle_psx_hw':
        return 'pcsx_rearmed';
      case 'n64':
      case 'mupen64plus':
      case 'mupen64plus_next':
        return 'mupen64plus_next';
      case 'psp':
      case 'ppsspp':
        return 'ppsspp';
      case 'arcade':
      case 'mame':
      case 'neogeo':
      case 'cps':
        return 'fbneo';
      default:
        return core;
    }
  }

  /// Create a Game from a user-picked ROM file with automatic platform & core detection.
  factory Game.fromRomFile({
    required String id,
    required String title,
    required String filePath,
    required int fileSizeBytes,
    String? originalFileName,
  }) {
    final fileNameToTest = originalFileName ?? filePath;
    final ext = fileNameToTest.contains('.')
        ? fileNameToTest.split('.').last.toLowerCase()
        : '';
    String? platform;
    String? core;
    String aspectRatio = '4/3';

    if (ext == 'sfc' || ext == 'smc' || ext == 'fig' || ext == 'swc') {
      platform = 'SNES';
      core = 'snes9x';
      aspectRatio = '4/3';
    } else if (ext == 'nes' || ext == 'fds' || ext == 'unf') {
      platform = 'NES';
      core = 'fceumm';
      aspectRatio = '4/3';
    } else if (ext == 'md' || ext == 'gen' || ext == 'smd') {
      platform = 'GENESIS';
      core = 'genesis_plus_gx';
      aspectRatio = '4/3';
    } else if (ext == 'sms' || ext == 'gg' || ext == 'sg') {
      platform = 'GENESIS';
      core = 'genesis_plus_gx';
      aspectRatio = '4/3';
    } else if (ext == 'gba') {
      platform = 'GBA';
      core = 'mgba';
      aspectRatio = '3/2';
    } else if (ext == 'gb' || ext == 'gbc') {
      platform = 'GB';
      core = 'mgba';
      aspectRatio = '10/9';
    } else if (ext == 'chd' || ext == 'cue' || ext == 'pbp' || ext == 'iso' || ext == 'img') {
      platform = 'PS1';
      core = 'pcsx_rearmed';
      aspectRatio = '4/3';
    } else if (ext == 'bin') {
      // .bin could be Genesis or PS1 CD track - default to PS1 if > 10MB, otherwise Genesis
      if (fileSizeBytes > 10 * 1024 * 1024) {
        platform = 'PS1';
        core = 'pcsx_rearmed';
        aspectRatio = '4/3';
      } else {
        platform = 'GENESIS';
        core = 'genesis_plus_gx';
        aspectRatio = '4/3';
      }
    } else if (ext == 'z64' || ext == 'n64' || ext == 'v64') {
      platform = 'N64';
      core = 'mupen64plus_next';
      aspectRatio = '4/3';
    }

    if (platform == null || core == null) {
      throw UnsupportedRomException(
        ext.isNotEmpty
            ? 'Format file .$ext tidak dikenali sebagai format ROM konsol yang valid.'
            : 'File tidak memiliki ekstensi ROM yang valid.',
      );
    }

    return Game(
      id: id,
      title: title,
      platform: platform,
      core: core,
      romSizeMB: (fileSizeBytes / (1024 * 1024)).ceil(),
      aspectRatio: aspectRatio,
      localRomPath: filePath,
    );
  }

  /// Creates a copy of this game with specified fields replaced
  Game copyWith({
    String? id,
    String? title,
    String? platform,
    String? core,
    String? romPath,
    String? boxartPath,
    String? description,
    String? tips,
    int? romSizeMB,
    String? aspectRatio,
    String? localRomPath,
  }) {
    return Game(
      id: id ?? this.id,
      title: title ?? this.title,
      platform: platform ?? this.platform,
      core: core ?? this.core,
      romPath: romPath ?? this.romPath,
      boxartPath: boxartPath ?? this.boxartPath,
      description: description ?? this.description,
      tips: tips ?? this.tips,
      romSizeMB: romSizeMB ?? this.romSizeMB,
      aspectRatio: aspectRatio ?? this.aspectRatio,
      localRomPath: localRomPath ?? this.localRomPath,
    );
  }

  /// Serialize to JSON for SharedPreferences storage.
  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'platform': platform,
    'core': core,
    'romPath': romPath,
    'boxartPath': boxartPath,
    'description': description,
    'tips': tips,
    'romSizeMB': romSizeMB,
    'aspectRatio': aspectRatio,
    'localRomPath': localRomPath,
  };

  /// Deserialize from JSON with core auto-normalization.
  factory Game.fromJson(Map<String, dynamic> json) => Game(
    id: json['id'] as String,
    title: json['title'] as String,
    platform: json['platform'] as String,
    core: normalizeCore(json['core'] as String),
    romPath: (json['romPath'] as String?) ?? '',
    boxartPath: (json['boxartPath'] as String?) ?? '',
    description: (json['description'] as String?) ?? '',
    tips: (json['tips'] as String?) ?? '',
    romSizeMB: (json['romSizeMB'] as int?) ?? 0,
    aspectRatio: (json['aspectRatio'] as String?) ?? '4/3',
    localRomPath: json['localRomPath'] as String?,
  );

  static String encodeList(List<Game> games) =>
      jsonEncode(games.map((g) => g.toJson()).toList());

  static List<Game> decodeList(String jsonStr) {
    final list = jsonDecode(jsonStr) as List<dynamic>;
    return list.map((e) => Game.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// Returns the parsed floating point aspect ratio for rendering viewport
  double get numericAspectRatio {
    if (aspectRatio.contains('/')) {
      final parts = aspectRatio.split('/');
      if (parts.length == 2) {
        final num = double.tryParse(parts[0]);
        final den = double.tryParse(parts[1]);
        if (num != null && den != null && den != 0) {
          return num / den;
        }
      }
    }
    // Fallbacks based on platform
    switch (platform.toUpperCase()) {
      case 'GB':
      case 'GBC':
        return 10.0 / 9.0;
      case 'GBA':
        return 3.0 / 2.0;
      case 'SNES':
      case 'NES':
      case 'GENESIS':
      case 'PCE':
      case 'ARCADE':
      default:
        return 4.0 / 3.0;
    }
  }

  /// Returns true if this game has a ROM file ready to play (local file or bundled asset).
  bool get isBundled => romPath.isNotEmpty;

  /// Returns true if this game is ready to play.
  bool get hasRom => isBundled || (localRomPath != null && localRomPath!.isNotEmpty);

  /// Returns asset path for ROM
  String get romAssetPath => 'assets/$romPath';

  /// Returns asset path for boxart
  String get boxartAssetPath => 'assets/$boxartPath';
}



