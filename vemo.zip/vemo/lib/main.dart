import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme/app_theme.dart';
import 'screens/library_screen.dart';
import 'services/audio_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Allow all orientations: Handheld Game Boy in portrait & Widescreen in landscape
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);

  // Full immersive mode — no status/nav bars
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  FlutterError.onError = (FlutterErrorDetails details) {
    debugPrint('FLUTTER_ERROR_CAUGHT: ${details.exceptionAsString()}');
    debugPrint('${details.stack}');
  };

  ErrorWidget.builder = (FlutterErrorDetails details) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Text(
            'ERROR: ${details.exceptionAsString()}\n\n${details.stack}',
            style: const TextStyle(color: Colors.redAccent, fontSize: 11),
          ),
        ),
      ),
    );
  };

  // Launch UI immediately
  runApp(const VemoApp());

  // Initialize audio non-blocking after UI launch
  Future.microtask(() async {
    try {
      await AudioService().init();
      AudioService().playLobbyBgm();
    } catch (e) {
      debugPrint('[Main] AudioService error: $e');
    }
  });
}

class VemoApp extends StatefulWidget {
  const VemoApp({super.key});

  @override
  State<VemoApp> createState() => _VemoAppState();
}

class _VemoAppState extends State<VemoApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    AudioService().dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    switch (state) {
      case AppLifecycleState.paused:
      case AppLifecycleState.inactive:
      case AppLifecycleState.hidden:
        // App is minimized or user pressed Home button -> Silence audio immediately!
        AudioService().pauseLobbyBgm(dueToBackground: true);
        break;
      case AppLifecycleState.resumed:
        // App is back in foreground -> Resume audio if we are in library
        AudioService().onAppForeground();
        break;
      case AppLifecycleState.detached:
        AudioService().dispose();
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vemo',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.darkTheme,
      home: const LibraryScreen(),
    );
  }
}
