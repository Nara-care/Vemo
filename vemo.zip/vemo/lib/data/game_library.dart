import '../models/game.dart';

/// Platform filter labels used in the library screen (matches active bundled Libretro cores).
const List<String> kPlatformFilters = ['SEMUA', 'PS1', 'GBA', 'SNES', 'NES', 'GENESIS', 'GB'];

/// Default bundled games included with Vemo.
const List<Game> kDefaultBundledGames = [
  Game(
    id: 'super_mario_bros_2',
    title: 'Super Mario Bros. 2',
    platform: 'NES',
    core: 'fceumm',
    romPath: 'roms/nes/super_mario_bros_2.nes',
    boxartPath: 'boxart/super_mario_bros_2.png',
    description: 'Petualangan legendaris Mario & kawan-kawan di negeri Subcon.',
    tips: 'Tekan B untuk berlari dan mencabut tanaman/musuh!',
    romSizeMB: 1,
    aspectRatio: '4/3',
  ),
  Game(
    id: 'kirby_adventure',
    title: "Kirby's Adventure",
    platform: 'NES',
    core: 'fceumm',
    romPath: 'roms/nes/kirby_adventure.nes',
    boxartPath: 'boxart/kirby_adventure.png',
    description: 'Petualangan imut Kirby menelan musuh dan menyalin kekuatan.',
    tips: 'Tekan ATAS untuk terbang melayang di udara!',
    romSizeMB: 1,
    aspectRatio: '4/3',
  ),
  Game(
    id: 'crash_bandicoot_woc',
    title: 'Crash Bandicoot: The Wrath of Cortex',
    platform: 'GBA',
    core: 'mgba',
    romPath: 'roms/gba/crash_bandicoot_woc.gba',
    boxartPath: 'boxart/crash_bandicoot_woc.png',
    description: 'Petualangan platformer Crash melintasi dimensi Cortex.',
    tips: 'Gunakan tombol B untuk berputar (spin attack) mengalahkan musuh!',
    romSizeMB: 8,
    aspectRatio: '3/2',
  ),
];

