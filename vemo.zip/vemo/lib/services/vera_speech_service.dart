import 'dart:math' as math;
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';

/// 🔊 Retro 8-Bit Speech Sound & Easter Egg Session Manager for Vera
class VeraSpeechService {
  static final VeraSpeechService _instance = VeraSpeechService._internal();
  factory VeraSpeechService() => _instance;
  VeraSpeechService._internal();

  /// Session flag: Vera's monologue plays only 1 time per app session (until app closed)
  static bool hasPlayedEasterEggThisSession = false;

  final AudioPlayer _blipPlayer = AudioPlayer();
  final List<Uint8List> _cachedBlips = [];
  final math.Random _random = math.Random();
  bool _isInitialized = false;

  Future<void> init() async {
    if (_isInitialized) return;
    _isInitialized = true;

    try {
      // Pre-generate 4 subtle pitch variations (Undertale-style voice blips: 300Hz - 360Hz)
      const pitches = [300.0, 320.0, 340.0, 360.0];
      for (final freq in pitches) {
        _cachedBlips.add(_generatePcmWav(frequency: freq, durationMs: 42.0, volume: 0.22));
      }
      await _blipPlayer.setVolume(0.25);
    } catch (e) {
      debugPrint('[VeraSpeechService] Init error: $e');
    }
  }

  /// Play one retro speech blip in sync with character typing
  Future<void> playSpeechBlip() async {
    try {
      if (!_isInitialized) await init();
      if (_cachedBlips.isEmpty) return;

      final randomIndex = _random.nextInt(_cachedBlips.length);
      final wavData = _cachedBlips[randomIndex];
      await _blipPlayer.stop();
      await _blipPlayer.play(BytesSource(wavData));
    } catch (e) {
      // Audio blip non-blocking failure shouldn't disrupt UI
    }
  }

  /// Synthesizes an 8-bit square/sine hybrid retro PCM WAV byte buffer
  static Uint8List _generatePcmWav({
    required double frequency,
    required double durationMs,
    required double volume,
  }) {
    const int sampleRate = 22050;
    final int numSamples = (sampleRate * (durationMs / 1000.0)).round();
    final int dataSize = numSamples * 2; // 16-bit mono
    final int fileSize = 36 + dataSize;

    final ByteData byteData = ByteData(44 + dataSize);

    // RIFF chunk
    byteData.setUint8(0, 0x52); // R
    byteData.setUint8(1, 0x49); // I
    byteData.setUint8(2, 0x46); // F
    byteData.setUint8(3, 0x46); // F
    byteData.setUint32(4, fileSize, Endian.little);
    byteData.setUint8(8, 0x57);  // W
    byteData.setUint8(9, 0x41);  // A
    byteData.setUint8(10, 0x56); // V
    byteData.setUint8(11, 0x45); // E

    // fmt subchunk
    byteData.setUint8(12, 0x66); // f
    byteData.setUint8(13, 0x6D); // m
    byteData.setUint8(14, 0x74); // t
    byteData.setUint8(15, 0x20); // ' '
    byteData.setUint32(16, 16, Endian.little); // Subchunk size (16 for PCM)
    byteData.setUint16(20, 1, Endian.little);  // Format: PCM
    byteData.setUint16(22, 1, Endian.little);  // Channels: 1 (mono)
    byteData.setUint32(24, sampleRate, Endian.little);
    byteData.setUint32(28, sampleRate * 2, Endian.little); // Byte rate
    byteData.setUint16(32, 2, Endian.little);  // Block align
    byteData.setUint16(34, 16, Endian.little); // Bits per sample: 16

    // data subchunk
    byteData.setUint8(36, 0x64); // d
    byteData.setUint8(37, 0x61); // a
    byteData.setUint8(38, 0x74); // t
    byteData.setUint8(39, 0x61); // a
    byteData.setUint32(40, dataSize, Endian.little);

    // Write samples with retro hybrid waveform & exponential envelope
    int offset = 44;
    for (int i = 0; i < numSamples; i++) {
      final double t = i / sampleRate;
      final double sine = math.sin(2 * math.pi * frequency * t);
      final double square = sine > 0 ? 0.75 : -0.75;
      final double hybrid = (sine * 0.55 + square * 0.45);

      // Fast exponential envelope to avoid clicks
      final double env = math.exp(-i / (numSamples * 0.38));
      final double sampleValue = (hybrid * env * volume).clamp(-1.0, 1.0);
      final int sampleInt16 = (sampleValue * 32767).round();

      byteData.setInt16(offset, sampleInt16, Endian.little);
      offset += 2;
    }

    return byteData.buffer.asUint8List();
  }

  void dispose() {
    _blipPlayer.dispose();
  }
}
