import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'native_emulator_service.dart';

class SaveSlotInfo {
  final int slot;
  final bool exists;
  final DateTime? savedAt;

  const SaveSlotInfo({
    required this.slot,
    required this.exists,
    this.savedAt,
  });
}

/// Manages persistent save states and SRAM battery files for Libretro cores.
/// Save states: getApplicationDocumentsDirectory()/saves/{gameId}/slot{n}.state
/// SRAM battery: getApplicationDocumentsDirectory()/sram/{gameId}.srm
class SaveService {
  static final SaveService _instance = SaveService._internal();
  factory SaveService() => _instance;
  SaveService._internal();

  Future<Directory> _getSavesDir(String gameId) async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}/saves/$gameId');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  /// Get absolute path for a save state file
  Future<String> getSaveStateFilePath(String gameId, int slot) async {
    final dir = await _getSavesDir(gameId);
    return '${dir.path}/slot$slot.state';
  }

  /// Save native state from the active Libretro core
  Future<bool> saveNativeState(String gameId, int slot) async {
    final path = await getSaveStateFilePath(gameId, slot);
    final success = await NativeEmulatorService().saveState(path);
    if (success) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        'save_${gameId}_slot${slot}_time',
        DateTime.now().toIso8601String(),
      );
    }
    return success;
  }

  /// Load native state into the active Libretro core
  Future<bool> loadNativeState(String gameId, int slot) async {
    final path = await getSaveStateFilePath(gameId, slot);
    return await NativeEmulatorService().loadState(path);
  }

  /// Get metadata for all 3 slots of a game
  Future<List<SaveSlotInfo>> getSaveSlots(String gameId) async {
    final prefs = await SharedPreferences.getInstance();
    final dir = await _getSavesDir(gameId);
    final List<SaveSlotInfo> slots = [];

    for (int i = 1; i <= 3; i++) {
      final file = File('${dir.path}/slot$i.state');
      final exists = await file.exists();
      DateTime? savedAt;
      if (exists) {
        final timeStr = prefs.getString('save_${gameId}_slot${i}_time');
        if (timeStr != null) {
          savedAt = DateTime.tryParse(timeStr);
        }
      }
      slots.add(SaveSlotInfo(slot: i, exists: exists, savedAt: savedAt));
    }
    return slots;
  }

  /// Check if any save exists for a game (for "Continue" CTA)
  Future<bool> hasAnySave(String gameId) async {
    final slots = await getSaveSlots(gameId);
    return slots.any((s) => s.exists);
  }

  /// Get the most recent save slot number, or null
  Future<int?> getMostRecentSlot(String gameId) async {
    final slots = await getSaveSlots(gameId);
    final existing = slots.where((s) => s.exists && s.savedAt != null).toList();
    if (existing.isEmpty) return null;
    existing.sort((a, b) => b.savedAt!.compareTo(a.savedAt!));
    return existing.first.slot;
  }

  /// Delete all save states and SRM battery files for a deleted game
  Future<void> deleteGameSaves(String gameId) async {
    try {
      final dir = await _getSavesDir(gameId);
      if (await dir.exists()) {
        await dir.delete(recursive: true);
      }
      final docs = await getApplicationDocumentsDirectory();
      final srmFile = File('${docs.path}/saves/$gameId.srm');
      if (await srmFile.exists()) {
        await srmFile.delete();
      }
      final prefs = await SharedPreferences.getInstance();
      for (int i = 1; i <= 3; i++) {
        await prefs.remove('save_${gameId}_slot${i}_time');
      }
    } catch (_) {}
  }

  /// Store last played game ID
  Future<void> setLastPlayed(String gameId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('last_played_game', gameId);
  }

  Future<String?> getLastPlayed() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('last_played_game');
  }
}
