import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import 'package:ve_ne/ve_ne.dart';
import '../models/game.dart';

/// Key codes for retro controller mapping (Full 16 buttons Libretro Joypad)
class RetroKey {
  static const int b = 0;
  static const int y = 1;
  static const int select = 2;
  static const int start = 3;
  static const int up = 4;
  static const int down = 5;
  static const int left = 6;
  static const int right = 7;
  static const int a = 8;
  static const int x = 9;
  static const int l = 10;
  static const int r = 11;
  static const int l2 = 12;
  static const int r2 = 13;
  static const int l3 = 14;
  static const int r3 = 15;
}

/// Service managing the Native C++ Libretro Engine powered by VE-NE (Vera Native Engine)
/// Supports zero-copy SurfaceTexture hardware rendering, AAudio EXCLUSIVE sink,
/// 128-bit ARM NEON SIMD blitting, and sub-millisecond input pipeline.
class NativeEmulatorService {
  static final NativeEmulatorService _instance = NativeEmulatorService._internal();
  factory NativeEmulatorService() => _instance;
  NativeEmulatorService._internal();

  static const MethodChannel _channel = MethodChannel('com.veracreation.vemo/emulator');
  final VeneFFIBridge _ffiBridge = VeneFFIBridge();
  bool _isFfiLoaded = false;

  int? _textureId;
  int? get textureId => _textureId;

  /// Initialize FFI bridge if available
  void initFfi() {
    if (!_isFfiLoaded) {
      _isFfiLoaded = _ffiBridge.load();
    }
  }

  /// Create Flutter Texture & attach Native Surface
  Future<int?> createTexture({int width = 256, int height = 224}) async {
    try {
      initFfi();
      final id = await _channel.invokeMethod<int>('createTexture', {
        'width': width,
        'height': height,
      });
      _textureId = id;
      debugPrint('[NativeEmulator:VE-NE] SurfaceTexture created with ID: $id (${width}x$height)');
      return id;
    } catch (e) {
      debugPrint('[NativeEmulator:VE-NE] Error creating texture: $e');
      return null;
    }
  }

  /// Start game using POSIX mmap() ROM file and VE-NE CoreLoader
  Future<bool> loadRom(Game game, String romFilePath) async {
    try {
      final core = Game.normalizeCore(game.core);
      final result = await _channel.invokeMethod<bool>('loadRom', {
        'romPath': romFilePath,
        'core': core,
        'gameId': game.id,
      });
      debugPrint('[NativeEmulator:VE-NE] Loaded ROM: ${game.title} with Core: $core -> $result');
      return result ?? false;
    } catch (e) {
      debugPrint('[NativeEmulator:VE-NE] Error loading ROM: $e');
      return false;
    }
  }

  /// Send button press / release state to VE-NE C++ engine
  Future<void> sendKey(int keyCode, bool isPressed) async {
    try {
      await _channel.invokeMethod('sendKey', {
        'keyCode': keyCode,
        'isPressed': isPressed,
      });
    } catch (_) {}
  }

  /// Send full 16-bit controller state with analog sticks
  void sendControllerState({
    required int buttons,
    double lx = 0.0,
    double ly = 0.0,
    double rx = 0.0,
    double ry = 0.0,
  }) {
    if (_isFfiLoaded) {
      _ffiBridge.sendControllerState(
        buttons: buttons,
        lx: lx,
        ly: ly,
        rx: rx,
        ry: ry,
      );
    } else {
      _channel.invokeMethod('sendControllerState', {
        'buttons': buttons,
        'lx': lx,
        'ly': ly,
        'rx': rx,
        'ry': ry,
      });
    }
  }

  /// Send analog stick position (stick: 0=Left, 1=Right; axis: 0=X, 1=Y; value: -1.0 to 1.0)
  Future<void> sendAnalog(int stick, int axis, double value) async {
    try {
      await _channel.invokeMethod('sendAnalog', {
        'stick': stick,
        'axis': axis,
        'value': value,
      });
    } catch (_) {}
  }

  /// Reset emulation (hardware-accurate core reset)
  Future<bool> reset() async {
    try {
      final res = await _channel.invokeMethod<bool>('reset');
      return res ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Save state to file
  Future<bool> saveState(String path) async {
    try {
      final res = await _channel.invokeMethod<bool>('saveState', {'path': path});
      return res ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Load state from file
  Future<bool> loadState(String path) async {
    try {
      final res = await _channel.invokeMethod<bool>('loadState', {'path': path});
      return res ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Save battery SRAM to .srm file
  Future<bool> saveSram([String? path]) async {
    try {
      final res = await _channel.invokeMethod<bool>('saveSram', {'path': path});
      return res ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Load battery SRAM from .srm file
  Future<bool> loadSram([String? path]) async {
    try {
      final res = await _channel.invokeMethod<bool>('loadSram', {'path': path});
      return res ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Set video filter mode (0: Smooth HD Bilinear, 1: Retro CRT Scanlines, 2: Crisp Pixel)
  Future<void> setVideoFilter(int mode) async {
    try {
      await _channel.invokeMethod('setVideoFilter', {'mode': mode});
    } catch (_) {}
  }

  /// Pause emulation loop and native AAudio stream
  Future<void> pause() async {
    try {
      await _channel.invokeMethod('pause');
    } catch (_) {}
  }

  /// Resume emulation loop and native AAudio stream
  Future<void> resume() async {
    try {
      await _channel.invokeMethod('resume');
    } catch (_) {}
  }

  /// Configure 3D Hardware acceleration, Internal Resolution Scaling (1x/2x/4x/8x), and Graphics API
  Future<bool> configureEngine({
    bool enableHw = true,
    int resolutionScale = 1,
    int graphicsApi = 0, // 0 = GLES3, 1 = Vulkan
    bool enableVrr = true,
  }) async {
    try {
      if (_isFfiLoaded) {
        _ffiBridge.configureEngine(
          enableHwAcceleration: enableHw,
          internalResolutionScale: resolutionScale,
          graphicsApi: graphicsApi,
          enableVrrPacing: enableVrr,
        );
      }
      final res = await _channel.invokeMethod<bool>('configureEngine', {
        'enableHw': enableHw,
        'resolutionScale': resolutionScale,
        'graphicsApi': graphicsApi,
        'enableVrr': enableVrr,
      });
      return res ?? true;
    } catch (e) {
      debugPrint('[NativeEmulator:VE-NE] Error configuring 3D HW Engine: $e');
      return false;
    }
  }

  /// Stop native engine & release surface
  Future<void> stop() async {
    try {
      await _channel.invokeMethod('stop');
      _textureId = null;
    } catch (_) {}
  }
}
