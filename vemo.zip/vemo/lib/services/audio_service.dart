import 'package:flutter/foundation.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Singleton service for managing ambient lobby background music.
/// Configured with soft default volume (25%) so it never overpowers the user experience.
class AudioService {
  static final AudioService _instance = AudioService._internal();
  factory AudioService() => _instance;
  AudioService._internal();

  final AudioPlayer _player = AudioPlayer();
  final AudioPlayer _sfxPlayer = AudioPlayer();
  int _lastSfxTimestamp = 0;
  bool _isInitialized = false;
  bool _isPlaying = false;
  bool _isInGameplay = false;
  bool _wasPlayingBeforeBackground = false;

  // Notifiers for reactive UI binding
  final ValueNotifier<bool> isMutedNotifier = ValueNotifier<bool>(false);
  final ValueNotifier<double> volumeNotifier = ValueNotifier<double>(0.25);

  bool get isMuted => isMutedNotifier.value;
  double get volume => volumeNotifier.value;
  bool get isPlaying => _isPlaying;
  bool get isInGameplay => _isInGameplay;

  final Source _veraBlipSource = AssetSource('audio/vera_talk.wav');
  bool _isSfxPrepared = false;

  Future<void> _ensureSfxPrepared() async {
    if (_isSfxPrepared) return;
    try {
      await _sfxPlayer.setPlayerMode(PlayerMode.lowLatency);
      await _sfxPlayer.setSource(_veraBlipSource);
      await _sfxPlayer.setVolume(0.55);
      _isSfxPrepared = true;
    } catch (_) {}
  }

  /// Low-latency Sans-dialogue SFX blip for Vera talking (zero memory leak, single reusable player)
  Future<void> playVeraBlip() async {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastSfxTimestamp < 110) return;
    _lastSfxTimestamp = now;
    try {
      if (!_isSfxPrepared) {
        await _ensureSfxPrepared();
      }
      await _sfxPlayer.seek(Duration.zero);
      await _sfxPlayer.resume();
    } catch (_) {
      try {
        await _sfxPlayer.play(
          _veraBlipSource,
          mode: PlayerMode.lowLatency,
          volume: 0.55,
        );
      } catch (_) {}
    }
  }

  /// Immediately stops any ongoing Vera talk SFX
  Future<void> stopVeraBlip() async {
    try {
      await _sfxPlayer.pause();
    } catch (_) {}
  }

  /// Call when entering emulator gameplay
  void setInGameplay(bool value) {
    _isInGameplay = value;
    if (value) {
      pauseLobbyBgm();
    }
  }

  /// Initialize player, load persisted volume and mute settings, and start BGM.
  Future<void> init() async {
    if (_isInitialized) return;
    _isInitialized = true;

    try {
      final prefs = await SharedPreferences.getInstance();
      final savedMuted = prefs.getBool('lobby_bgm_muted') ?? false;
      final savedVolume = prefs.getDouble('lobby_bgm_volume') ?? 0.25;

      isMutedNotifier.value = savedMuted;
      volumeNotifier.value = savedVolume.clamp(0.0, 1.0);

      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.setVolume(isMuted ? 0.0 : volume);
    } catch (e) {
      debugPrint('[AudioService] Init error: $e');
    }
  }

  /// Start or loop the lobby background music ("Insert Coin").
  Future<void> playLobbyBgm() async {
    try {
      if (_isInGameplay) return; // Never play lobby BGM during gameplay
      if (!_isInitialized) await init();
      if (_isPlaying) return;

      await _player.setVolume(isMuted ? 0.0 : volume);
      await _player.play(AssetSource('audio/insert_coin.mp3'));
      _isPlaying = true;
      debugPrint('[AudioService] Lobby BGM started at volume: ${(volume * 100).round()}%');
    } catch (e) {
      debugPrint('[AudioService] Play error: $e');
    }
  }

  /// Pause lobby music (e.g. when launching a game into emulator or app minimized).
  Future<void> pauseLobbyBgm({bool dueToBackground = false}) async {
    try {
      if (_isPlaying) {
        if (dueToBackground) {
          _wasPlayingBeforeBackground = true;
        }
        await _player.pause();
        _isPlaying = false;
        debugPrint('[AudioService] Lobby BGM paused (background: $dueToBackground)');
      }
    } catch (e) {
      debugPrint('[AudioService] Pause error: $e');
    }
  }

  /// Called when app returns to foreground from background.
  Future<void> onAppForeground() async {
    if (!_isInGameplay && (_wasPlayingBeforeBackground || !_isPlaying)) {
      _wasPlayingBeforeBackground = false;
      await resumeLobbyBgm();
    }
  }

  /// Resume lobby music gently when returning from gameplay.
  Future<void> resumeLobbyBgm() async {
    try {
      if (_isInGameplay) return;
      if (!_isPlaying) {
        await _player.setVolume(isMuted ? 0.0 : volume);
        await _player.resume();
        _isPlaying = true;
        debugPrint('[AudioService] Lobby BGM resumed');
      }
    } catch (e) {
      // If resume fails (e.g. source was dropped), replay cleanly
      await playLobbyBgm();
    }
  }

  /// Adjust BGM volume (0.0 to 1.0) and persist preference.
  Future<void> setVolume(double newVolume) async {
    try {
      final clamped = newVolume.clamp(0.0, 1.0);
      volumeNotifier.value = clamped;
      if (!isMuted) {
        await _player.setVolume(clamped);
      }
      final prefs = await SharedPreferences.getInstance();
      await prefs.setDouble('lobby_bgm_volume', clamped);
    } catch (e) {
      debugPrint('[AudioService] SetVolume error: $e');
    }
  }

  /// Duck lobby BGM to a quiet whisper volume while dialogue / voice plays
  Future<void> duckLobbyBgm({double duckVolume = 0.04}) async {
    try {
      if (!isMuted && _isPlaying) {
        await _player.setVolume(duckVolume);
        debugPrint('[AudioService] Lobby BGM ducked to ${(duckVolume * 100).round()}%');
      }
    } catch (e) {
      debugPrint('[AudioService] Duck error: $e');
    }
  }

  /// Restore lobby BGM volume smoothly to normal user setting
  Future<void> unduckLobbyBgm() async {
    try {
      if (!isMuted) {
        await _player.setVolume(volume);
        if (!_isPlaying && !_isInGameplay) {
          await resumeLobbyBgm();
        }
        debugPrint('[AudioService] Lobby BGM restored to ${(volume * 100).round()}%');
      }
    } catch (e) {
      debugPrint('[AudioService] Unduck error: $e');
    }
  }

  /// Toggle mute state with persistent storage.
  Future<void> toggleMute() async {
    try {
      final newMuted = !isMuted;
      isMutedNotifier.value = newMuted;
      await _player.setVolume(newMuted ? 0.0 : volume);

      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('lobby_bgm_muted', newMuted);
    } catch (e) {
      debugPrint('[AudioService] ToggleMute error: $e');
    }
  }

  /// Release resources if needed.
  Future<void> dispose() async {
    _isInitialized = false;
    _isPlaying = false;
    try {
      await _player.dispose();
      await _sfxPlayer.dispose();
    } catch (_) {}
  }
}
