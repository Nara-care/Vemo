import 'package:shared_preferences/shared_preferences.dart';
import '../models/game.dart';
import '../data/game_library.dart';

/// Manages the user's game library — stored persistently in SharedPreferences.
class UserLibraryService {
  static const _key = 'vemo_user_library_v4';
  static const _hiddenBundledKey = 'vemo_hidden_bundled_games_v1';

  /// Returns all saved games. Bundled games are included unless explicitly removed/hidden by the user.
  Future<List<Game>> getGames() async {
    final prefs = await SharedPreferences.getInstance();
    final hiddenIds = (prefs.getStringList(_hiddenBundledKey) ?? []).toSet();

    final json = prefs.getString(_key);
    List<Game> savedGames = [];
    if (json != null && json.isNotEmpty) {
      try {
        savedGames = Game.decodeList(json);
      } catch (_) {}
    }

    final List<Game> result = [];
    final existingIds = <String>{};

    // 1. Ensure default bundled games exist UNLESS hidden by user
    for (final bundled in kDefaultBundledGames) {
      if (!hiddenIds.contains(bundled.id)) {
        // If user has an updated/customized version in savedGames, prefer that
        final customIndex = savedGames.indexWhere((g) => g.id == bundled.id);
        if (customIndex >= 0) {
          result.add(savedGames[customIndex]);
        } else {
          result.add(bundled);
        }
        existingIds.add(bundled.id);
      }
    }

    // 2. Append user-imported games
    for (final g in savedGames) {
      if (!existingIds.contains(g.id)) {
        result.add(g);
        existingIds.add(g.id);
      }
    }

    return result;
  }

  /// Updates an existing game in the library (or persists customized metadata for bundled games)
  Future<void> updateGame(Game game) async {
    final prefs = await SharedPreferences.getInstance();
    final json = prefs.getString(_key);
    List<Game> savedGames = [];
    if (json != null && json.isNotEmpty) {
      try {
        savedGames = Game.decodeList(json);
      } catch (_) {}
    }

    final index = savedGames.indexWhere((g) => g.id == game.id);
    if (index >= 0) {
      savedGames[index] = game;
    } else {
      savedGames.add(game);
    }
    await _save(savedGames);
  }

  /// Adds a game to the library (if not already present).
  Future<void> addGame(Game game) async {
    final prefs = await SharedPreferences.getInstance();
    final json = prefs.getString(_key);
    List<Game> savedGames = [];
    if (json != null && json.isNotEmpty) {
      try {
        savedGames = Game.decodeList(json);
      } catch (_) {}
    }

    final index = savedGames.indexWhere((g) => g.id == game.id);
    if (index >= 0) {
      savedGames[index] = game;
    } else {
      savedGames.add(game);
    }
    await _save(savedGames);

    // If re-adding a bundled game, unhide it
    final hiddenIds = (prefs.getStringList(_hiddenBundledKey) ?? []).toSet();
    if (hiddenIds.contains(game.id)) {
      hiddenIds.remove(game.id);
      await prefs.setStringList(_hiddenBundledKey, hiddenIds.toList());
    }
  }

  /// Adds multiple games to the library in a single atomic batch save.
  Future<void> addGames(List<Game> games) async {
    if (games.isEmpty) return;
    final prefs = await SharedPreferences.getInstance();
    final json = prefs.getString(_key);
    List<Game> savedGames = [];
    if (json != null && json.isNotEmpty) {
      try {
        savedGames = Game.decodeList(json);
      } catch (_) {}
    }

    final hiddenIds = (prefs.getStringList(_hiddenBundledKey) ?? []).toSet();
    bool hiddenChanged = false;

    for (final game in games) {
      final index = savedGames.indexWhere((g) => g.id == game.id);
      if (index >= 0) {
        savedGames[index] = game;
      } else {
        savedGames.add(game);
      }
      if (hiddenIds.contains(game.id)) {
        hiddenIds.remove(game.id);
        hiddenChanged = true;
      }
    }

    await _save(savedGames);
    if (hiddenChanged) {
      await prefs.setStringList(_hiddenBundledKey, hiddenIds.toList());
    }
  }

  /// Removes a game by id (permanently hides bundled games and deletes user-imported games).
  Future<void> removeGame(String id) async {
    final prefs = await SharedPreferences.getInstance();
    
    // Check if it's a bundled game
    final isBundled = kDefaultBundledGames.any((b) => b.id == id);
    if (isBundled) {
      final hiddenIds = (prefs.getStringList(_hiddenBundledKey) ?? []).toSet();
      hiddenIds.add(id);
      await prefs.setStringList(_hiddenBundledKey, hiddenIds.toList());
    }

    // Also remove from saved user games if present
    final json = prefs.getString(_key);
    if (json != null && json.isNotEmpty) {
      try {
        final savedGames = Game.decodeList(json);
        savedGames.removeWhere((g) => g.id == id);
        await _save(savedGames);
      } catch (_) {}
    }
  }

  /// Restores all hidden default bundled games back to the library.
  Future<void> restoreBundledGames() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_hiddenBundledKey);
  }

  /// Clears all games.
  Future<void> clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_key);
    await prefs.remove(_hiddenBundledKey);
  }

  Future<void> _save(List<Game> games) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, Game.encodeList(games));
  }
}
