import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum ControllerPreset { standard, bigFingers, arcade, custom }

/// Data model for a single Controller Layout Slot (Supports HP, Tablet, Claw Grip, etc.)
class ControllerSlotData {
  String name;
  double scale;
  double opacity;
  double dpadOffsetX;
  double dpadOffsetY;
  double actionOffsetX;
  double actionOffsetY;
  double lTriggerOffsetX;
  double lTriggerOffsetY;
  double rTriggerOffsetX;
  double rTriggerOffsetY;
  double menuDockOffsetX;
  double menuDockOffsetY;
  bool isActionTilted;

  ControllerSlotData({
    required this.name,
    this.scale = 1.0,
    this.opacity = 0.85,
    this.dpadOffsetX = 0.0,
    this.dpadOffsetY = 0.0,
    this.actionOffsetX = 0.0,
    this.actionOffsetY = 0.0,
    this.lTriggerOffsetX = 0.0,
    this.lTriggerOffsetY = 0.0,
    this.rTriggerOffsetX = 0.0,
    this.rTriggerOffsetY = 0.0,
    this.menuDockOffsetX = 0.0,
    this.menuDockOffsetY = 0.0,
    this.isActionTilted = true,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'scale': scale,
        'opacity': opacity,
        'dpadOffsetX': dpadOffsetX,
        'dpadOffsetY': dpadOffsetY,
        'actionOffsetX': actionOffsetX,
        'actionOffsetY': actionOffsetY,
        'lTriggerOffsetX': lTriggerOffsetX,
        'lTriggerOffsetY': lTriggerOffsetY,
        'rTriggerOffsetX': rTriggerOffsetX,
        'rTriggerOffsetY': rTriggerOffsetY,
        'menuDockOffsetX': menuDockOffsetX,
        'menuDockOffsetY': menuDockOffsetY,
        'isActionTilted': isActionTilted,
      };

  factory ControllerSlotData.fromJson(Map<String, dynamic> json, {required String defaultName}) {
    return ControllerSlotData(
      name: json['name'] as String? ?? defaultName,
      scale: ((json['scale'] as num?)?.toDouble() ?? 1.0).clamp(0.75, 1.40),
      opacity: ((json['opacity'] as num?)?.toDouble() ?? 0.85).clamp(0.20, 1.0),
      dpadOffsetX: ((json['dpadOffsetX'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      dpadOffsetY: ((json['dpadOffsetY'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      actionOffsetX: ((json['actionOffsetX'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      actionOffsetY: ((json['actionOffsetY'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      lTriggerOffsetX: ((json['lTriggerOffsetX'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      lTriggerOffsetY: ((json['lTriggerOffsetY'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      rTriggerOffsetX: ((json['rTriggerOffsetX'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      rTriggerOffsetY: ((json['rTriggerOffsetY'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      menuDockOffsetX: ((json['menuDockOffsetX'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      menuDockOffsetY: ((json['menuDockOffsetY'] as num?)?.toDouble() ?? 0.0).clamp(-180.0, 180.0),
      isActionTilted: json['isActionTilted'] as bool? ?? true,
    );
  }

  ControllerSlotData clone() {
    return ControllerSlotData(
      name: name,
      scale: scale,
      opacity: opacity,
      dpadOffsetX: dpadOffsetX,
      dpadOffsetY: dpadOffsetY,
      actionOffsetX: actionOffsetX,
      actionOffsetY: actionOffsetY,
      lTriggerOffsetX: lTriggerOffsetX,
      lTriggerOffsetY: lTriggerOffsetY,
      rTriggerOffsetX: rTriggerOffsetX,
      rTriggerOffsetY: rTriggerOffsetY,
      menuDockOffsetX: menuDockOffsetX,
      menuDockOffsetY: menuDockOffsetY,
      isActionTilted: isActionTilted,
    );
  }
}

/// Manages persistent customized positions, scales, opacities, and 3 custom slots for virtual touch buttons.
class ControllerLayoutService {
  static final ControllerLayoutService _instance = ControllerLayoutService._internal();
  factory ControllerLayoutService() => _instance;
  ControllerLayoutService._internal();

  static const String _prefKeySlots = 'vemo_controller_layout_slots_v5';
  static const String _prefKeyActiveSlot = 'vemo_controller_active_slot_v5';

  int activeSlotIndex = 0; // 0: Slot 1, 1: Slot 2, 2: Slot 3

  final List<ControllerSlotData> slots = [
    ControllerSlotData(name: 'Slot 1 (Standar HP)'),
    ControllerSlotData(name: 'Slot 2 (Tablet / Layar Lebar)'),
    ControllerSlotData(name: 'Slot 3 (Kustom / Claw)'),
  ];

  // Helper getters pointing directly to current active slot for zero breaking changes:
  ControllerSlotData get current => slots[activeSlotIndex.clamp(0, slots.length - 1)];

  double get scale => current.scale;
  set scale(double val) => current.scale = val.clamp(0.75, 1.40);

  double get opacity => current.opacity;
  set opacity(double val) => current.opacity = val.clamp(0.20, 1.0);

  double get dpadOffsetX => current.dpadOffsetX;
  set dpadOffsetX(double val) => current.dpadOffsetX = val.clamp(-180.0, 180.0);

  double get dpadOffsetY => current.dpadOffsetY;
  set dpadOffsetY(double val) => current.dpadOffsetY = val.clamp(-180.0, 180.0);

  double get actionOffsetX => current.actionOffsetX;
  set actionOffsetX(double val) => current.actionOffsetX = val.clamp(-180.0, 180.0);

  double get actionOffsetY => current.actionOffsetY;
  set actionOffsetY(double val) => current.actionOffsetY = val.clamp(-180.0, 180.0);

  double get lTriggerOffsetX => current.lTriggerOffsetX;
  set lTriggerOffsetX(double val) => current.lTriggerOffsetX = val.clamp(-180.0, 180.0);

  double get lTriggerOffsetY => current.lTriggerOffsetY;
  set lTriggerOffsetY(double val) => current.lTriggerOffsetY = val.clamp(-180.0, 180.0);

  double get rTriggerOffsetX => current.rTriggerOffsetX;
  set rTriggerOffsetX(double val) => current.rTriggerOffsetX = val.clamp(-180.0, 180.0);

  double get rTriggerOffsetY => current.rTriggerOffsetY;
  set rTriggerOffsetY(double val) => current.rTriggerOffsetY = val.clamp(-180.0, 180.0);

  double get menuDockOffsetX => current.menuDockOffsetX;
  set menuDockOffsetX(double val) => current.menuDockOffsetX = val.clamp(-180.0, 180.0);

  double get menuDockOffsetY => current.menuDockOffsetY;
  set menuDockOffsetY(double val) => current.menuDockOffsetY = val.clamp(-180.0, 180.0);

  bool get isActionTilted => current.isActionTilted;
  set isActionTilted(bool val) => current.isActionTilted = val;

  ControllerPreset activePreset = ControllerPreset.standard;

  Future<void> init() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      activeSlotIndex = (prefs.getInt(_prefKeyActiveSlot) ?? 0).clamp(0, 2);

      final jsonStr = prefs.getString(_prefKeySlots);
      if (jsonStr != null) {
        final List<dynamic> decoded = jsonDecode(jsonStr);
        for (int i = 0; i < slots.length && i < decoded.length; i++) {
          final item = decoded[i] as Map<String, dynamic>;
          slots[i] = ControllerSlotData.fromJson(
            item,
            defaultName: slots[i].name,
          );
        }
      }
    } catch (e) {
      debugPrint('[ControllerLayoutService] Error loading layout slots: $e');
    }
  }

  Future<void> save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_prefKeyActiveSlot, activeSlotIndex);

      final data = slots.map((s) => s.toJson()).toList();
      await prefs.setString(_prefKeySlots, jsonEncode(data));
      debugPrint('[ControllerLayoutService] Saved all 3 layout slots.');
    } catch (e) {
      debugPrint('[ControllerLayoutService] Error saving layout slots: $e');
    }
  }

  Future<void> switchSlot(int index) async {
    activeSlotIndex = index.clamp(0, slots.length - 1);
    await save();
  }

  Future<void> resetSlotToDefault(int index) async {
    final i = index.clamp(0, slots.length - 1);
    final defaultNames = [
      'Slot 1 (Standar HP)',
      'Slot 2 (Tablet / Layar Lebar)',
      'Slot 3 (Kustom / Claw)',
    ];

    if (i == 1) {
      // Tablet ergonomic preset default (buttons shifted inward for comfortable reach)
      slots[i] = ControllerSlotData(
        name: defaultNames[i],
        scale: 1.15,
        opacity: 0.90,
        dpadOffsetX: 40.0,
        dpadOffsetY: 20.0,
        actionOffsetX: -40.0,
        actionOffsetY: 20.0,
        lTriggerOffsetX: 20.0,
        lTriggerOffsetY: 10.0,
        rTriggerOffsetX: -20.0,
        rTriggerOffsetY: 10.0,
        menuDockOffsetX: 0.0,
        menuDockOffsetY: 10.0,
        isActionTilted: true,
      );
    } else {
      slots[i] = ControllerSlotData(name: defaultNames[i]);
    }
    await save();
  }

  Future<void> applyPreset(ControllerPreset preset) async {
    activePreset = preset;
    switch (preset) {
      case ControllerPreset.standard:
        current.scale = 1.0;
        current.opacity = 0.85;
        current.dpadOffsetX = 0.0;
        current.dpadOffsetY = 0.0;
        current.actionOffsetX = 0.0;
        current.actionOffsetY = 0.0;
        current.lTriggerOffsetX = 0.0;
        current.lTriggerOffsetY = 0.0;
        current.rTriggerOffsetX = 0.0;
        current.rTriggerOffsetY = 0.0;
        current.menuDockOffsetX = 0.0;
        current.menuDockOffsetY = 0.0;
        current.isActionTilted = true;
        break;
      case ControllerPreset.bigFingers:
        current.scale = 1.20;
        current.opacity = 0.90;
        current.dpadOffsetX = 10.0;
        current.dpadOffsetY = -8.0;
        current.actionOffsetX = -10.0;
        current.actionOffsetY = -8.0;
        current.isActionTilted = true;
        break;
      case ControllerPreset.arcade:
        current.scale = 1.10;
        current.opacity = 0.80;
        current.dpadOffsetX = 0.0;
        current.dpadOffsetY = 0.0;
        current.actionOffsetX = 0.0;
        current.actionOffsetY = 0.0;
        current.isActionTilted = false;
        break;
      case ControllerPreset.custom:
        break;
    }
    await save();
  }

  Future<void> resetToDefault() async {
    await resetSlotToDefault(activeSlotIndex);
  }
}
