import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:crypto/crypto.dart';

/// Metadata definition for known system BIOS files.
class BiosInfo {
  final String filename;
  final String console;
  final String description;
  final String? expectedMd5;
  final bool isRequired;

  const BiosInfo({
    required this.filename,
    required this.console,
    required this.description,
    this.expectedMd5,
    this.isRequired = false,
  });
}

/// Manages system BIOS verification, MD5 checksum calculation, and provisioning.
class BiosService {
  static final BiosService _instance = BiosService._internal();
  factory BiosService() => _instance;
  BiosService._internal();

  /// Known console BIOS catalogue for V1 supported retro systems (GBA, Sega CD)
  static const List<BiosInfo> knownBiosList = [
    // Game Boy Advance
    BiosInfo(
      filename: 'gba_bios.bin',
      console: 'GBA',
      description: 'Game Boy Advance Official Boot ROM (Opsional - mGBA memiliki HLE bios bawaan)',
      expectedMd5: 'a860e8c0b6d573d191e4ec7db1b1e4f6',
    ),
    // Sega CD / Mega-CD (Genesis Plus GX)
    BiosInfo(
      filename: 'bios_CD_U.bin',
      console: 'GENESIS',
      description: 'Sega CD (USA) BIOS untuk Genesis Plus GX',
      expectedMd5: '2efd74e3232ff260e3929994f0e5043f',
    ),
    // Sony PlayStation 1 (DuckStation / PCSX ReARMed / SwanStation / Beetle PSX)
    BiosInfo(
      filename: 'scph5501.bin',
      console: 'PS1',
      description: 'PlayStation 1 (USA v3.0) Recommended Standard BIOS',
      expectedMd5: '490f666e1afb15b7362b406ed1cea946',
      isRequired: true,
    ),
    BiosInfo(
      filename: 'scph1001.bin',
      console: 'PS1',
      description: 'PlayStation 1 (USA v2.0) BIOS',
      expectedMd5: '924e392ed05558ffdb115408c263dccf',
    ),
    BiosInfo(
      filename: 'scph5502.bin',
      console: 'PS1',
      description: 'PlayStation 1 (Europe/PAL v3.0) BIOS',
      expectedMd5: '32736f17079d0b2b70244077792e6094',
    ),
    BiosInfo(
      filename: 'scph5500.bin',
      console: 'PS1',
      description: 'PlayStation 1 (Japan v3.0) BIOS',
      expectedMd5: 'ff3eeb8c664e0d63beb5f6f6986de4c5',
    ),
  ];

  /// Get the system directory path where Libretro cores expect BIOS files
  Future<Directory> getSystemDirectory() async {
    final docsDir = await getApplicationDocumentsDirectory();
    final parentDir = docsDir.parent;
    final filesDir = Directory('${parentDir.path}/files');
    if (!await filesDir.exists()) {
      await filesDir.create(recursive: true);
    }
    return filesDir;
  }

  /// Checks if a specific BIOS file exists in the system directory
  Future<bool> isBiosPresent(String filename) async {
    final sysDir = await getSystemDirectory();
    final cleanName = filename.replaceAll(RegExp(r'[\\/]'), '').replaceAll('..', '');
    if (cleanName.isEmpty) return false;
    final file = File('${sysDir.path}/$cleanName');
    return await file.exists();
  }

  /// Calculates MD5 checksum of a file
  Future<String?> getFileMd5(File file) async {
    if (!await file.exists()) return null;
    try {
      final bytes = await file.readAsBytes();
      return md5.convert(bytes).toString();
    } catch (_) {
      return null;
    }
  }

  /// Verifies whether the installed BIOS matches the official MD5 checksum
  Future<bool> verifyBiosChecksum(String filename) async {
    final sysDir = await getSystemDirectory();
    final cleanName = filename.replaceAll(RegExp(r'[\\/]'), '').replaceAll('..', '');
    if (cleanName.isEmpty) return false;
    final file = File('${sysDir.path}/$cleanName');
    if (!await file.exists()) return false;

    final info = knownBiosList.firstWhere(
      (b) => b.filename.toLowerCase() == cleanName.toLowerCase(),
      orElse: () => BiosInfo(filename: cleanName, console: 'Unknown', description: ''),
    );

    if (info.expectedMd5 == null) return true; // No hash to verify
    final calculatedMd5 = await getFileMd5(file);
    return calculatedMd5?.toLowerCase() == info.expectedMd5!.toLowerCase();
  }

  /// Imports a user-selected BIOS file safely into the Libretro system directory
  Future<bool> importBiosFile(String targetFileName, Uint8List bytes) async {
    try {
      // Security: Sanitize filename to prevent path traversal attacks
      final cleanName = targetFileName.replaceAll(RegExp(r'[\\/]'), '').replaceAll('..', '').trim();
      if (cleanName.isEmpty) return false;

      final sysDir = await getSystemDirectory();
      final targetFile = File('${sysDir.path}/$cleanName');
      await targetFile.writeAsBytes(bytes);
      debugPrint('[BiosService] Successfully installed BIOS: $cleanName (${bytes.length} bytes)');
      return true;
    } catch (e) {
      debugPrint('[BiosService] Failed to import BIOS $targetFileName: $e');
      return false;
    }
  }

  /// Returns summary status of all known BIOS files
  Future<Map<String, bool>> getBiosStatusMap() async {
    final Map<String, bool> status = {};
    for (final bios in knownBiosList) {
      status[bios.filename] = await isBiosPresent(bios.filename);
    }
    return status;
  }
}
