import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum HapticIntensity { off, light, medium, heavy }

class HapticService {
  static final HapticService _instance = HapticService._internal();
  factory HapticService() => _instance;
  HapticService._internal();

  bool enabled = true;
  HapticIntensity intensity = HapticIntensity.medium;
  double controlSize = 1.0; // 0.8 to 1.2
  double controlOpacity = 0.8; // 0.3 to 1.0

  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    enabled = prefs.getBool('haptic_enabled') ?? true;
    final intIndex = prefs.getInt('haptic_intensity') ?? 2;
    intensity = HapticIntensity.values[intIndex.clamp(0, 3)];
    controlSize = prefs.getDouble('control_size') ?? 1.0;
    controlOpacity = prefs.getDouble('control_opacity') ?? 0.8;
  }

  Future<void> setEnabled(bool val) async {
    enabled = val;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('haptic_enabled', val);
  }

  Future<void> setIntensity(HapticIntensity val) async {
    intensity = val;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('haptic_intensity', val.index);
  }

  Future<void> setControlSize(double val) async {
    controlSize = val;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('control_size', val);
  }

  Future<void> setControlOpacity(double val) async {
    controlOpacity = val;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('control_opacity', val);
  }

  /// Instant tactile button click (sub-millisecond haptic tap)
  void triggerClick() {
    if (!enabled || intensity == HapticIntensity.off) return;
    try {
      switch (intensity) {
        case HapticIntensity.light:
          HapticFeedback.selectionClick();
          break;
        case HapticIntensity.medium:
          HapticFeedback.lightImpact();
          break;
        case HapticIntensity.heavy:
          HapticFeedback.mediumImpact();
          break;
        case HapticIntensity.off:
          break;
      }
    } catch (_) {
      // Fallback to basic vibration if device doesn't support fine haptic channels
      try {
        HapticFeedback.vibrate();
      } catch (_) {}
    }
  }

  /// Subtle rollover tick for D-Pad angle changes (Diagonal movement feedback)
  void triggerRollover() {
    if (!enabled || intensity == HapticIntensity.off) return;
    try {
      HapticFeedback.selectionClick();
    } catch (_) {}
  }

  /// General trigger fallback / preview test
  void trigger() {
    if (!enabled || intensity == HapticIntensity.off) return;
    try {
      switch (intensity) {
        case HapticIntensity.light:
          HapticFeedback.selectionClick();
          break;
        case HapticIntensity.medium:
          HapticFeedback.mediumImpact();
          break;
        case HapticIntensity.heavy:
          HapticFeedback.heavyImpact();
          break;
        case HapticIntensity.off:
          break;
      }
    } catch (_) {
      HapticFeedback.vibrate();
    }
  }
}
