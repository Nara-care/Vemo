import 'dart:io';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:archive/archive.dart';
import '../models/game.dart';
import 'user_library_service.dart';

class RomService {
  static final RomService _instance = RomService._internal();
  factory RomService() => _instance;
  RomService._internal();

  /// Known console ROM extensions that should be extracted from .zip
  static const Set<String> _consoleExtensions = {
    'nes', 'fds', 'unf',
    'sfc', 'smc', 'fig', 'swc',
    'gba', 'gb', 'gbc',
    'md', 'gen', 'smd',
    'sms', 'gg', 'sg',
    'chd', 'cue', 'pbp', 'iso', 'bin', 'img',
    'z64', 'n64', 'v64',
  };

  /// Validate header magic bytes of ROM files to prevent corrupt or bogus files
  static bool validateRomHeader(Uint8List bytes, String ext) {
    if (bytes.isEmpty) return false;
    final lowerExt = ext.toLowerCase();

    // Cue sheets can be relatively small text files (< 1MB)
    if (lowerExt == 'cue') {
      if (bytes.length > 0 && bytes.length < 1024 * 1024) {
        try {
          final preview = String.fromCharCodes(bytes.sublist(0, bytes.length.clamp(0, 512))).toUpperCase();
          if (preview.contains('FILE') || preview.contains('TRACK')) return true;
        } catch (_) {}
        return true;
      }
      return false;
    }

    // Reject files that are absurdly small (< 32 bytes) for ROM containers
    if (bytes.length < 32) return false;

    switch (lowerExt) {
      case 'nes':
      case 'fds':
      case 'unf':
        // NES 2.0 / iNES header: 'NES\x1A' (0x4E, 0x45, 0x53, 0x1A)
        if (bytes.length >= 4) {
          if (bytes[0] == 0x4E && bytes[1] == 0x45 && bytes[2] == 0x53 && bytes[3] == 0x1A) {
            return true;
          }
        }
        return bytes.length >= 8192; // Fallback for raw or unheadered dumps

      case 'gba':
        // GBA ROM: Nintendo logo check at offset 0xB2 (value 0x96) or valid ARM entry opcode
        if (bytes.length >= 192) {
          if (bytes.length > 0xB2 && bytes[0xB2] == 0x96) return true;
          final armOpcode = bytes[3];
          if (armOpcode == 0xEA || armOpcode == 0xEB) return true;
        }
        return bytes.length >= 32768;

      case 'gb':
      case 'gbc':
        // Game Boy cartridge header check (offset 0x0104 - 0x0107 Nintendo logo: 0xCE, 0xED, 0x66, 0x66)
        if (bytes.length >= 512) {
          if (bytes.length > 0x107 &&
              bytes[0x104] == 0xCE &&
              bytes[0x105] == 0xED &&
              bytes[0x106] == 0x66 &&
              bytes[0x107] == 0x66) {
            return true;
          }
          // Cartridge header entry point (NOP + JP at 0x100: 0x00, 0xC3)
          if (bytes.length > 0x101 && bytes[0x100] == 0x00 && bytes[0x101] == 0xC3) {
            return true;
          }
        }
        return bytes.length >= 16384; // Lenient fallback for ROMhacks/homebrews

      case 'sfc':
      case 'smc':
      case 'fig':
      case 'swc':
        // SNES ROM: Minimal valid cartridge size is at least 32KB
        return bytes.length >= 32768;

      case 'md':
      case 'gen':
      case 'smd':
      case 'sms':
      case 'gg':
      case 'sg':
        // Sega Mega Drive / Genesis header check ("SEGA" at offset 0x0100) or size >= 512 bytes
        if (bytes.length >= 512) {
          if (bytes.length >= 0x104) {
            final magic = String.fromCharCodes(bytes.sublist(0x100, 0x104));
            if (magic == 'SEGA') return true;
          }
          if (lowerExt == 'sms' || lowerExt == 'gg' || lowerExt == 'sg') return true;
          if (bytes.length >= 16384) return true;
        }
        return false;

      case 'chd':
        // MAME CHD header 'MComprHD'
        if (bytes.length >= 8) {
          final magic = String.fromCharCodes(bytes.sublist(0, 8));
          if (magic == 'MComprHD') return true;
        }
        return bytes.length >= 1024 * 1024;

      case 'iso':
      case 'img':
        // Disc image files
        return bytes.length >= 1024 * 1024;

      case 'pbp':
        // Sony PSP / PS1 EBOOT header '\0PBP'
        if (bytes.length >= 4) {
          if (bytes[0] == 0x00 && bytes[1] == 0x50 && bytes[2] == 0x42 && bytes[3] == 0x50) {
            return true;
          }
        }
        return bytes.length >= 1024 * 1024;

      case 'bin':
        // .bin could be Genesis (>= 16KB) or PS1 track (>= 10MB)
        return bytes.length >= 16384;

      case 'z64':
      case 'n64':
      case 'v64':
        return bytes.length >= 1024 * 1024;

      case 'zip':
        // ZIP archive magic bytes: 'PK\x03\x04' (0x50, 0x4B, 0x03, 0x04)
        if (bytes.length >= 4) {
          return bytes[0] == 0x50 && bytes[1] == 0x4B && bytes[2] == 0x03 && bytes[3] == 0x04;
        }
        return false;

      default:
        // Allow any known extension with valid size fallback
        if (_consoleExtensions.contains(lowerExt) && bytes.length >= 512) {
          return true;
        }
        return false;
    }
  }

  /// Check if a game's ROM is available (local path, local storage, or bundled assets)
  Future<bool> isRomAvailable(Game game) async {
    // 1. Direct local file path
    if (game.localRomPath != null && game.localRomPath!.isNotEmpty) {
      if (await File(game.localRomPath!).exists()) {
        return true;
      }
    }

    // 2. Local app document storage
    final localFile = await getLocalRomFile(game.id);
    if (await localFile.exists()) {
      return true;
    }

    // 3. Bundled asset
    if (game.romPath.isNotEmpty) {
      try {
        await rootBundle.load(game.romAssetPath);
        return true;
      } catch (_) {}
    }

    return false;
  }

  /// Get the local storage file for a game's ROM preserving its original extension
  Future<File> getLocalRomFile(String gameId, {String? extension}) async {
    final docsDir = await getApplicationDocumentsDirectory();
    final romsDir = Directory('${docsDir.path}/roms');
    if (!await romsDir.exists()) {
      await romsDir.create(recursive: true);
    }
    final ext = (extension != null && extension.isNotEmpty)
        ? (extension.startsWith('.') ? extension : '.$extension')
        : '.rom';
    return File('${romsDir.path}/$gameId$ext');
  }

  /// Ensure ROM is on local filesystem and return its absolute path
  Future<String?> getRomFilePath(Game game) async {
    // 1. Direct local file path
    if (game.localRomPath != null && game.localRomPath!.isNotEmpty) {
      final file = File(game.localRomPath!);
      if (await file.exists()) {
        return file.absolute.path;
      }
    }

    // 2. Local app document storage scan (search for any matching gameId file)
    final docsDir = await getApplicationDocumentsDirectory();
    final romsDir = Directory('${docsDir.path}/roms');
    if (await romsDir.exists()) {
      final entities = romsDir.listSync();
      for (final entity in entities) {
        if (entity is File) {
          final filename = entity.uri.pathSegments.last;
          if (filename == game.id || filename.startsWith('${game.id}.')) {
            return entity.absolute.path;
          }
        }
      }
    }

    // 3. Bundled asset -> unpack to document storage with proper extension
    if (game.romPath.isNotEmpty) {
      try {
        final byteData = await rootBundle.load(game.romAssetPath);
        final bytes = byteData.buffer.asUint8List(
          byteData.offsetInBytes,
          byteData.lengthInBytes,
        );
        final ext = game.romPath.contains('.') ? '.${game.romPath.split('.').last}' : '.rom';
        final localFile = await getLocalRomFile(game.id, extension: ext);
        await localFile.writeAsBytes(bytes);
        return localFile.absolute.path;
      } catch (_) {}
    }

    return null;
  }

  /// Smart import processor for picked files with magic-byte validation and zip extraction
  Future<List<Game>> processImportedFile({
    required String filePath,
    required String fileName,
    required Uint8List bytes,
  }) async {
    final List<Game> importedGames = [];
    final ext = fileName.contains('.') ? fileName.split('.').last.toLowerCase() : '';

    // Handle RAR and 7Z archives with friendly guidance
    if (ext == 'rar') {
      throw const UnsupportedRomException(
        'Format RAR (.rar) menggunakan kompresi tertutup.\n\n'
        '💡 Tips: Silakan kompres folder/kumpulan ROM kamu ke format .ZIP (atau ekstrak foldernya lalu pilih file ROM langsung). '
        'Vemo mendukung multi-game .ZIP untuk mengekstrak dan mendeteksi banyak game sekaligus secara otomatis!',
      );
    }
    if (ext == '7z') {
      throw const UnsupportedRomException(
        'Format 7Z (.7z) belum didukung secara langsung.\n\n'
        '💡 Tips: Silakan gunakan format .ZIP untuk mem-pack kumpulan game kamu. '
        'Vemo akan langsung mendeteksi platform setiap game di dalam .ZIP secara otomatis!',
      );
    }

    // Validate header magic bytes
    if (!validateRomHeader(bytes, ext)) {
      throw UnsupportedRomException(
        'Header file $fileName tidak valid atau corrupt. Pastikan file adalah ROM utuh.',
      );
    }

    if (ext == 'zip') {
      try {
        final archive = ZipDecoder().decodeBytes(bytes);
        final List<ArchiveFile> consoleRomFiles = [];
        final Map<String, ArchiveFile> allFilesInZip = {};

        // 1. Inspect archive files
        for (final file in archive) {
          if (!file.isFile) continue;
          final innerName = file.name.replaceAll('\\', '/');
          
          // Security: Prevent Zip-Slip / Path Traversal attack
          if (innerName.contains('..') || innerName.startsWith('/')) {
            continue;
          }

          final innerBaseName = innerName.split('/').last;
          allFilesInZip[innerBaseName.toLowerCase()] = file;

          // Skip system/metadata junk files
          if (innerBaseName.startsWith('.') ||
              innerBaseName.startsWith('__MACOSX') ||
              innerBaseName.toLowerCase().endsWith('.txt') ||
              innerBaseName.toLowerCase().endsWith('.nfo') ||
              innerBaseName.toLowerCase().endsWith('.url')) {
            continue;
          }

          final innerExt = innerBaseName.contains('.')
              ? innerBaseName.split('.').last.toLowerCase()
              : '';

          if (_consoleExtensions.contains(innerExt)) {
            consoleRomFiles.add(file);
          }
        }

        // ── Case A: ZIP contains single or multiple Console ROMs -> Auto Extract! ──
        if (consoleRomFiles.isNotEmpty) {
          // Detect .cue sheets to bind associated .bin audio/data tracks together
          final Set<String> referencedBinNames = {};
          final List<ArchiveFile> cueFiles = [];
          final List<ArchiveFile> regularFiles = [];

          for (final f in consoleRomFiles) {
            final fName = f.name.replaceAll('\\', '/').split('/').last;
            final fExt = fName.contains('.') ? fName.split('.').last.toLowerCase() : '';
            if (fExt == 'cue') {
              cueFiles.add(f);
              try {
                final cueContent = f.content is List<int>
                    ? f.content as List<int>
                    : Uint8List.fromList((f.content as dynamic).toList());
                final cueText = String.fromCharCodes(cueContent);
                final matches = RegExp(r'FILE\s+["\x27]([^"\x27]+)["\x27]', caseSensitive: false).allMatches(cueText);
                for (final m in matches) {
                  final targetBin = m.group(1)?.replaceAll('\\', '/').split('/').last.toLowerCase();
                  if (targetBin != null) referencedBinNames.add(targetBin);
                }
              } catch (_) {}
            } else {
              regularFiles.add(f);
            }
          }

          // A1: Process CUE multi-disc/track sets
          for (final cueFile in cueFiles) {
            final cueName = cueFile.name.replaceAll('\\', '/').split('/').last;
            final cueBytes = cueFile.content is List<int>
                ? Uint8List.fromList(cueFile.content as List<int>)
                : Uint8List.fromList((cueFile.content as dynamic).toList());

            final gameId = 'user_${DateTime.now().millisecondsSinceEpoch}_${importedGames.length}';
            final docsDir = await getApplicationDocumentsDirectory();
            final gameDir = Directory('${docsDir.path}/roms/$gameId');
            if (!await gameDir.exists()) await gameDir.create(recursive: true);

            final targetCueFile = File('${gameDir.path}/$cueName');
            await targetCueFile.writeAsBytes(cueBytes);

            // Extract all referenced .bin tracks alongside the .cue file
            for (final binName in referencedBinNames) {
              final binArchiveFile = allFilesInZip[binName];
              if (binArchiveFile != null) {
                final binTarget = File('${gameDir.path}/$binName');
                final binBytes = binArchiveFile.content is List<int>
                    ? Uint8List.fromList(binArchiveFile.content as List<int>)
                    : Uint8List.fromList((binArchiveFile.content as dynamic).toList());
                await binTarget.writeAsBytes(binBytes);
              }
            }

            final baseName = cueName.contains('.')
                ? cueName.substring(0, cueName.lastIndexOf('.'))
                : cueName;
            final displayName = _formatTitle(baseName);

            final game = Game.fromRomFile(
              id: gameId,
              title: displayName,
              filePath: targetCueFile.path,
              fileSizeBytes: cueBytes.length,
              originalFileName: cueName,
            );
            importedGames.add(game);
          }

          // A2: Process Regular Standalone ROMs
          for (final romFile in regularFiles) {
            final innerName = romFile.name.replaceAll('\\', '/').split('/').last;
            final innerExt = innerName.contains('.') ? innerName.split('.').last.toLowerCase() : 'rom';

            // Skip .bin files that were already paired to a .cue sheet
            if (innerExt == 'bin' && referencedBinNames.contains(innerName.toLowerCase())) {
              continue;
            }

            final innerBytes = romFile.content is List<int>
                ? Uint8List.fromList(romFile.content as List<int>)
                : Uint8List.fromList((romFile.content as dynamic).toList());

            // Validate extracted ROM header
            if (!validateRomHeader(innerBytes, innerExt)) {
              continue; // skip corrupt sub-files
            }

            final gameId = 'user_${DateTime.now().millisecondsSinceEpoch}_${importedGames.length}';

            final savedFile = await getLocalRomFile(gameId, extension: '.$innerExt');
            await savedFile.writeAsBytes(innerBytes);

            final baseName = innerName.contains('.')
                ? innerName.substring(0, innerName.lastIndexOf('.'))
                : innerName;
            final displayName = _formatTitle(baseName);

            final game = Game.fromRomFile(
              id: gameId,
              title: displayName,
              filePath: savedFile.path,
              fileSizeBytes: innerBytes.length,
              originalFileName: innerName,
            );

            importedGames.add(game);
          }

          if (importedGames.isNotEmpty) return importedGames;
        }

        // ── Case B: Arcade ROM Set (e.g. mslug2.zip) ──
        final gameId = 'user_${DateTime.now().millisecondsSinceEpoch}';
        final savedFile = await getLocalRomFile(gameId, extension: '.zip');
        await savedFile.writeAsBytes(bytes);

        final baseName = fileName.contains('.')
            ? fileName.substring(0, fileName.lastIndexOf('.'))
            : fileName;
        final displayName = _formatTitle(baseName);

        final game = Game.fromRomFile(
          id: gameId,
          title: displayName,
          filePath: savedFile.path,
          fileSizeBytes: bytes.length,
          originalFileName: fileName,
        );

        importedGames.add(game);
        return importedGames;
      } catch (e) {
        if (e is UnsupportedRomException) rethrow;
        throw UnsupportedRomException('Gagal membaca arsip ZIP: $e');
      }
    }

    // ── Case C: Standard loose ROM file (.gba, .sfc, .nes, .md, etc.) ──
    final gameId = 'user_${DateTime.now().millisecondsSinceEpoch}';
    final accurateExt = ext.isNotEmpty ? '.$ext' : '.rom';
    final savedFile = await getLocalRomFile(gameId, extension: accurateExt);
    await savedFile.writeAsBytes(bytes);

    final baseName = fileName.contains('.')
        ? fileName.substring(0, fileName.lastIndexOf('.'))
        : fileName;
    final displayName = _formatTitle(baseName);

    final game = Game.fromRomFile(
      id: gameId,
      title: displayName,
      filePath: savedFile.path,
      fileSizeBytes: bytes.length,
      originalFileName: fileName,
    );

    importedGames.add(game);
    return importedGames;
  }

  /// Clean release tags like (USA), (Europe), [!], (Rev 1) and normalize casing
  String _formatTitle(String rawName) {
    // 1. Remove bracketed release/dump metadata e.g. (USA), (Europe), [!], (Rev 1)
    var clean = rawName.replaceAll(RegExp(r'\s*\([^)]*\)|\s*\[[^\]]*\]'), '');

    // 2. Handle inverted articles e.g. "Legend of Zelda, The" -> "The Legend of Zelda"
    if (clean.contains(', The')) {
      clean = 'The ${clean.replaceAll(', The', '')}';
    } else if (clean.contains(', the')) {
      clean = 'The ${clean.replaceAll(', the', '')}';
    }

    // 3. Normalize delimiters and excess whitespace
    clean = clean.replaceAll('_', ' ').replaceAll('-', ' ');
    clean = clean.replaceAll(RegExp(r'\s+'), ' ').trim();

    if (clean.isEmpty) clean = rawName;

    // 4. Proper Title Casing
    return clean
        .split(' ')
        .map((w) => w.isNotEmpty ? '${w[0].toUpperCase()}${w.substring(1)}' : w)
        .join(' ');
  }

  /// Directly attaches/associates a chosen ROM file to an existing game in the library.
  /// Atomically updates platform, core, aspectRatio, romSizeMB, and localRomPath in UserLibraryService.
  Future<Game> attachRomToGame(Game game, String fileName, Uint8List bytes) async {
    final ext = fileName.contains('.') ? fileName.split('.').last.toLowerCase() : '';

    // 1. Validate Container & Magic Bytes
    if (!validateRomHeader(bytes, ext)) {
      throw const UnsupportedRomException('File ROM rusak atau header tidak valid untuk sistem ini.');
    }

    // 2. Classify Console, Core, AspectRatio, and Extension
    String? platform;
    String? core;
    String aspectRatio = '4/3';

    if (ext == 'sfc' || ext == 'smc' || ext == 'fig') {
      platform = 'SNES';
      core = 'snes9x';
      aspectRatio = '4/3';
    } else if (ext == 'nes' || ext == 'fds' || ext == 'unf') {
      platform = 'NES';
      core = 'fceumm';
      aspectRatio = '4/3';
    } else if (ext == 'md' || ext == 'gen' || ext == 'smd' || ext == 'bin' || ext == 'sms' || ext == 'gg' || ext == 'sg') {
      platform = 'GENESIS';
      core = 'genesis_plus_gx';
      aspectRatio = '4/3';
    } else if (ext == 'gba') {
      platform = 'GBA';
      core = 'mgba';
      aspectRatio = '3/2';
    } else if (ext == 'gb' || ext == 'gbc') {
      platform = 'GB';
      core = 'mgba';
      aspectRatio = '10/9';
    } else if (ext == 'zip') {
      try {
        final archive = ZipDecoder().decodeBytes(bytes);
        for (final f in archive) {
          if (!f.isFile) continue;
          final innerExt = f.name.contains('.') ? f.name.split('.').last.toLowerCase() : '';
          if (_consoleExtensions.contains(innerExt)) {
            if (innerExt == 'gba') {
              platform = 'GBA';
              core = 'mgba';
              aspectRatio = '3/2';
            } else if (innerExt == 'gb' || innerExt == 'gbc') {
              platform = 'GB';
              core = 'mgba';
              aspectRatio = '10/9';
            } else if (innerExt == 'nes' || innerExt == 'fds' || innerExt == 'unf') {
              platform = 'NES';
              core = 'fceumm';
              aspectRatio = '4/3';
            } else if (innerExt == 'sfc' || innerExt == 'smc' || innerExt == 'fig') {
              platform = 'SNES';
              core = 'snes9x';
              aspectRatio = '4/3';
            } else {
              platform = 'GENESIS';
              core = 'genesis_plus_gx';
              aspectRatio = '4/3';
            }
            break;
          }
        }
      } catch (_) {}
    }

    if (platform == null || core == null) {
      if (ext == 'pce' || ext == 'cue' || ext == 'iso' || ext == 'chd') {
        throw const UnsupportedRomException('Format file (PS1/PCE) belum didukung pada rilis V1.');
      }
      throw const UnsupportedRomException('Format file ROM tidak dikenali sebagai konsol yang didukung.');
    }

    // 3. Transactional Disk Persistence: write new file first to temporary path
    final accurateExt = ext.isNotEmpty ? '.$ext' : '.rom';
    final docsDir = await getApplicationDocumentsDirectory();
    final romsDir = Directory('${docsDir.path}/roms');
    if (!await romsDir.exists()) {
      await romsDir.create(recursive: true);
    }
    final targetFile = File('${romsDir.path}/${game.id}$accurateExt');
    final tmpFile = File('${romsDir.path}/${game.id}.tmp_${DateTime.now().millisecondsSinceEpoch}');

    await tmpFile.writeAsBytes(bytes, flush: true);

    // 4. Remove previous conflicting local ROM files (except tmpFile)
    if (await romsDir.exists()) {
      final entities = romsDir.listSync();
      for (final entity in entities) {
        if (entity is File && entity.path != tmpFile.path) {
          final filename = entity.uri.pathSegments.last;
          if (filename == game.id || filename.startsWith('${game.id}.')) {
            try {
              await entity.delete();
            } catch (_) {}
          }
        }
      }
    }

    // Atomically commit tmpFile to targetFile
    await tmpFile.rename(targetFile.path);

    // 5. Construct updated Game object with mutated metadata
    final updatedGame = game.copyWith(
      platform: platform,
      core: core,
      aspectRatio: aspectRatio,
      romSizeMB: (bytes.length / (1024 * 1024)).ceil(),
      localRomPath: targetFile.absolute.path,
    );

    // 6. Persist to UserLibraryService
    await UserLibraryService().updateGame(updatedGame);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('rom_name_${game.id}', fileName);

    return updatedGame;
  }

  /// Completely deletes all local ROM files matching this game ID to avoid orphaned files.
  Future<void> removeLocalRom(String gameId) async {
    try {
      final docsDir = await getApplicationDocumentsDirectory();
      final romsDir = Directory('${docsDir.path}/roms');
      if (await romsDir.exists()) {
        final entities = romsDir.listSync();
        for (final entity in entities) {
          if (entity is File) {
            final filename = entity.uri.pathSegments.last;
            if (filename == gameId || filename.startsWith('$gameId.')) {
              try {
                await entity.delete();
              } catch (_) {}
            }
          }
        }
      }
    } catch (_) {}

    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('rom_name_$gameId');
  }
}
