import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/game.dart';
import '../services/audio_service.dart';
import '../services/rom_service.dart';
import '../services/haptic_service.dart';
import '../services/save_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/native_emulator_service.dart';
import '../services/controller_layout_service.dart';
import '../widgets/custom_controller_editor.dart';

/// Vemo Native C++ Libretro Emulator Screen
/// Direct 60 FPS GPU Texture rendering via SurfaceTexture (Zero WebView).
class EmulatorScreen extends StatefulWidget {
  final Game game;
  final int? loadSlot;

  const EmulatorScreen({
    super.key,
    required this.game,
    this.loadSlot,
  });

  @override
  State<EmulatorScreen> createState() => _EmulatorScreenState();
}

class _EmulatorScreenState extends State<EmulatorScreen> with WidgetsBindingObserver {
  final NativeEmulatorService _emulator = NativeEmulatorService();
  final HapticService _haptic = HapticService();
  final SaveService _saveService = SaveService();
  final ControllerLayoutService _layout = ControllerLayoutService();

  int? _textureId;
  bool _isLoading = true;
  bool _controlBarVisible = false;
  String? _errorMessage;
  int _videoFilterMode = 0; // 0: Smooth HD Bilinear, 1: Retro Scanlines CRT, 2: Crisp Pixel

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    AudioService().setInGameplay(true);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    _initNativeEmulator();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _emulator.stop();
    AudioService().setInGameplay(false);
    AudioService().resumeLobbyBgm();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.hidden) {
      _emulator.pause();
    } else if (state == AppLifecycleState.resumed) {
      _emulator.resume();
    }
  }

  Future<void> _initNativeEmulator() async {
    try {
      await _haptic.init();
      await _layout.init();

      // 1. Ensure ROM file path exists on disk
      final romPath = await RomService().getRomFilePath(widget.game);
      if (romPath == null || !await File(romPath).exists()) {
        if (mounted) {
          setState(() {
            _errorMessage = 'File ROM "${widget.game.title}" tidak ditemukan.\nSilakan impor file ROM ke HP.';
            _isLoading = false;
          });
        }
        return;
      }

      // 2. Determine native resolution (256x240 for NES, 240x160 for GBA, 256x224 for SNES, 320x224 for Genesis, 320x240 for PS1)
      int targetW = 256;
      int targetH = 240;
      final platformUpper = widget.game.platform.toUpperCase();
      if (platformUpper == 'GBA') {
        targetW = 240;
        targetH = 160;
      } else if (platformUpper == 'SNES') {
        targetW = 256;
        targetH = 224;
      } else if (platformUpper == 'GENESIS') {
        targetW = 320;
        targetH = 224;
      } else if (platformUpper == 'PS1' || platformUpper == 'PSX') {
        targetW = 320;
        targetH = 240;
      } else if (platformUpper == 'N64' || platformUpper == 'PSP') {
        targetW = 640;
        targetH = 480;
      }

      // 2b. Configure 3D Hardware Acceleration & Resolution Scaling
      final prefs = await SharedPreferences.getInstance();
      final is3d = platformUpper == 'PS1' || platformUpper == 'PSX' || platformUpper == 'N64' || platformUpper == 'PSP';
      final enable3dHw = prefs.getBool('enable_3d_hw') ?? is3d;
      final resolutionScale = prefs.getInt('internal_resolution_scale') ?? 1;

      await _emulator.configureEngine(
        enableHw: is3d ? enable3dHw : false,
        resolutionScale: is3d ? resolutionScale : 1,
        graphicsApi: 0,
        enableVrr: true,
      );

      // 3. Create Hardware SurfaceTexture via NativeEmulatorService
      final textureId = await _emulator.createTexture(width: targetW, height: targetH);
      if (textureId == null) {
        throw Exception('Gagal mengalokasikan SurfaceTexture hardware.');
      }

      // 4. Load ROM into Libretro Core
      final success = await _emulator.loadRom(widget.game, romPath);

      // 5. Apply saved video filter (Smooth HD Bilinear / Retro Scanlines)
      final filterMode = prefs.getInt('video_filter_mode') ?? 0;
      await _emulator.setVideoFilter(filterMode);

      if (mounted) {
        setState(() {
          _textureId = textureId;
          _videoFilterMode = filterMode;
          _isLoading = false;
          if (!success) {
            _errorMessage = 'Gagal memuat ROM ke Core Libretro (${widget.game.core}).';
          }
        });
      }

      // 6. Automatically load save state if requested from Game Detail Drawer
      if (success && widget.loadSlot != null) {
        await Future.delayed(const Duration(milliseconds: 200));
        final loaded = await _saveService.loadNativeState(widget.game.id, widget.loadSlot!);
        if (mounted && loaded) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'Progres Slot ${widget.loadSlot} berhasil dimuat!',
                    style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              backgroundColor: AppTheme.chassisCard,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 2),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _errorMessage = 'Inisialisasi Native Core Gagal: $e';
          _isLoading = false;
        });
      }
    }
  }

  void _sendKey(int keyCode, bool isPressed) {
    if (isPressed) {
      _haptic.triggerClick();
    }
    _emulator.sendKey(keyCode, isPressed);
  }

  void _showControllerEditorModal() {
    _haptic.triggerClick();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => CustomControllerEditorModal(
        platform: widget.game.platform,
        onLayoutChanged: () {
          if (mounted) setState(() {});
        },
      ),
    );
  }

  void _showSaveLoadSheet() async {
    _haptic.triggerClick();
    final slots = await _saveService.getSaveSlots(widget.game.id);

    if (!mounted) return;
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (modalContext, setModalState) {
          return Container(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
            decoration: BoxDecoration(
              color: AppTheme.chassisElevated,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              border: Border.all(color: AppTheme.borderHard, width: 1.5),
              boxShadow: const [VemoShadows.tactileModal],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Modal Handle
                Center(
                  child: Container(
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppTheme.borderHard,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.save_rounded, color: AppTheme.accentAmber, size: 20),
                        const SizedBox(width: 8),
                        Text(
                          'Slot Simpanan',
                          style: GoogleFonts.spaceGrotesk(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white54, size: 20),
                      onPressed: () => Navigator.pop(ctx),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // 3 Save Slots
                ...List.generate(3, (index) {
                  final slotNum = index + 1;
                  final slotInfo = slots[index];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: AppTheme.chassisCard,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: slotInfo.exists
                            ? AppTheme.accentAmber.withValues(alpha: 0.4)
                            : AppTheme.borderHard,
                        width: slotInfo.exists ? 1.5 : 1,
                      ),
                      boxShadow: const [VemoShadows.tactileSmall],
                    ),
                    child: Row(
                      children: [
                        Icon(
                          slotInfo.exists ? Icons.save_rounded : Icons.save_outlined,
                          color: slotInfo.exists ? AppTheme.accentAmber : Colors.white30,
                          size: 20,
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Slot $slotNum',
                                style: GoogleFonts.spaceGrotesk(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                slotInfo.exists && slotInfo.savedAt != null
                                    ? 'Tersimpan: ${_formatDate(slotInfo.savedAt!)}'
                                    : 'Kosong (Belum ada save)',
                                style: GoogleFonts.spaceGrotesk(
                                  color: slotInfo.exists ? Colors.white70 : Colors.white30,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                        // SAVE BUTTON
                        ElevatedButton.icon(
                          onPressed: () async {
                            HapticFeedback.mediumImpact();
                            final success = await _saveService.saveNativeState(widget.game.id, slotNum);
                            if (success) {
                              final updated = await _saveService.getSaveSlots(widget.game.id);
                              setModalState(() {
                                slots[index] = updated[index];
                              });
                              if (mounted) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text('State tersimpan di Slot $slotNum!'),
                                    backgroundColor: AppTheme.accentAmber,
                                    behavior: SnackBarBehavior.floating,
                                  ),
                                );
                              }
                            }
                          },
                          icon: const Icon(Icons.save_rounded, size: 14),
                          label: Text('Save', style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w700)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.chassisVoid,
                            foregroundColor: AppTheme.accentAmber,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            side: const BorderSide(color: AppTheme.accentAmber),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                        ),
                        const SizedBox(width: 6),
                        // LOAD BUTTON
                        ElevatedButton.icon(
                          onPressed: slotInfo.exists
                              ? () async {
                                  HapticFeedback.mediumImpact();
                                  Navigator.pop(ctx);
                                  await _saveService.loadNativeState(widget.game.id, slotNum);
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text('Memuat state dari Slot $slotNum!'),
                                        backgroundColor: AppTheme.accentTeal,
                                        behavior: SnackBarBehavior.floating,
                                      ),
                                    );
                                  }
                                }
                              : null,
                          icon: const Icon(Icons.restore_rounded, size: 14),
                          label: Text('Load', style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w700)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.accentAmber,
                            foregroundColor: AppTheme.chassisVoid,
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
              ],
            ),
          );
        },
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 1) return 'Baru saja';
    if (diff.inHours < 1) return '${diff.inMinutes} menit lalu';
    if (diff.inDays == 0) return 'Hari ini ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    return '${dt.day}/${dt.month}/${dt.year}';
  }

  Future<void> _handleResetGame() async {
    await _emulator.pause();
    if (!mounted) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.chassisCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Reset Game?',
          style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 16),
        ),
        content: Text(
          'Permainan akan di-restart dari awal seperti menekan tombol Reset fisik pada konsol.',
          style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Batal', style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontWeight: FontWeight.w600)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accentAmber,
              foregroundColor: AppTheme.chassisVoid,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: Text('Reset', style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await _emulator.reset();
      await _emulator.resume();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Konsol berhasil di-reset!'),
            backgroundColor: AppTheme.accentAmber,
            behavior: SnackBarBehavior.floating,
            duration: Duration(seconds: 2),
          ),
        );
      }
    } else {
      await _emulator.resume();
    }
  }

  Future<bool> _onWillPop() async {
    await _emulator.pause();
    if (!mounted) return false;
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.chassisCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          'Keluar dari Game?',
          style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontWeight: FontWeight.w700, fontSize: 16),
        ),
        content: Text(
          'Pastikan progres permainan sudah tersimpan di Slot Simpanan.',
          style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Lanjut Main', style: GoogleFonts.spaceGrotesk(color: AppTheme.accentAmber, fontWeight: FontWeight.w600)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red.shade800,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: Text('Keluar', style: GoogleFonts.spaceGrotesk(color: Colors.white, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
    if (shouldExit != true) {
      await _emulator.resume();
    }
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final shouldExit = await _onWillPop();
        if (shouldExit && context.mounted) {
          Navigator.of(context).pop();
        }
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF0D0D14),
        body: OrientationBuilder(
          builder: (context, orientation) {
            final isLandscape = orientation == Orientation.landscape;

            return Stack(
              children: [
                // ─── Main Layout ──────────────────────────────────────
                if (isLandscape)
                  _buildLandscapeLayout()
                else
                  _buildVerticalGameBoyLayout(),

                // ─── Floating Top Bar (Tap at center top to toggle) ───────────
                AnimatedPositioned(
                  duration: const Duration(milliseconds: 250),
                  curve: Curves.easeOut,
                  top: _controlBarVisible ? 0 : -70,
                  left: isLandscape ? 90 : 0,
                  right: isLandscape ? 90 : 0,
                  child: _ControlBar(
                    isLandscape: isLandscape,
                    gameName: widget.game.title,
                    platform: widget.game.platform,
                    onCustomize: _showControllerEditorModal,
                    onSaveLoad: _showSaveLoadSheet,
                    onReset: _handleResetGame,
                    onExit: () async {
                      if (await _onWillPop() && context.mounted) {
                        Navigator.of(context).pop();
                      }
                    },
                  ),
                ),

                // Tap trigger zone for Top Bar (Center Only — 100% Free of L/R Trigger collision)
                Positioned(
                  top: 0,
                  left: isLandscape ? 120 : 60,
                  right: isLandscape ? 120 : 60,
                  height: 32,
                  child: GestureDetector(
                    onTap: () {
                      _haptic.triggerClick();
                      setState(() => _controlBarVisible = !_controlBarVisible);
                    },
                    behavior: HitTestBehavior.translucent,
                    child: Center(
                      child: Container(
                        width: 44,
                        height: 4,
                        margin: const EdgeInsets.only(top: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: _controlBarVisible ? 0.35 : 0.12),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ),
                ),

                // ─── Loading Overlay ──────────────────────────────────
                if (_isLoading)
                  Container(
                    color: const Color(0xFF0D0D14),
                    child: Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const CircularProgressIndicator(
                            color: AppTheme.accentAmber,
                            strokeWidth: 2.5,
                          ),
                          const SizedBox(height: 20),
                          Text(
                            'Memuat ${widget.game.title} (Native ${widget.game.core})...',
                            style: const TextStyle(color: AppTheme.textSecondary, fontSize: 13),
                          ),
                        ],
                      ),
                    ),
                  ),

                // ─── Error Overlay ────────────────────────────────────
                if (_errorMessage != null)
                  Container(
                    color: const Color(0xFF0D0D14),
                    child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.warning_amber_rounded, color: AppTheme.accentAmber, size: 52),
                            const SizedBox(height: 16),
                            Text('Core Error', style: Theme.of(context).textTheme.titleLarge),
                            const SizedBox(height: 8),
                            Text(
                              _errorMessage!,
                              style: const TextStyle(color: AppTheme.textMuted),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 24),
                            ElevatedButton(
                              onPressed: () => Navigator.of(context).pop(),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.accentAmber,
                                foregroundColor: AppTheme.backgroundDeep,
                              ),
                              child: const Text('Kembali ke Library'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// 📱 Vertical Handheld "Game Boy" Layout (Portrait) with Zero-Dead-Gap CRT TV Bezel
  Widget _buildVerticalGameBoyLayout() {
    final aspect = widget.game.numericAspectRatio;
    final topPadding = MediaQuery.of(context).padding.top;

    return Column(
      children: [
        // ── 1. Upper Viewport: Retro CRT TV Bezel (Tight Zero-Dead-Gap) ──
        Container(
          margin: EdgeInsets.fromLTRB(12, topPadding > 0 ? topPadding + 4 : 8, 12, 6),
          decoration: BoxDecoration(
            color: AppTheme.chassisCard,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.borderHard, width: 1.5),
            boxShadow: const [VemoShadows.tactileCard],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // CRT Bezel Header with Power LED and Title
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 6,
                          height: 6,
                          decoration: const BoxDecoration(
                            color: AppTheme.ledPowerOn,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(color: AppTheme.ledPowerOn, blurRadius: 4),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'POWER',
                          style: GoogleFonts.spaceGrotesk(
                            color: Colors.white.withValues(alpha: 0.6),
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      widget.game.platform,
                      style: GoogleFonts.spaceGrotesk(
                        color: AppTheme.accentAmber.withValues(alpha: 0.7),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),

              // Game Viewport (Tight Aspect Ratio) — Render Layer Isolated
              RepaintBoundary(
                child: Container(
                  margin: const EdgeInsets.fromLTRB(6, 0, 6, 6),
                  decoration: BoxDecoration(
                    color: Colors.black,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black54, width: 1),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(9),
                    child: AspectRatio(
                      aspectRatio: aspect,
                      child: Stack(
                        children: [
                          Positioned.fill(
                            child: _textureId != null
                                ? Texture(
                                    textureId: _textureId!,
                                    filterQuality: _videoFilterMode == 2
                                        ? FilterQuality.none
                                        : FilterQuality.medium,
                                  )
                                : const SizedBox.shrink(),
                          ),
                          // Active CRT Scanlines & Phosphor Aperture Raster Overlay
                          if (_videoFilterMode == 1)
                            const Positioned.fill(
                              child: IgnorePointer(
                                child: CustomPaint(
                                  painter: CRTScanlinePainter(),
                                ),
                              ),
                            ),
                          // Subtle CRT Screen Vignette & Glass Bloom
                          Positioned.fill(
                            child: IgnorePointer(
                              child: Container(
                                decoration: BoxDecoration(
                                  gradient: RadialGradient(
                                    center: Alignment.center,
                                    radius: 1.05,
                                    colors: [
                                      Colors.transparent,
                                      Colors.black.withValues(
                                        alpha: _videoFilterMode == 1 ? 0.32 : 0.18,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),

        // ── 2. Lower Handheld Controller Chassis (Expanded & ClipRRect bounded) ──
        Expanded(
          child: RepaintBoundary(
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
                decoration: const BoxDecoration(
                  color: AppTheme.chassisElevated,
                  border: Border(top: BorderSide(color: AppTheme.borderHard, width: 1.5)),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Upper Shoulder Trigger Row (L & R Triggers + Layout Editor)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Transform.translate(
                            offset: Offset(
                              _layout.lTriggerOffsetX.clamp(-20.0, 40.0),
                              _layout.lTriggerOffsetY.clamp(-20.0, 20.0),
                            ),
                            child: _buildShoulderBtn('L', RetroKey.l),
                          ),
                          GestureDetector(
                            onTap: _showControllerEditorModal,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: AppTheme.chassisCard,
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: AppTheme.borderHard),
                                boxShadow: const [VemoShadows.tactileSmall],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.tune_rounded, color: AppTheme.accentAmber, size: 12),
                                  const SizedBox(width: 4),
                                  Text(
                                    'TATA LETAK',
                                    style: GoogleFonts.spaceGrotesk(
                                      color: AppTheme.accentAmber,
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Transform.translate(
                            offset: Offset(
                              (-_layout.rTriggerOffsetX).clamp(-40.0, 20.0),
                              _layout.rTriggerOffsetY.clamp(-20.0, 20.0),
                            ),
                            child: _buildShoulderBtn('R', RetroKey.r),
                          ),
                        ],
                      ),
                    ),

                    // Controller Main Cluster (D-Pad on left, Action buttons on right - strictly bounded)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Flexible(
                              child: Align(
                                alignment: Alignment.centerLeft,
                                child: Transform.translate(
                                  offset: Offset(
                                    _layout.dpadOffsetX.clamp(-40.0, 60.0),
                                    (-_layout.dpadOffsetY).clamp(-50.0, 50.0),
                                  ),
                                  child: _buildDPad(),
                                ),
                              ),
                            ),
                            Flexible(
                              child: Align(
                                alignment: Alignment.centerRight,
                                child: Transform.translate(
                                  offset: Offset(
                                    (-_layout.actionOffsetX).clamp(-60.0, 40.0),
                                    (-_layout.actionOffsetY).clamp(-50.0, 50.0),
                                  ),
                                  child: _buildActionCluster(),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    // Select, Save Slots & Start Center Row
                    Transform.translate(
                      offset: Offset(
                        _layout.menuDockOffsetX.clamp(-40.0, 40.0),
                        (-_layout.menuDockOffsetY).clamp(-20.0, 30.0),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildPillBtn('SELECT', RetroKey.select),
                          const SizedBox(width: 12),
                          GestureDetector(
                            onTap: _showSaveLoadSheet,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                              decoration: BoxDecoration(
                                color: AppTheme.accentAmber.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(color: AppTheme.accentAmber, width: 1.2),
                                boxShadow: const [VemoShadows.tactileSmall],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.save_rounded, color: AppTheme.accentAmber, size: 12),
                                  const SizedBox(width: 4),
                                  Text(
                                    'SLOTS',
                                    style: GoogleFonts.spaceGrotesk(
                                      color: AppTheme.accentAmber,
                                      fontSize: 9.5,
                                      fontWeight: FontWeight.w700,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          _buildPillBtn('START', RetroKey.start),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),

                    // Brand Confidentiality Footer
                    Text(
                      'Vera Creation • Dibuat dengan cinta',
                      style: GoogleFonts.spaceGrotesk(
                        color: Colors.white.withValues(alpha: 0.25),
                        fontSize: 9.5,
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  /// 🖥️ Landscape Layout (Fullscreen Widescreen with Floating Overlay)
  Widget _buildLandscapeLayout() {
    final aspect = widget.game.numericAspectRatio;

    return Stack(
      children: [
        // Centered Video Frame with CRT Overlay — Render Layer Isolated
        RepaintBoundary(
          child: Center(
            child: AspectRatio(
              aspectRatio: aspect,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: _textureId != null
                        ? Texture(
                            textureId: _textureId!,
                            filterQuality: _videoFilterMode == 2
                                ? FilterQuality.none
                                : FilterQuality.medium,
                          )
                        : const SizedBox.shrink(),
                  ),
                  if (_videoFilterMode == 1)
                    const Positioned.fill(
                      child: IgnorePointer(
                        child: CustomPaint(
                          painter: CRTScanlinePainter(),
                        ),
                      ),
                    ),
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: RadialGradient(
                            center: Alignment.center,
                            radius: 1.05,
                            colors: [
                              Colors.transparent,
                              Colors.black.withValues(
                                alpha: _videoFilterMode == 1 ? 0.32 : 0.18,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),

        // Left L Trigger
        Positioned(
          top: (14 + _layout.lTriggerOffsetY).clamp(4.0, 100.0),
          left: (16 + _layout.lTriggerOffsetX).clamp(8.0, 140.0),
          child: _buildShoulderBtn('L', RetroKey.l),
        ),

        // Right R Trigger
        Positioned(
          top: (14 + _layout.rTriggerOffsetY).clamp(4.0, 100.0),
          right: (16 - _layout.rTriggerOffsetX).clamp(8.0, 140.0),
          child: _buildShoulderBtn('R', RetroKey.r),
        ),

        // Left D-Pad
        Positioned(
          left: (20 + _layout.dpadOffsetX).clamp(8.0, 200.0),
          bottom: (24 + _layout.dpadOffsetY).clamp(8.0, 180.0),
          child: _buildDPad(),
        ),

        // Right Action Buttons
        Positioned(
          right: (20 - _layout.actionOffsetX).clamp(8.0, 200.0),
          bottom: (24 + _layout.actionOffsetY).clamp(8.0, 180.0),
          child: _buildActionCluster(),
        ),

        // Center Bottom Select, Slots & Start
        Positioned(
          bottom: (12 + _layout.menuDockOffsetY).clamp(4.0, 80.0),
          left: 0,
          right: 0,
          child: Transform.translate(
            offset: Offset(_layout.menuDockOffsetX.clamp(-80.0, 80.0), 0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildPillBtn('SELECT', RetroKey.select),
                const SizedBox(width: 12),
                GestureDetector(
                  onTap: _showSaveLoadSheet,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppTheme.accentAmber.withValues(alpha: 0.18),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.5), width: 1.2),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.save_rounded, color: AppTheme.accentAmber, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          'SLOTS',
                          style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.accentAmber,
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 0.8,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                _buildPillBtn('START', RetroKey.start),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // ─── Virtual Controls Components (Fast Path Sub-Millisecond & Bounded) ────

  Widget _buildPadArm({
    required IconData icon,
    required int key,
    required double width,
    required double height,
    required BorderRadius borderRadius,
    required double opacity,
  }) {
    return Listener(
      onPointerDown: (_) => _sendKey(key, true),
      onPointerUp: (_) => _sendKey(key, false),
      onPointerCancel: (_) => _sendKey(key, false),
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E2C).withValues(alpha: opacity),
          borderRadius: borderRadius,
        ),
        alignment: Alignment.center,
        child: Icon(
          icon,
          color: Colors.white.withValues(alpha: opacity * 0.9),
          size: (width < height ? width : height) * 0.65,
        ),
      ),
    );
  }

  /// Unified Tactile Cross D-Pad (Single unified chassis with center pivot recess)
  Widget _buildDPad() {
    final scale = _layout.scale.clamp(0.8, 1.25);
    final opacity = _layout.opacity.clamp(0.2, 1.0);
    final armW = 42.0 * scale;
    final armL = 40.0 * scale;
    final totalSize = armW + (armL * 2);

    return Container(
      width: totalSize,
      height: totalSize,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black.withValues(alpha: 0.25 * opacity),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Vertical Arm (Up / Down)
          Container(
            width: armW,
            height: totalSize,
            decoration: BoxDecoration(
              color: const Color(0xFF191926).withValues(alpha: opacity),
              borderRadius: BorderRadius.circular(10 * scale),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.15 * opacity),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.35 * opacity),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
          ),

          // Horizontal Arm (Left / Right)
          Container(
            width: totalSize,
            height: armW,
            decoration: BoxDecoration(
              color: const Color(0xFF191926).withValues(alpha: opacity),
              borderRadius: BorderRadius.circular(10 * scale),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.15 * opacity),
                width: 1.2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.35 * opacity),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
          ),

          // Center Pivot Recess (Concave circular thumb depression)
          Container(
            width: armW * 0.75,
            height: armW * 0.75,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF141420).withValues(alpha: opacity),
              border: Border.all(
                color: Colors.white.withValues(alpha: 0.08 * opacity),
                width: 1,
              ),
            ),
          ),

          // UP Touch Target
          Positioned(
            top: 0,
            left: (totalSize - armW) / 2,
            child: _buildPadArm(
              icon: Icons.keyboard_arrow_up_rounded,
              key: RetroKey.up,
              width: armW,
              height: armL + (armW * 0.2),
              borderRadius: BorderRadius.vertical(top: Radius.circular(10 * scale)),
              opacity: opacity,
            ),
          ),

          // DOWN Touch Target
          Positioned(
            bottom: 0,
            left: (totalSize - armW) / 2,
            child: _buildPadArm(
              icon: Icons.keyboard_arrow_down_rounded,
              key: RetroKey.down,
              width: armW,
              height: armL + (armW * 0.2),
              borderRadius: BorderRadius.vertical(bottom: Radius.circular(10 * scale)),
              opacity: opacity,
            ),
          ),

          // LEFT Touch Target
          Positioned(
            left: 0,
            top: (totalSize - armW) / 2,
            child: _buildPadArm(
              icon: Icons.keyboard_arrow_left_rounded,
              key: RetroKey.left,
              width: armL + (armW * 0.2),
              height: armW,
              borderRadius: BorderRadius.horizontal(left: Radius.circular(10 * scale)),
              opacity: opacity,
            ),
          ),

          // RIGHT Touch Target
          Positioned(
            right: 0,
            top: (totalSize - armW) / 2,
            child: _buildPadArm(
              icon: Icons.keyboard_arrow_right_rounded,
              key: RetroKey.right,
              width: armL + (armW * 0.2),
              height: armW,
              borderRadius: BorderRadius.horizontal(right: Radius.circular(10 * scale)),
              opacity: opacity,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionBtn(String label, int key, Color color, [double? customSize]) {
    final scale = _layout.scale.clamp(0.8, 1.25);
    final opacity = _layout.opacity.clamp(0.2, 1.0);
    final btnSize = customSize ?? (50.0 * scale);

    return Listener(
      onPointerDown: (_) => _sendKey(key, true),
      onPointerUp: (_) => _sendKey(key, false),
      onPointerCancel: (_) => _sendKey(key, false),
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: btnSize,
        height: btnSize,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(
            center: const Alignment(-0.2, -0.3),
            radius: 0.85,
            colors: [
              color.withValues(alpha: 0.45 * opacity),
              color.withValues(alpha: 0.18 * opacity),
            ],
          ),
          border: Border.all(
            color: color.withValues(alpha: 0.85 * opacity),
            width: 2.0 * scale,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.25 * opacity),
              blurRadius: 8 * scale,
              offset: Offset(0, 2 * scale),
            ),
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.4 * opacity),
              blurRadius: 4 * scale,
              offset: Offset(0, 3 * scale),
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: GoogleFonts.spaceGrotesk(
              color: Colors.white.withValues(alpha: opacity),
              fontWeight: FontWeight.w700,
              fontSize: (customSize != null ? customSize * 0.38 : 17 * scale),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildShoulderBtn(String label, int key) {
    final scale = _layout.scale.clamp(0.8, 1.25);
    final opacity = _layout.opacity.clamp(0.2, 1.0);

    return Listener(
      onPointerDown: (_) => _sendKey(key, true),
      onPointerUp: (_) => _sendKey(key, false),
      onPointerCancel: (_) => _sendKey(key, false),
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 68 * scale,
        height: 30 * scale,
        decoration: BoxDecoration(
          color: const Color(0xFF252538).withValues(alpha: opacity),
          borderRadius: BorderRadius.circular(8 * scale),
          border: Border.all(color: Colors.white.withValues(alpha: 0.18 * opacity), width: 1.2),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.3 * opacity),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Center(
          child: Text(
            label,
            style: GoogleFonts.spaceGrotesk(
              color: Colors.white.withValues(alpha: opacity),
              fontWeight: FontWeight.w700,
              fontSize: 12 * scale,
              letterSpacing: 1,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionCluster() {
    final scale = _layout.scale.clamp(0.8, 1.25);
    final isNes = widget.game.platform.toUpperCase() == 'NES' || widget.game.platform.toUpperCase() == 'GB';

    if (isNes) {
      // 2-Button classic layout (B and A)
      return SizedBox(
        width: 116 * scale,
        height: 56 * scale,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildActionBtn('B', RetroKey.b, Colors.amberAccent),
            SizedBox(width: 12 * scale),
            _buildActionBtn('A', RetroKey.a, Colors.redAccent),
          ],
        ),
      );
    }

    if (!_layout.isActionTilted) {
      // Flat Row Layout
      return SizedBox(
        width: 116 * scale,
        height: 112 * scale,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildActionBtn('Y', RetroKey.y, Colors.greenAccent),
                SizedBox(width: 12 * scale),
                _buildActionBtn('X', RetroKey.x, Colors.blueAccent),
              ],
            ),
            SizedBox(height: 8 * scale),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _buildActionBtn('B', RetroKey.b, Colors.amberAccent),
                SizedBox(width: 12 * scale),
                _buildActionBtn('A', RetroKey.a, Colors.redAccent),
              ],
            ),
          ],
        ),
      );
    }

    // Classic Diamond Tilted Layout (SNES / GBA)
    final opacity = _layout.opacity.clamp(0.2, 1.0);
    final platform = widget.game.platform.toUpperCase();

    return RepaintBoundary(
      child: Opacity(
        opacity: opacity,
        child: SizedBox(
          width: 140 * scale,
          height: 140 * scale,
          child: Stack(
            children: [
              if (platform == 'NES' || platform == 'GB' || platform == 'GBC') ...[
                // Classic 2-Button layout (B on left, A on right)
                Positioned(
                  bottom: 30 * scale,
                  left: 10 * scale,
                  child: _buildActionBtn('B', RetroKey.b, const Color(0xFFE94560), 48 * scale),
                ),
                Positioned(
                  top: 20 * scale,
                  right: 10 * scale,
                  child: _buildActionBtn('A', RetroKey.a, const Color(0xFFE94560), 48 * scale),
                ),
              ] else if (platform == 'GBA') ...[
                // GBA 2-Button layout angled
                Positioned(
                  bottom: 25 * scale,
                  left: 12 * scale,
                  child: _buildActionBtn('B', RetroKey.b, const Color(0xFF533483), 48 * scale),
                ),
                Positioned(
                  top: 20 * scale,
                  right: 12 * scale,
                  child: _buildActionBtn('A', RetroKey.a, const Color(0xFFE94560), 48 * scale),
                ),
              ] else ...[
                // SNES / Genesis 4-Button Diamond layout (A, B, X, Y)
                Positioned(
                  bottom: 0,
                  left: 46 * scale,
                  child: _buildActionBtn('B', RetroKey.b, const Color(0xFFFFCC00), 44 * scale),
                ),
                Positioned(
                  top: 46 * scale,
                  right: 0,
                  child: _buildActionBtn('A', RetroKey.a, const Color(0xFFE94560), 44 * scale),
                ),
                Positioned(
                  top: 0,
                  left: 46 * scale,
                  child: _buildActionBtn('X', RetroKey.x, const Color(0xFF00ADB5), 44 * scale),
                ),
                Positioned(
                  top: 46 * scale,
                  left: 0,
                  child: _buildActionBtn('Y', RetroKey.y, const Color(0xFF4E9F3D), 44 * scale),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPillBtn(String label, int key) {
    final scale = _layout.scale.clamp(0.8, 1.25);
    final opacity = _layout.opacity.clamp(0.2, 1.0);

    return Listener(
      onPointerDown: (_) => _sendKey(key, true),
      onPointerUp: (_) => _sendKey(key, false),
      onPointerCancel: (_) => _sendKey(key, false),
      behavior: HitTestBehavior.opaque,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 14 * scale, vertical: 6 * scale),
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E2E).withValues(alpha: opacity),
          borderRadius: BorderRadius.circular(14 * scale),
          border: Border.all(color: Colors.white.withValues(alpha: 0.2 * opacity), width: 1.2),
        ),
        child: Text(
          label,
          style: GoogleFonts.spaceGrotesk(
            color: Colors.white.withValues(alpha: opacity),
            fontSize: 9.5 * scale,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.1,
          ),
        ),
      ),
    );
  }
}

/// Floating Control Bar with Game Title, Quick Save/Load, Reset, Layout Settings & Exit button
class _ControlBar extends StatelessWidget {
  final bool isLandscape;
  final String gameName;
  final String platform;
  final VoidCallback onSaveLoad;
  final VoidCallback onCustomize;
  final VoidCallback onReset;
  final VoidCallback onExit;

  const _ControlBar({
    this.isLandscape = false,
    required this.gameName,
    required this.platform,
    required this.onSaveLoad,
    required this.onCustomize,
    required this.onReset,
    required this.onExit,
  });

  @override
  Widget build(BuildContext context) {
    final topPadding = MediaQuery.of(context).padding.top;

    return Padding(
      padding: EdgeInsets.fromLTRB(
        isLandscape ? 6 : 12,
        topPadding > 0 ? topPadding + 4 : 8,
        isLandscape ? 6 : 12,
        0,
      ),
      child: Container(
        height: isLandscape ? 44 : 48,
        decoration: BoxDecoration(
          color: const Color(0xF2161624),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.borderHard, width: 1.2),
          boxShadow: const [VemoShadows.tactileCard],
        ),
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70, size: 16),
              onPressed: onExit,
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                gameName,
                style: GoogleFonts.spaceGrotesk(
                  color: Colors.white,
                  fontSize: isLandscape ? 11.5 : 12.5,
                  fontWeight: FontWeight.w700,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            // Reset Console Button
            IconButton(
              icon: const Icon(Icons.restart_alt_rounded, color: Colors.orangeAccent, size: 17),
              tooltip: 'Reset Konsol',
              onPressed: onReset,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              constraints: const BoxConstraints(),
            ),
            const SizedBox(width: 4),
            // Custom Controller Button
            IconButton(
              icon: const Icon(Icons.tune_rounded, color: AppTheme.accentAmber, size: 16),
              tooltip: 'Tata Letak Tombol',
              onPressed: onCustomize,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              constraints: const BoxConstraints(),
            ),
            const SizedBox(width: 4),
            // Save / Load Quick Action Button in Top Bar
            IconButton(
              icon: const Icon(Icons.save_rounded, color: AppTheme.accentTeal, size: 17),
              tooltip: 'Slot Simpanan',
              onPressed: onSaveLoad,
              padding: const EdgeInsets.symmetric(horizontal: 4),
              constraints: const BoxConstraints(),
            ),
            const SizedBox(width: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: AppTheme.accentAmber.withValues(alpha: 0.18),
                borderRadius: BorderRadius.circular(6),
                border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.5)),
              ),
              child: Text(
                platform,
                style: GoogleFonts.spaceGrotesk(
                  color: AppTheme.accentAmber,
                  fontSize: 9,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Active CRT Scanline & Phosphor Bloom raster overlay
class CRTScanlinePainter extends CustomPainter {
  const CRTScanlinePainter();

  @override
  void paint(Canvas canvas, Size size) {
    final linePaint = Paint()
      ..color = Colors.black.withValues(alpha: 0.28)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;

    final phosphorTint = Paint()
      ..color = const Color(0x0600FF99)
      ..style = PaintingStyle.fill;

    // Faint phosphor glass tint
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), phosphorTint);

    // Precise horizontal CRT raster scanlines
    const double step = 2.5;
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), linePaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
