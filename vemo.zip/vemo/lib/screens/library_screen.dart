import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/game.dart';
import '../data/game_library.dart';
import '../widgets/game_card.dart';
import '../widgets/game_detail_drawer.dart';
import '../widgets/settings_modal.dart';
import '../widgets/vemo_tactile_logo.dart';
import '../services/audio_service.dart';
import '../services/user_library_service.dart';
import '../services/rom_service.dart';
import '../services/save_service.dart';


/// The main game library screen — carousel + platform filter.
class LibraryScreen extends StatefulWidget {
  const LibraryScreen({super.key});

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  String _selectedPlatform = 'SEMUA';
  int _carouselIndex = 0;
  bool _isGridView = false;
  bool _isLoading = true;
  List<Game> _allGames = [];
  final PageController _pageController = PageController(viewportFraction: 0.70);
  final UserLibraryService _library = UserLibraryService();

  List<Game> get _filteredGames {
    if (_selectedPlatform == 'SEMUA') return _allGames;
    return _allGames.where((g) => g.platform == _selectedPlatform).toList();
  }

  @override
  void initState() {
    super.initState();
    _loadLibrary();
  }

  Future<void> _loadLibrary() async {
    final games = await _library.getGames();
    if (mounted) setState(() { _allGames = games; _isLoading = false; });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        backgroundColor: AppTheme.backgroundDeep,
        body: Center(child: CircularProgressIndicator(color: AppTheme.accentAmber)),
      );
    }

    final games = _filteredGames;

    return Scaffold(
      backgroundColor: AppTheme.backgroundDeep,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(context),
            if (_allGames.isNotEmpty) _buildPlatformFilters(),
            const SizedBox(height: 10),
            Expanded(
              child: _allGames.isEmpty
                  ? _buildEmptyState()
                  : games.isEmpty
                      ? _buildEmptyCategoryState()
                      : _isGridView
                          ? _buildGameGrid(games)
                          : _buildCarouselView(games),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              // Tactile Text Logo: VEMO + BY VERA CREATION
              const VemoTactileLogo(),

              const Spacer(),

              // View Mode Toggle
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  setState(() => _isGridView = !_isGridView);
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  margin: const EdgeInsets.only(right: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.chassisElevated,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.2)),
                    boxShadow: const [VemoShadows.tactileSmall],
                  ),
                  child: Icon(
                    _isGridView ? Icons.view_carousel_rounded : Icons.grid_view_rounded,
                    color: AppTheme.accentAmber,
                    size: 18,
                  ),
                ),
              ),

              // Sound Toggle
              ValueListenableBuilder<bool>(
                valueListenable: AudioService().isMutedNotifier,
                builder: (context, isMuted, _) {
                  return GestureDetector(
                    onTap: () {
                      HapticFeedback.lightImpact();
                      AudioService().toggleMute();
                    },
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      margin: const EdgeInsets.only(right: 6),
                      decoration: BoxDecoration(
                        color: isMuted ? AppTheme.chassisElevated : AppTheme.accentAmber.withValues(alpha: 0.18),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: isMuted ? AppTheme.textMuted.withValues(alpha: 0.3) : AppTheme.accentAmber,
                          width: isMuted ? 1 : 1.5,
                        ),
                        boxShadow: const [VemoShadows.tactileSmall],
                      ),
                      child: Icon(
                        isMuted ? Icons.music_off_rounded : Icons.music_note_rounded,
                        color: isMuted ? AppTheme.textMuted : AppTheme.accentAmber,
                        size: 18,
                      ),
                    ),
                  );
                },
              ),

              // Panduan Download & Impor (Help Modal)
              GestureDetector(
                onTap: () {
                  HapticFeedback.lightImpact();
                  _showRomGuideModal();
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  margin: const EdgeInsets.only(right: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.chassisElevated,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.2)),
                    boxShadow: const [VemoShadows.tactileSmall],
                  ),
                  child: const Icon(Icons.help_outline_rounded, color: AppTheme.accentAmber, size: 18),
                ),
              ),

              // Settings icon
              GestureDetector(
                onTap: () => SettingsModal.show(context),
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppTheme.chassisElevated,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.2)),
                    boxShadow: const [VemoShadows.tactileSmall],
                  ),
                  child: const Icon(Icons.tune_rounded, color: AppTheme.accentAmber, size: 18),
                ),
              ),
            ],
          ),

          // ── Buka ROM banner — full width ──
          const SizedBox(height: 12),
          GestureDetector(
            onTap: _addGame,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppTheme.accentAmber.withValues(alpha: 0.20),
                    AppTheme.accentAmber.withValues(alpha: 0.06),
                  ],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.8), width: 1.5),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppTheme.accentAmber,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(Icons.add_rounded, color: AppTheme.chassisVoid, size: 16),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Tambah Game',
                          style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.accentAmber,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          'Pilih file ROM (.gba, .sfc, .nes, .zip) dari HP',
                          style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.textSecondary,
                            fontSize: 11,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: AppTheme.accentAmber, size: 18),
                ],
              ),
            ),
          ),
        ],
      ).animate().fadeIn(duration: 350.ms),
    );
  }


  /// Opens file picker to add one or multiple ROMs (or a multi-pack ZIP archive) to the library.
  Future<void> _addGame() async {
    HapticFeedback.selectionClick();
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: [
          'zip', 'rar', '7z',
          'nes', 'fds', 'unf',
          'sfc', 'smc', 'fig', 'swc',
          'gba', 'gb', 'gbc',
          'md', 'gen', 'smd', 'bin', 'sms', 'gg', 'sg',
          'chd', 'cue', 'pbp', 'iso', 'img',
          'z64', 'n64', 'v64',
        ],
        allowMultiple: true,
      );
      if (result == null || result.files.isEmpty) return;

      final validPickedFiles = result.files.where((f) => f.path != null).toList();
      if (validPickedFiles.isEmpty) return;

      // Show temporary processing notification for batch files
      if (validPickedFiles.length > 1 || validPickedFiles.any((f) => f.name.toLowerCase().endsWith('.zip'))) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(
                children: [
                  const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.accentAmber),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'Memindai & mengekstrak file ROM...',
                      style: GoogleFonts.spaceGrotesk(fontSize: 12, color: AppTheme.textPrimary),
                    ),
                  ),
                ],
              ),
              backgroundColor: AppTheme.chassisCard,
              behavior: SnackBarBehavior.floating,
              duration: const Duration(seconds: 1),
            ),
          );
        }
      }

      final List<Game> totalImportedGames = [];
      final List<String> errorMessages = [];

      for (final picked in validPickedFiles) {
        final path = picked.path!;
        final file = File(path);
        if (!await file.exists()) continue;

        try {
          final bytes = await file.readAsBytes();
          final fullName = picked.name;

          final games = await RomService().processImportedFile(
            filePath: path,
            fileName: fullName,
            bytes: bytes,
          );
          totalImportedGames.addAll(games);
        } catch (e) {
          final errStr = e is UnsupportedRomException ? e.message : 'Gagal memproses ${picked.name}: $e';
          errorMessages.add(errStr);
        }
      }

      if (totalImportedGames.isNotEmpty) {
        await _library.addGames(totalImportedGames);
        await _loadLibrary();
      }

      if (!mounted) return;

      if (totalImportedGames.isNotEmpty) {
        // Group by platform for clean summary
        final Map<String, int> counts = {};
        for (final g in totalImportedGames) {
          counts[g.platform] = (counts[g.platform] ?? 0) + 1;
        }
        final breakdown = counts.entries.map((e) => '${e.value} ${e.key}').join(', ');

        final successMsg = totalImportedGames.length == 1
            ? '${totalImportedGames.first.title} (${totalImportedGames.first.platform}) berhasil ditambahkan!'
            : '${totalImportedGames.length} game berhasil diimpor ($breakdown)!';

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.check_circle_rounded, color: AppTheme.accentAmber, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    successMsg,
                    style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.chassisCard,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 3),
          ),
        );
      } else if (errorMessages.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.info_outline_rounded, color: Colors.orangeAccent, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Tidak ditemukan file ROM yang didukung di dalam file yang dipilih.',
                    style: GoogleFonts.spaceGrotesk(fontSize: 12),
                  ),
                ),
              ],
            ),
            backgroundColor: AppTheme.chassisCard,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }

      // If there were explicit errors (like RAR upload prompt), display them prominently
      if (errorMessages.isNotEmpty && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: errorMessages.map((msg) => Text(
                msg,
                style: GoogleFonts.spaceGrotesk(fontSize: 11, color: Colors.white),
              )).toList(),
            ),
            backgroundColor: Colors.red.shade900,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 5),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        final errorText = e is UnsupportedRomException ? e.message : 'Gagal membuka file: $e';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.error_outline_rounded, color: Colors.white, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    errorText,
                    style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w500),
                  ),
                ),
              ],
            ),
            backgroundColor: Colors.red.shade800,
            behavior: SnackBarBehavior.floating,
            duration: const Duration(seconds: 4),
          ),
        );
      }
    }
  }

  /// Confirm + delete a game from the library.
  Future<void> _deleteGame(Game game) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.backgroundElevated,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Hapus Game',
            style: TextStyle(color: AppTheme.textPrimary, fontWeight: FontWeight.w700)),
        content: Text('${game.title} akan dihapus dari library.',
            style: const TextStyle(color: AppTheme.textMuted)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Batal', style: TextStyle(color: AppTheme.textMuted))),
          TextButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Hapus', style: TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    if (confirmed == true) {
      await RomService().removeLocalRom(game.id);
      await SaveService().deleteGameSaves(game.id);
      await _library.removeGame(game.id);
      await _loadLibrary();
      HapticFeedback.mediumImpact();
    }
  }

  /// Shows step-by-step ROM downloading & auto-unzipping guide for users (Retrostic.com).
  void _showRomGuideModal() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => Container(
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
        decoration: BoxDecoration(
          color: const Color(0xFF141420),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.3), width: 1.5),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Handle Bar
              Center(
                child: Container(
                  width: 36,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // Title
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Row(
                      children: [
                        const Icon(Icons.menu_book_rounded, color: AppTheme.accentAmber, size: 20),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            'Panduan Download Game & ROM',
                            style: GoogleFonts.spaceGrotesk(
                              color: Colors.white,
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, color: Colors.white54, size: 20),
                    onPressed: () => Navigator.pop(ctx),
                  ),
                ],
              ),
              const SizedBox(height: 14),

              // Recommended Site Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppTheme.chassisCard,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.4)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.public_rounded, color: AppTheme.accentAmber, size: 18),
                        const SizedBox(width: 6),
                        Text(
                          'Situs Rekomendasi:',
                          style: GoogleFonts.spaceGrotesk(color: Colors.white70, fontSize: 12),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'https://www.retrostic.com/',
                      style: GoogleFonts.spaceGrotesk(
                        color: AppTheme.accentAmber,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Menyediakan ribuan koleksi game GBA, SNES, NES, SEGA Genesis, Game Boy, dan Arcade.',
                      style: GoogleFonts.spaceGrotesk(color: Colors.white60, fontSize: 11),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),

              // 3 Easy Steps
              Text(
                '3 Langkah Mudah:',
                style: GoogleFonts.spaceGrotesk(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 8),
              _buildGuideStep('1', 'Download Game', 'Buka browser HP -> cari game di retrostic.com -> Klik tombol Download.'),
              _buildGuideStep('2', 'File Berupa .ZIP', 'File hasil unduhan biasanya berformat .zip di folder Download HP Anda.'),
              _buildGuideStep('3', 'Impor ke Vemo', 'Buka Vemo -> Tekan tombol "+ Tambah Game" -> Pilih file .zip tersebut.'),
              const SizedBox(height: 14),

              // Extraction Note
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AppTheme.chassisElevated,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.accentTeal.withValues(alpha: 0.3)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.auto_awesome_rounded, color: AppTheme.accentTeal, size: 16),
                        const SizedBox(width: 6),
                        Text(
                          'Ekstraksi Otomatis:',
                          style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.accentTeal,
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '• Game Konsol (GBA/SNES/NES/MD/GB): Vemo otomatis mengekstrak file ROM (.gba/.sfc/.nes) dari dalam .zip secara instan tanpa perlu aplikasi lain.\n\n'
                      '• Game Arcade: Vemo mempertahankan file .zip utuh agar siap dimainkan oleh engine Arcade.',
                      style: GoogleFonts.spaceGrotesk(color: Colors.white70, fontSize: 11, height: 1.4),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Close Button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.accentAmber,
                    foregroundColor: AppTheme.chassisVoid,
                    padding: const EdgeInsets.symmetric(vertical: 13),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () => Navigator.pop(ctx),
                  child: Text(
                    'Tutup Panduan',
                    style: GoogleFonts.spaceGrotesk(fontSize: 13, fontWeight: FontWeight.w700),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGuideStep(String number, String title, String desc) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 22,
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: AppTheme.accentAmber.withValues(alpha: 0.2),
              shape: BoxShape.circle,
              border: Border.all(color: AppTheme.accentAmber, width: 1.2),
            ),
            child: Text(
              number,
              style: GoogleFonts.spaceGrotesk(
                color: AppTheme.accentAmber,
                fontSize: 11,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: RichText(
              text: TextSpan(
                style: GoogleFonts.spaceGrotesk(color: Colors.white70, fontSize: 11, height: 1.3),
                children: [
                  TextSpan(
                    text: '$title: ',
                    style: GoogleFonts.spaceGrotesk(color: Colors.white, fontWeight: FontWeight.w700),
                  ),
                  TextSpan(text: desc),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: AppTheme.accentAmber.withValues(alpha: 0.12),
                shape: BoxShape.circle,
                border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.3), width: 2),
              ),
              child: const Icon(Icons.sports_esports_outlined,
                  color: AppTheme.accentAmber, size: 48),
            ),
            const SizedBox(height: 24),
            const Text('Library Kosong',
                style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 20,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            const Text(
              'Gunakan tombol Tambah Game di atas\nuntuk memilih file ROM dari perangkat Anda.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.textMuted, fontSize: 13, height: 1.6),
            ),
            const SizedBox(height: 8),
            const Text(
              'Format didukung: GBA, SNES, NES, Genesis',
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: AppTheme.accentAmber,
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5),
            ),
          ],
        ),
      ).animate().fadeIn(duration: 600.ms, delay: 200.ms).scale(begin: const Offset(0.9, 0.9)),
    );
  }

  Widget _buildEmptyCategoryState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: AppTheme.chassisCard,
                shape: BoxShape.circle,
                border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.4), width: 1.5),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: const Icon(Icons.sports_esports_outlined, color: AppTheme.accentAmber, size: 38),
            ),
            const SizedBox(height: 16),
            Text(
              'Belum ada game $_selectedPlatform',
              style: GoogleFonts.spaceGrotesk(
                color: AppTheme.textPrimary,
                fontSize: 15,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Gunakan tombol di bawah untuk menambahkan game $_selectedPlatform.',
              textAlign: TextAlign.center,
              style: GoogleFonts.spaceGrotesk(
                color: AppTheme.textSecondary,
                fontSize: 12,
                height: 1.4,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _addGame,
              icon: const Icon(Icons.add_rounded, size: 16),
              label: Text(
                'Tambah Game $_selectedPlatform',
                style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w700),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accentAmber,
                foregroundColor: AppTheme.chassisVoid,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPlatformFilters() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: kPlatformFilters.map((platform) {
            final isSelected = platform == _selectedPlatform;
            final color = (platform == 'SEMUA' || platform == 'ALL')
                ? AppTheme.accentAmber
                : AppTheme.platformColor(platform);
            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: GestureDetector(
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() {
                    _selectedPlatform = platform;
                    _carouselIndex = 0;
                    if (_pageController.hasClients) {
                      _pageController.jumpToPage(0);
                    }
                  });
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? color.withValues(alpha: 0.18)
                        : AppTheme.chassisCard,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: isSelected
                          ? color
                          : AppTheme.borderHard,
                      width: isSelected ? 1.5 : 1,
                    ),
                    boxShadow: const [VemoShadows.tactileSmall],
                  ),
                  child: Text(
                    platform,
                    style: GoogleFonts.spaceGrotesk(
                      color: isSelected ? color : AppTheme.textSecondary,
                      fontSize: 11,
                      fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildCarouselView(List<Game> games) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final availableHeight = constraints.maxHeight;
        final cardHeight = (availableHeight * 0.78).clamp(240.0, 380.0);
        final cardWidth = cardHeight * 0.72; // 3:4 golden cartridge ratio

        return Column(
          children: [
            Expanded(
              child: Center(
                child: SizedBox(
                  height: cardHeight,
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: games.length,
                    onPageChanged: (index) => setState(() => _carouselIndex = index),
                    itemBuilder: (context, index) {
                      final game = games[index];
                      final isActive = index == _carouselIndex;
                      return Center(
                        child: AnimatedScale(
                          scale: isActive ? 1.0 : 0.88,
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeOut,
                          child: SizedBox(
                            width: cardWidth,
                            height: cardHeight,
                            child: GameCard(
                              game: game,
                              isSelected: isActive,
                              onTap: () {
                                if (isActive) {
                                  GameDetailDrawer.show(context, game,
                                      onDelete: () => _deleteGame(game));
                                } else {
                                  _pageController.animateToPage(index,
                                      duration: const Duration(milliseconds: 300),
                                      curve: Curves.easeOut);
                                }
                              },
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            _buildCarouselIndicators(games),
            const SizedBox(height: 6),
          ],
        );
      },
    );
  }

  Widget _buildCarouselIndicators(List<Game> games) {
    if (games.length <= 1) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(games.length, (index) {
          final isActive = index == _carouselIndex;
          return AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: isActive ? 20 : 5,
            height: 5,
            margin: const EdgeInsets.symmetric(horizontal: 2.5),
            decoration: BoxDecoration(
              color: isActive
                  ? AppTheme.accentAmber
                  : AppTheme.textMuted.withValues(alpha: 0.4),
              borderRadius: BorderRadius.circular(3),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildGameGrid(List<Game> games) {
    final media = MediaQuery.of(context);
    final isLandscape = media.orientation == Orientation.landscape;
    final isTablet = media.size.shortestSide >= 600;

    final crossAxisCount = isLandscape
        ? (isTablet ? 5 : 3)
        : (isTablet ? 3 : 2);

    return Padding(
      padding: EdgeInsets.symmetric(horizontal: isTablet ? 32 : 20),
      child: GridView.builder(
        physics: const BouncingScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: crossAxisCount,
          crossAxisSpacing: 14,
          mainAxisSpacing: 14,
          childAspectRatio: isLandscape ? 0.72 : 0.70,
        ),
        itemCount: games.length,
        itemBuilder: (context, index) {
          return GameCard(
            game: games[index],
            isSelected: false,
            onTap: () => GameDetailDrawer.show(context, games[index],
                onDelete: () => _deleteGame(games[index])),
          );
        },
      ),
    );
  }
}
