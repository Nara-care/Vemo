import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../services/controller_layout_service.dart';
import '../services/haptic_service.dart';

enum ActiveDraggableCluster { none, dpad, action, lTrigger, rTrigger, menuDock }

/// 🎮 FPS-Style Visual Controller HUD Editor
/// Memungkinkan kustomisasi drag-and-drop tombol langsung di layar seperti PUBG Mobile / CoD Mobile,
/// mendukung multi-konsol (GBA, SNES, NES, SEGA), 3 Slot Simpanan (HP, Tablet, Claw),
/// serta batas aman (Safe Ergonomic Clamping) agar tombol tidak keluar layar.
class VisualControllerEditorScreen extends StatefulWidget {
  final String initialPlatform;

  const VisualControllerEditorScreen({
    super.key,
    this.initialPlatform = 'GBA',
  });

  @override
  State<VisualControllerEditorScreen> createState() => _VisualControllerEditorScreenState();
}

class _VisualControllerEditorScreenState extends State<VisualControllerEditorScreen> {
  final ControllerLayoutService _layout = ControllerLayoutService();
  final HapticService _haptic = HapticService();

  late String _currentPlatform;
  bool _isLandscapePreview = false;
  ActiveDraggableCluster _activeCluster = ActiveDraggableCluster.none;

  // Local working copy of slots
  late int _selectedSlotIndex;
  late List<ControllerSlotData> _workingSlots;

  @override
  void initState() {
    super.initState();
    _currentPlatform = widget.initialPlatform.toUpperCase();
    _selectedSlotIndex = _layout.activeSlotIndex;
    _workingSlots = _layout.slots.map((s) => s.clone()).toList();
  }

  ControllerSlotData get _activeSlot => _workingSlots[_selectedSlotIndex];

  void _triggerHapticTick() {
    _haptic.triggerClick();
  }

  void _saveAllChanges() async {
    _haptic.trigger();
    for (int i = 0; i < _workingSlots.length; i++) {
      _layout.slots[i] = _workingSlots[i].clone();
    }
    _layout.activeSlotIndex = _selectedSlotIndex;
    await _layout.save();

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(
            children: [
              const Icon(Icons.check_circle_rounded, color: AppTheme.accentAmber, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Tata letak tersimpan di ${_activeSlot.name}!',
                  style: GoogleFonts.spaceGrotesk(
                    fontWeight: FontWeight.w700,
                    color: Colors.white,
                    fontSize: 13,
                  ),
                ),
              ),
            ],
          ),
          backgroundColor: AppTheme.chassisCard,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: const BorderSide(color: AppTheme.accentAmber, width: 1.2),
          ),
          duration: const Duration(seconds: 2),
        ),
      );
      Navigator.pop(context, true);
    }
  }

  void _resetCurrentSlot() async {
    _haptic.trigger();
    final isTabletSlot = _selectedSlotIndex == 1;
    setState(() {
      if (isTabletSlot) {
        _workingSlots[_selectedSlotIndex] = ControllerSlotData(
          name: 'Slot 2 (Tablet / Layar Lebar)',
          scale: 1.15,
          opacity: 0.90,
          dpadOffsetX: 40.0,
          dpadOffsetY: 20.0,
          actionOffsetX: -40.0,
          actionOffsetY: 20.0,
          lTriggerOffsetX: 20.0,
          lTriggerOffsetY: 10.0,
          rTriggerOffsetX: -20.0,
          rTriggerOffsetY: 10.0,
          menuDockOffsetX: 0.0,
          menuDockOffsetY: 10.0,
          isActionTilted: true,
        );
      } else {
        _workingSlots[_selectedSlotIndex] = ControllerSlotData(
          name: _selectedSlotIndex == 0 ? 'Slot 1 (Standar HP)' : 'Slot 3 (Kustom / Claw)',
        );
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Slot ${_selectedSlotIndex + 1} dikembalikan ke posisi pabrik.',
          style: GoogleFonts.spaceGrotesk(fontSize: 12),
        ),
        backgroundColor: AppTheme.chassisElevated,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 1),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);

    return Scaffold(
      backgroundColor: AppTheme.chassisVoid,
      body: SafeArea(
        child: Column(
          children: [
            // ── Top Header Toolbar ──────────────────────────────────────────
            _buildTopToolbar(),

            // ── Main Interactive HUD Canvas ─────────────────────────────────
            Expanded(
              child: Stack(
                children: [
                  // Cyber Grid Background
                  Positioned.fill(
                    child: _buildGridBackground(),
                  ),

                  // Simulated Game Video Screen in Center
                  Center(
                    child: _buildMockupGameScreen(),
                  ),

                  // Safe Area Boundary Helper Guide
                  Positioned.fill(
                    child: IgnorePointer(
                      child: Container(
                        margin: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.06),
                            width: 1,
                          ),
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ),

                  // Interactive Draggable Clusters
                  if (_isLandscapePreview)
                    _buildLandscapeCanvasElements(media)
                  else
                    _buildPortraitCanvasElements(media),

                  // Active Cluster Floating Guide Tooltip
                  if (_activeCluster != ActiveDraggableCluster.none)
                    Positioned(
                      top: 12,
                      left: 0,
                      right: 0,
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppTheme.chassisVoid.withValues(alpha: 0.85),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: AppTheme.accentAmber, width: 1.2),
                            boxShadow: const [VemoShadows.tactileSmall],
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.open_with_rounded, color: AppTheme.accentAmber, size: 14),
                              const SizedBox(width: 6),
                              Text(
                                'Geser jari di layar untuk memindahkan ${_getClusterName(_activeCluster)}',
                                style: GoogleFonts.spaceGrotesk(
                                  color: Colors.white,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            // ── Bottom Tuning Panel (Size, Opacity, Formation, Save) ─────────
            _buildBottomTuningPanel(),
          ],
        ),
      ),
    );
  }

  String _getClusterName(ActiveDraggableCluster cluster) {
    switch (cluster) {
      case ActiveDraggableCluster.dpad:
        return 'D-Pad';
      case ActiveDraggableCluster.action:
        return 'Tombol Aksi (${_currentPlatform == 'SNES' ? 'X/Y/A/B' : 'A/B'})';
      case ActiveDraggableCluster.lTrigger:
        return 'Tombol L';
      case ActiveDraggableCluster.rTrigger:
        return 'Tombol R';
      case ActiveDraggableCluster.menuDock:
        return 'Select / Start / Slots';
      case ActiveDraggableCluster.none:
        return '';
    }
  }

  // ── Top Header Toolbar ─────────────────────────────────────────────────────
  Widget _buildTopToolbar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: const BoxDecoration(
        color: AppTheme.chassisElevated,
        border: Border(bottom: BorderSide(color: AppTheme.borderHard, width: 1.2)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70, size: 18),
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'HUD LAYOUT CUSTOMIZER',
                    style: GoogleFonts.spaceGrotesk(
                      color: AppTheme.accentAmber,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.2,
                    ),
                  ),
                  Text(
                    'Kustomisasi posisi tombol ala game FPS Mobile',
                    style: GoogleFonts.spaceGrotesk(color: Colors.white54, fontSize: 10),
                  ),
                ],
              ),
              const Spacer(),
              // Mode Preview Toggle (Portrait vs Landscape)
              GestureDetector(
                onTap: () {
                  _triggerHapticTick();
                  setState(() {
                    _isLandscapePreview = !_isLandscapePreview;
                  });
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _isLandscapePreview
                        ? AppTheme.accentAmber.withValues(alpha: 0.2)
                        : AppTheme.chassisCard,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _isLandscapePreview ? AppTheme.accentAmber : AppTheme.borderHard,
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        _isLandscapePreview ? Icons.screen_rotation_rounded : Icons.stay_current_portrait_rounded,
                        color: _isLandscapePreview ? AppTheme.accentAmber : Colors.white70,
                        size: 14,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        _isLandscapePreview ? 'Lanskap' : 'Potret',
                        style: GoogleFonts.spaceGrotesk(
                          color: _isLandscapePreview ? AppTheme.accentAmber : Colors.white70,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 8),
              // Save Button
              ElevatedButton.icon(
                onPressed: _saveAllChanges,
                icon: const Icon(Icons.check_rounded, size: 14),
                label: const Text('Simpan'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.accentAmber,
                  foregroundColor: AppTheme.chassisVoid,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  textStyle: GoogleFonts.spaceGrotesk(fontSize: 11, fontWeight: FontWeight.w800),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Sub Bar: Slot Selector & Platform Selector
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                // Slot Chips
                Text('SLOT:', style: GoogleFonts.spaceGrotesk(color: AppTheme.accentAmber, fontSize: 9.5, fontWeight: FontWeight.w800)),
                const SizedBox(width: 6),
                for (int i = 0; i < 3; i++) ...[
                  _buildSlotChip(i),
                  const SizedBox(width: 6),
                ],
                const SizedBox(width: 10),
                Container(width: 1, height: 16, color: AppTheme.borderHard),
                const SizedBox(width: 10),
                // Console Chips
                Text('KONSOL:', style: GoogleFonts.spaceGrotesk(color: Colors.white54, fontSize: 9.5, fontWeight: FontWeight.w800)),
                const SizedBox(width: 6),
                for (final p in ['GBA', 'SNES', 'NES', 'GENESIS']) ...[
                  _buildPlatformChip(p),
                  const SizedBox(width: 6),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSlotChip(int index) {
    final isSelected = _selectedSlotIndex == index;

    return GestureDetector(
      onTap: () {
        _triggerHapticTick();
        setState(() {
          _selectedSlotIndex = index;
          _activeCluster = ActiveDraggableCluster.none;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.accentAmber : AppTheme.chassisCard,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: isSelected ? AppTheme.accentAmber : AppTheme.borderHard,
            width: 1,
          ),
        ),
        child: Text(
          index == 0 ? 'Slot 1 (HP)' : index == 1 ? 'Slot 2 (Tablet)' : 'Slot 3 (Claw)',
          style: GoogleFonts.spaceGrotesk(
            color: isSelected ? AppTheme.chassisVoid : Colors.white70,
            fontSize: 10,
            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildPlatformChip(String platform) {
    final isSelected = _currentPlatform == platform;
    return GestureDetector(
      onTap: () {
        _triggerHapticTick();
        setState(() {
          _currentPlatform = platform;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.accentTeal.withValues(alpha: 0.2) : AppTheme.chassisCard,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: isSelected ? AppTheme.accentTeal : AppTheme.borderHard,
            width: 1,
          ),
        ),
        child: Text(
          platform,
          style: GoogleFonts.spaceGrotesk(
            color: isSelected ? AppTheme.accentTeal : Colors.white60,
            fontSize: 10,
            fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
          ),
        ),
      ),
    );
  }

  // ── Grid & Mockup Screen ───────────────────────────────────────────────────
  Widget _buildGridBackground() {
    return CustomPaint(
      painter: _CyberGridPainter(),
    );
  }

  Widget _buildMockupGameScreen() {
    final isGba = _currentPlatform == 'GBA';
    final aspect = isGba ? (3 / 2) : (4 / 3);

    return Container(
      width: _isLandscapePreview ? 260 : 200,
      height: (_isLandscapePreview ? 260 : 200) / aspect,
      decoration: BoxDecoration(
        color: const Color(0xFF0F1423),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppTheme.borderHard, width: 2),
        boxShadow: const [VemoShadows.tactileCard],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Cyber Screen Glow
          Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                colors: [
                  AppTheme.accentTeal.withValues(alpha: 0.15),
                  Colors.transparent,
                ],
                radius: 0.8,
              ),
            ),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.videogame_asset_rounded,
                color: AppTheme.accentAmber.withValues(alpha: 0.7),
                size: 28,
              ),
              const SizedBox(height: 4),
              Text(
                '$_currentPlatform GAME SCREEN',
                style: GoogleFonts.pressStart2p(
                  color: Colors.white70,
                  fontSize: 7.5,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                '(Area Gameplay Terlindungi)',
                style: GoogleFonts.spaceGrotesk(
                  color: Colors.white38,
                  fontSize: 9,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Portrait Canvas Elements (Draggable Clusters) ──────────────────────────
  Widget _buildPortraitCanvasElements(MediaQueryData media) {
    return Stack(
      children: [
        // L Trigger (Top Left)
        Positioned(
          top: 20 + _activeSlot.lTriggerOffsetY.clamp(-40.0, 40.0),
          left: 16 + _activeSlot.lTriggerOffsetX.clamp(-10.0, 100.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.lTrigger,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.lTriggerOffsetX = (_activeSlot.lTriggerOffsetX + dx).clamp(-10.0, 100.0);
                _activeSlot.lTriggerOffsetY = (_activeSlot.lTriggerOffsetY + dy).clamp(-40.0, 40.0);
              });
            },
            child: _buildPreviewShoulderBtn('L'),
          ),
        ),

        // R Trigger (Top Right)
        Positioned(
          top: 20 + _activeSlot.rTriggerOffsetY.clamp(-40.0, 40.0),
          right: 16 - _activeSlot.rTriggerOffsetX.clamp(-100.0, 10.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.rTrigger,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.rTriggerOffsetX = (_activeSlot.rTriggerOffsetX - dx).clamp(-100.0, 10.0);
                _activeSlot.rTriggerOffsetY = (_activeSlot.rTriggerOffsetY + dy).clamp(-40.0, 40.0);
              });
            },
            child: _buildPreviewShoulderBtn('R'),
          ),
        ),

        // D-Pad Cluster (Bottom Left)
        Positioned(
          bottom: 70 + _activeSlot.dpadOffsetY.clamp(-80.0, 100.0),
          left: 18 + _activeSlot.dpadOffsetX.clamp(-10.0, 120.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.dpad,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.dpadOffsetX = (_activeSlot.dpadOffsetX + dx).clamp(-10.0, 120.0);
                _activeSlot.dpadOffsetY = (_activeSlot.dpadOffsetY - dy).clamp(-80.0, 100.0);
              });
            },
            child: _buildPreviewDPad(),
          ),
        ),

        // Action Cluster (Bottom Right)
        Positioned(
          bottom: 70 + _activeSlot.actionOffsetY.clamp(-80.0, 100.0),
          right: 18 - _activeSlot.actionOffsetX.clamp(-120.0, 10.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.action,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.actionOffsetX = (_activeSlot.actionOffsetX - dx).clamp(-120.0, 10.0);
                _activeSlot.actionOffsetY = (_activeSlot.actionOffsetY - dy).clamp(-80.0, 100.0);
              });
            },
            child: _buildPreviewActionCluster(),
          ),
        ),

        // Menu Dock (Select / Start / Slots)
        Positioned(
          bottom: 16 + _activeSlot.menuDockOffsetY.clamp(-20.0, 60.0),
          left: 0,
          right: 0,
          child: Center(
            child: Transform.translate(
              offset: Offset(_activeSlot.menuDockOffsetX.clamp(-60.0, 60.0), 0),
              child: _buildDraggableClusterWrapper(
                cluster: ActiveDraggableCluster.menuDock,
                onPanUpdate: (dx, dy) {
                  setState(() {
                    _activeSlot.menuDockOffsetX = (_activeSlot.menuDockOffsetX + dx).clamp(-60.0, 60.0);
                    _activeSlot.menuDockOffsetY = (_activeSlot.menuDockOffsetY - dy).clamp(-20.0, 60.0);
                  });
                },
                child: _buildPreviewMenuDock(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Landscape Canvas Elements (Draggable Clusters) ─────────────────────────
  Widget _buildLandscapeCanvasElements(MediaQueryData media) {
    return Stack(
      children: [
        // L Trigger (Top Left)
        Positioned(
          top: 14 + _activeSlot.lTriggerOffsetY.clamp(-20.0, 60.0),
          left: 20 + _activeSlot.lTriggerOffsetX.clamp(-10.0, 120.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.lTrigger,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.lTriggerOffsetX = (_activeSlot.lTriggerOffsetX + dx).clamp(-10.0, 120.0);
                _activeSlot.lTriggerOffsetY = (_activeSlot.lTriggerOffsetY + dy).clamp(-20.0, 60.0);
              });
            },
            child: _buildPreviewShoulderBtn('L'),
          ),
        ),

        // R Trigger (Top Right)
        Positioned(
          top: 14 + _activeSlot.rTriggerOffsetY.clamp(-20.0, 60.0),
          right: 20 - _activeSlot.rTriggerOffsetX.clamp(-120.0, 10.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.rTrigger,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.rTriggerOffsetX = (_activeSlot.rTriggerOffsetX - dx).clamp(-120.0, 10.0);
                _activeSlot.rTriggerOffsetY = (_activeSlot.rTriggerOffsetY + dy).clamp(-20.0, 60.0);
              });
            },
            child: _buildPreviewShoulderBtn('R'),
          ),
        ),

        // D-Pad Cluster (Bottom Left)
        Positioned(
          bottom: 24 + _activeSlot.dpadOffsetY.clamp(-40.0, 120.0),
          left: 24 + _activeSlot.dpadOffsetX.clamp(-10.0, 160.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.dpad,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.dpadOffsetX = (_activeSlot.dpadOffsetX + dx).clamp(-10.0, 160.0);
                _activeSlot.dpadOffsetY = (_activeSlot.dpadOffsetY - dy).clamp(-40.0, 120.0);
              });
            },
            child: _buildPreviewDPad(),
          ),
        ),

        // Action Cluster (Bottom Right)
        Positioned(
          bottom: 24 + _activeSlot.actionOffsetY.clamp(-40.0, 120.0),
          right: 24 - _activeSlot.actionOffsetX.clamp(-160.0, 10.0),
          child: _buildDraggableClusterWrapper(
            cluster: ActiveDraggableCluster.action,
            onPanUpdate: (dx, dy) {
              setState(() {
                _activeSlot.actionOffsetX = (_activeSlot.actionOffsetX - dx).clamp(-160.0, 10.0);
                _activeSlot.actionOffsetY = (_activeSlot.actionOffsetY - dy).clamp(-40.0, 120.0);
              });
            },
            child: _buildPreviewActionCluster(),
          ),
        ),

        // Menu Dock (Bottom Center)
        Positioned(
          bottom: 12 + _activeSlot.menuDockOffsetY.clamp(-10.0, 50.0),
          left: 0,
          right: 0,
          child: Center(
            child: Transform.translate(
              offset: Offset(_activeSlot.menuDockOffsetX.clamp(-80.0, 80.0), 0),
              child: _buildDraggableClusterWrapper(
                cluster: ActiveDraggableCluster.menuDock,
                onPanUpdate: (dx, dy) {
                  setState(() {
                    _activeSlot.menuDockOffsetX = (_activeSlot.menuDockOffsetX + dx).clamp(-80.0, 80.0);
                    _activeSlot.menuDockOffsetY = (_activeSlot.menuDockOffsetY - dy).clamp(-10.0, 50.0);
                  });
                },
                child: _buildPreviewMenuDock(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Draggable Wrapper with Glowing Neon Halo Bounding Box ───────────────────
  Widget _buildDraggableClusterWrapper({
    required ActiveDraggableCluster cluster,
    required void Function(double dx, double dy) onPanUpdate,
    required Widget child,
  }) {
    final isSelected = _activeCluster == cluster;

    return GestureDetector(
      onTap: () {
        _triggerHapticTick();
        setState(() {
          _activeCluster = cluster;
        });
      },
      onPanStart: (_) {
        _triggerHapticTick();
        setState(() {
          _activeCluster = cluster;
        });
      },
      onPanUpdate: (details) {
        onPanUpdate(details.delta.dx, details.delta.dy);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppTheme.accentAmber : Colors.transparent,
            width: isSelected ? 1.8 : 0,
          ),
          color: isSelected ? AppTheme.accentAmber.withValues(alpha: 0.10) : Colors.transparent,
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: AppTheme.accentAmber.withValues(alpha: 0.25),
                    blurRadius: 10,
                    spreadRadius: 2,
                  ),
                ]
              : [],
        ),
        child: child,
      ),
    );
  }

  // ── Preview Button Cluster Renderers ───────────────────────────────────────
  Widget _buildPreviewDPad() {
    final scale = _activeSlot.scale;
    final opacity = _activeSlot.opacity;
    final armW = 40.0 * scale;
    final armL = 38.0 * scale;
    final totalSize = armW + (armL * 2);

    return Container(
      width: totalSize,
      height: totalSize,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Colors.black.withValues(alpha: 0.25 * opacity),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Vertical Arm
          Container(
            width: armW,
            height: totalSize,
            decoration: BoxDecoration(
              color: const Color(0xFF191926).withValues(alpha: opacity),
              borderRadius: BorderRadius.circular(10 * scale),
              border: Border.all(color: Colors.white.withValues(alpha: 0.2 * opacity), width: 1.2),
            ),
          ),
          // Horizontal Arm
          Container(
            width: totalSize,
            height: armW,
            decoration: BoxDecoration(
              color: const Color(0xFF191926).withValues(alpha: opacity),
              borderRadius: BorderRadius.circular(10 * scale),
              border: Border.all(color: Colors.white.withValues(alpha: 0.2 * opacity), width: 1.2),
            ),
          ),
          // Center Recess
          Container(
            width: armW * 0.75,
            height: armW * 0.75,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF141420).withValues(alpha: opacity),
            ),
          ),
          // Arrow Icons
          Positioned(
            top: 6 * scale,
            child: Icon(Icons.keyboard_arrow_up_rounded, color: Colors.white.withValues(alpha: opacity), size: 22 * scale),
          ),
          Positioned(
            bottom: 6 * scale,
            child: Icon(Icons.keyboard_arrow_down_rounded, color: Colors.white.withValues(alpha: opacity), size: 22 * scale),
          ),
          Positioned(
            left: 6 * scale,
            child: Icon(Icons.keyboard_arrow_left_rounded, color: Colors.white.withValues(alpha: opacity), size: 22 * scale),
          ),
          Positioned(
            right: 6 * scale,
            child: Icon(Icons.keyboard_arrow_right_rounded, color: Colors.white.withValues(alpha: opacity), size: 22 * scale),
          ),
        ],
      ),
    );
  }

  Widget _buildPreviewActionCluster() {
    final scale = _activeSlot.scale;
    final opacity = _activeSlot.opacity;
    final isNes = _currentPlatform == 'NES';
    final isSnes = _currentPlatform == 'SNES' || _currentPlatform == 'GENESIS';

    if (isNes) {
      // 2 Buttons Horizontal
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildActionButton('B', const Color(0xFFFFCC00), 46 * scale, opacity),
          SizedBox(width: 14 * scale),
          _buildActionButton('A', const Color(0xFFE94560), 46 * scale, opacity),
        ],
      );
    }

    if (isSnes && _activeSlot.isActionTilted) {
      // SNES Diamond 4-Button
      final boxSize = 136.0 * scale;
      final btnSize = 42.0 * scale;

      return SizedBox(
        width: boxSize,
        height: boxSize,
        child: Stack(
          children: [
            Positioned(
              bottom: 0,
              left: (boxSize - btnSize) / 2,
              child: _buildActionButton('B', const Color(0xFFFFCC00), btnSize, opacity),
            ),
            Positioned(
              top: (boxSize - btnSize) / 2,
              right: 0,
              child: _buildActionButton('A', const Color(0xFFE94560), btnSize, opacity),
            ),
            Positioned(
              top: 0,
              left: (boxSize - btnSize) / 2,
              child: _buildActionButton('X', const Color(0xFF00ADB5), btnSize, opacity),
            ),
            Positioned(
              top: (boxSize - btnSize) / 2,
              left: 0,
              child: _buildActionButton('Y', const Color(0xFF4E9F3D), btnSize, opacity),
            ),
          ],
        ),
      );
    }

    // GBA Angled 2-Button / Flat
    if (_activeSlot.isActionTilted) {
      final boxSize = 120.0 * scale;
      final btnSize = 46.0 * scale;
      return SizedBox(
        width: boxSize,
        height: boxSize,
        child: Stack(
          children: [
            Positioned(
              bottom: 10 * scale,
              left: 10 * scale,
              child: _buildActionButton('B', const Color(0xFF533483), btnSize, opacity),
            ),
            Positioned(
              top: 10 * scale,
              right: 10 * scale,
              child: _buildActionButton('A', const Color(0xFFE94560), btnSize, opacity),
            ),
          ],
        ),
      );
    }

    // Flat Horizontal Row
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildActionButton('B', const Color(0xFF533483), 46 * scale, opacity),
        SizedBox(width: 14 * scale),
        _buildActionButton('A', const Color(0xFFE94560), 46 * scale, opacity),
      ],
    );
  }

  Widget _buildActionButton(String label, Color color, double size, double opacity) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(
          center: const Alignment(-0.2, -0.3),
          radius: 0.85,
          colors: [
            color.withValues(alpha: 0.5 * opacity),
            color.withValues(alpha: 0.2 * opacity),
          ],
        ),
        border: Border.all(color: color.withValues(alpha: 0.9 * opacity), width: 2),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.25 * opacity),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Center(
        child: Text(
          label,
          style: GoogleFonts.spaceGrotesk(
            color: Colors.white.withValues(alpha: opacity),
            fontWeight: FontWeight.w800,
            fontSize: size * 0.40,
          ),
        ),
      ),
    );
  }

  Widget _buildPreviewShoulderBtn(String label) {
    final scale = _activeSlot.scale;
    final opacity = _activeSlot.opacity;

    return Container(
      width: 66 * scale,
      height: 30 * scale,
      decoration: BoxDecoration(
        color: const Color(0xFF252538).withValues(alpha: opacity),
        borderRadius: BorderRadius.circular(8 * scale),
        border: Border.all(color: Colors.white.withValues(alpha: 0.25 * opacity), width: 1.2),
        boxShadow: const [VemoShadows.tactileSmall],
      ),
      child: Center(
        child: Text(
          label,
          style: GoogleFonts.spaceGrotesk(
            color: Colors.white.withValues(alpha: opacity),
            fontWeight: FontWeight.w700,
            fontSize: 12 * scale,
            letterSpacing: 1.2,
          ),
        ),
      ),
    );
  }

  Widget _buildPreviewMenuDock() {
    final scale = _activeSlot.scale;
    final opacity = _activeSlot.opacity;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10 * scale, vertical: 4 * scale),
      decoration: BoxDecoration(
        color: AppTheme.chassisCard.withValues(alpha: opacity),
        borderRadius: BorderRadius.circular(14 * scale),
        border: Border.all(color: AppTheme.borderHard, width: 1.2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildPillText('SELECT', scale, opacity),
          SizedBox(width: 8 * scale),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 8 * scale, vertical: 3 * scale),
            decoration: BoxDecoration(
              color: AppTheme.accentAmber.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(8 * scale),
              border: Border.all(color: AppTheme.accentAmber, width: 1),
            ),
            child: Text(
              'SLOTS',
              style: GoogleFonts.spaceGrotesk(
                color: AppTheme.accentAmber,
                fontSize: 8.5 * scale,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          SizedBox(width: 8 * scale),
          _buildPillText('START', scale, opacity),
        ],
      ),
    );
  }

  Widget _buildPillText(String label, double scale, double opacity) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10 * scale, vertical: 4 * scale),
      decoration: BoxDecoration(
        color: const Color(0xFF1E1E2E).withValues(alpha: opacity),
        borderRadius: BorderRadius.circular(10 * scale),
        border: Border.all(color: Colors.white.withValues(alpha: 0.2 * opacity), width: 1),
      ),
      child: Text(
        label,
        style: GoogleFonts.spaceGrotesk(
          color: Colors.white.withValues(alpha: opacity),
          fontSize: 8.5 * scale,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  // ── Bottom Tuning Panel (Size, Opacity, Formation, Reset) ──────────────────
  Widget _buildBottomTuningPanel() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      decoration: const BoxDecoration(
        color: AppTheme.chassisElevated,
        border: Border(top: BorderSide(color: AppTheme.borderHard, width: 1.5)),
        boxShadow: [VemoShadows.tactileModal],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Sliders Row
          Row(
            children: [
              // Scale Slider
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Ukuran Tombol', style: GoogleFonts.spaceGrotesk(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600)),
                        Text('${(_activeSlot.scale * 100).round()}%', style: GoogleFonts.spaceGrotesk(color: AppTheme.accentAmber, fontSize: 11, fontWeight: FontWeight.w800)),
                      ],
                    ),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: AppTheme.accentAmber,
                        inactiveTrackColor: AppTheme.chassisVoid,
                        thumbColor: AppTheme.accentAmber,
                        trackHeight: 3.5,
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                      ),
                      child: Slider(
                        value: _activeSlot.scale.clamp(0.75, 1.40),
                        min: 0.75,
                        max: 1.40,
                        divisions: 13,
                        onChanged: (val) {
                          setState(() {
                            _activeSlot.scale = val;
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 16),
              // Opacity Slider
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Transparansi', style: GoogleFonts.spaceGrotesk(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w600)),
                        Text('${(_activeSlot.opacity * 100).round()}%', style: GoogleFonts.spaceGrotesk(color: AppTheme.accentAmber, fontSize: 11, fontWeight: FontWeight.w800)),
                      ],
                    ),
                    SliderTheme(
                      data: SliderTheme.of(context).copyWith(
                        activeTrackColor: AppTheme.accentAmber,
                        inactiveTrackColor: AppTheme.chassisVoid,
                        thumbColor: AppTheme.accentAmber,
                        trackHeight: 3.5,
                        thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
                      ),
                      child: Slider(
                        value: _activeSlot.opacity.clamp(0.20, 1.0),
                        min: 0.20,
                        max: 1.0,
                        divisions: 16,
                        onChanged: (val) {
                          setState(() {
                            _activeSlot.opacity = val;
                          });
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),

          const SizedBox(height: 6),

          // Toggles & Actions Row
          Row(
            children: [
              // Formation Toggle
              Expanded(
                child: GestureDetector(
                  onTap: () {
                    _triggerHapticTick();
                    setState(() {
                      _activeSlot.isActionTilted = !_activeSlot.isActionTilted;
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: AppTheme.chassisCard,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.borderHard),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          _activeSlot.isActionTilted ? Icons.change_history_rounded : Icons.crop_square_rounded,
                          color: AppTheme.accentAmber,
                          size: 14,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          _activeSlot.isActionTilted ? 'Formasi: Miring / Diamond' : 'Formasi: Datar / Arcade',
                          style: GoogleFonts.spaceGrotesk(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w600),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              // Reset Slot Button
              OutlinedButton.icon(
                onPressed: _resetCurrentSlot,
                icon: const Icon(Icons.restart_alt_rounded, size: 14),
                label: const Text('Reset Slot'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white70,
                  side: const BorderSide(color: AppTheme.borderHard),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  textStyle: GoogleFonts.spaceGrotesk(fontSize: 10.5, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),

          const SizedBox(height: 4),

          // Vera Creation Confidentiality Footer
          Text(
            'Vera Creation • Dibuat dengan cinta',
            style: GoogleFonts.spaceGrotesk(
              color: Colors.white.withValues(alpha: 0.25),
              fontSize: 9,
              letterSpacing: 0.3,
            ),
          ),
        ],
      ),
    );
  }
}

/// Custom Painter for Cyber Mesh Grid Background
class _CyberGridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFF1E2235).withValues(alpha: 0.4)
      ..strokeWidth = 0.6;

    const step = 24.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
