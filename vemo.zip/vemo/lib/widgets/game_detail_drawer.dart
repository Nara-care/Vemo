import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:file_picker/file_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/game.dart';
import '../services/save_service.dart';
import '../services/rom_service.dart';
import '../screens/emulator_screen.dart';

/// Bottom sheet showing game details and play CTA.
class GameDetailDrawer extends StatefulWidget {
  final Game game;
  final VoidCallback? onDelete;
  final VoidCallback? onGameUpdated;

  const GameDetailDrawer({
    super.key,
    required this.game,
    this.onDelete,
    this.onGameUpdated,
  });

  static Future<void> show(BuildContext context, Game game, {VoidCallback? onDelete, VoidCallback? onGameUpdated}) {
    HapticFeedback.mediumImpact();
    return showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => GameDetailDrawer(
        game: game,
        onDelete: onDelete,
        onGameUpdated: onGameUpdated,
      ),
    );
  }

  @override
  State<GameDetailDrawer> createState() => _GameDetailDrawerState();
}

class _GameDetailDrawerState extends State<GameDetailDrawer> {
  final SaveService _saveService = SaveService();
  final RomService _romService = RomService();
  List<SaveSlotInfo> _saveSlots = [];
  bool _loadingSaves = true;
  bool _isRomAvailable = false;
  bool _checkingRom = true;
  bool _isLaunching = false;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final slots = await _saveService.getSaveSlots(widget.game.id);
    // User-library games always have ROM ready (localRomPath is set)
    final romReady = widget.game.hasRom
        ? true
        : await _romService.isRomAvailable(widget.game);
    if (mounted) {
      setState(() {
        _saveSlots = slots;
        _loadingSaves = false;
        _isRomAvailable = romReady;
        _checkingRom = false;
      });
    }
  }

  Future<void> _pickRomFile() async {
    HapticFeedback.selectionClick();
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: [
          'zip',
          'nes', 'fds', 'unf',
          'sfc', 'smc', 'fig',
          'gba', 'gb', 'gbc',
          'md', 'gen', 'smd', 'bin', 'sms', 'gg', 'sg',
        ],
        allowMultiple: false,
      );

      if (result != null && result.files.single.path != null) {
        final file = File(result.files.single.path!);
        final bytes = await file.readAsBytes();
        final fileName = result.files.single.name;
        try {
          final updatedGame = await RomService().attachRomToGame(
            widget.game,
            fileName,
            bytes,
          );

          widget.onGameUpdated?.call();
          if (mounted) {
            setState(() {
              _isRomAvailable = true;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Row(
                  children: [
                    const Icon(Icons.check_circle_rounded, color: AppTheme.accentAmber, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'ROM "$fileName" (${updatedGame.platform}) berhasil dipasang ke ${updatedGame.title}!',
                        style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
                backgroundColor: AppTheme.chassisCard,
                behavior: SnackBarBehavior.floating,
              ),
            );
          }
        } on UnsupportedRomException catch (err) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  err.message,
                  style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w600),
                ),
                backgroundColor: Colors.red.shade900,
                behavior: SnackBarBehavior.floating,
              ),
            );
          }
        } catch (err) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  'Gagal memasang ROM: $err',
                  style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w600),
                ),
                backgroundColor: Colors.red.shade900,
                behavior: SnackBarBehavior.floating,
              ),
            );
          }
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Gagal memilih file: $e'),
            backgroundColor: Colors.red.shade800,
          ),
        );
      }
    }
  }

  Future<void> _handlePlayTap({int? loadSlot}) async {
    if (_isLaunching) return;
    setState(() => _isLaunching = true);

    try {
      final available = await _romService.isRomAvailable(widget.game);
      if (!available) {
        if (!mounted) return;
        _showMissingRomDialog();
        return;
      }

      _launchGame(loadSlot: loadSlot);
    } finally {
      if (mounted) {
        setState(() => _isLaunching = false);
      }
    }
  }

  void _launchGame({int? loadSlot}) {
    Navigator.of(context).pop();
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => EmulatorScreen(
          game: widget.game,
          loadSlot: loadSlot,
        ),
      ),
    );
    _saveService.setLastPlayed(widget.game.id);
  }

  void _showMissingRomDialog() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.chassisCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Row(
          children: [
            const Icon(Icons.folder_open_rounded, color: AppTheme.accentAmber, size: 22),
            const SizedBox(width: 10),
            Text(
              'Pilih File Game',
              style: GoogleFonts.spaceGrotesk(color: AppTheme.textPrimary, fontSize: 16, fontWeight: FontWeight.w700),
            ),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'File ROM untuk ${widget.game.title} (${widget.game.platform}) belum ada di memori.',
              style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 13, height: 1.4),
            ),
            const SizedBox(height: 10),
            Text(
              'Silakan pilih file ROM (.gba / .sfc / .nes / .zip) dari penyimpanan HP:',
              style: GoogleFonts.spaceGrotesk(color: AppTheme.textMuted, fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text('Batal', style: GoogleFonts.spaceGrotesk(color: AppTheme.textMuted)),
          ),
          ElevatedButton.icon(
            onPressed: () {
              Navigator.pop(ctx);
              _pickRomFile();
            },
            icon: const Icon(Icons.file_upload_rounded, size: 16),
            label: Text('Pilih File dari HP', style: GoogleFonts.spaceGrotesk(fontWeight: FontWeight.w700)),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accentAmber,
              foregroundColor: AppTheme.chassisVoid,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBoxartFallback(Color platformColor) {
    return Container(
      width: 110,
      height: 110,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            platformColor.withValues(alpha: 0.25),
            AppTheme.chassisElevated,
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: platformColor.withValues(alpha: 0.3), width: 1),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: platformColor.withValues(alpha: 0.15),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.sports_esports_rounded, size: 28, color: platformColor),
          ),
          const SizedBox(height: 6),
          Text(
            widget.game.platform,
            style: GoogleFonts.spaceGrotesk(
              color: platformColor,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final platformColor = AppTheme.platformColor(widget.game.platform);
    final hasAnySave = _saveSlots.any((s) => s.exists);
    final mostRecent = _saveSlots
        .where((s) => s.exists && s.savedAt != null)
        .toList()
      ..sort((a, b) => b.savedAt!.compareTo(a.savedAt!));

    return DraggableScrollableSheet(
      initialChildSize: 0.85,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: AppTheme.chassisElevated,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
            border: Border.all(
              color: platformColor.withValues(alpha: 0.4),
              width: 1.5,
            ),
            boxShadow: const [VemoShadows.tactileModal],
          ),
          child: Column(
            children: [
              // Drag handle
              Padding(
                padding: const EdgeInsets.only(top: 12, bottom: 4),
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppTheme.borderHard,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),

              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: const EdgeInsets.fromLTRB(24, 12, 24, 32),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Hero boxart + title row
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Hero(
                            tag: 'boxart_${widget.game.id}',
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(16),
                              child: widget.game.boxartPath.isNotEmpty
                                  ? Image.asset(
                                      'assets/${widget.game.boxartPath}',
                                      width: 110,
                                      height: 110,
                                      cacheWidth: 600,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => _buildBoxartFallback(platformColor),
                                    )
                                  : _buildBoxartFallback(platformColor),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 4,
                                      ),
                                      decoration: BoxDecoration(
                                        color: platformColor.withValues(alpha: 0.15),
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: platformColor.withValues(alpha: 0.4),
                                          width: 1.2,
                                        ),
                                      ),
                                      child: Text(
                                        widget.game.platform,
                                        style: GoogleFonts.spaceGrotesk(
                                          color: platformColor,
                                          fontSize: 11,
                                          fontWeight: FontWeight.w700,
                                          letterSpacing: 1.2,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    if (!_checkingRom)
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 8,
                                          vertical: 3,
                                        ),
                                        decoration: BoxDecoration(
                                          color: _isRomAvailable
                                              ? Colors.green.withValues(alpha: 0.15)
                                              : Colors.orange.withValues(alpha: 0.15),
                                          borderRadius: BorderRadius.circular(6),
                                          border: Border.all(
                                            color: _isRomAvailable
                                                ? Colors.green
                                                : Colors.orange,
                                            width: 1,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            Icon(
                                              _isRomAvailable
                                                  ? Icons.check_circle_rounded
                                                  : Icons.info_outline_rounded,
                                              color: _isRomAvailable
                                                  ? Colors.green
                                                  : Colors.orange,
                                              size: 11,
                                            ),
                                            const SizedBox(width: 4),
                                            Text(
                                              _isRomAvailable ? 'Siap Main' : 'Pilih ROM',
                                              style: GoogleFonts.spaceGrotesk(
                                                color: _isRomAvailable
                                                    ? Colors.green
                                                    : Colors.orange,
                                                fontSize: 10,
                                                fontWeight: FontWeight.w700,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  widget.game.title,
                                  style: GoogleFonts.spaceGrotesk(
                                    color: AppTheme.textPrimary,
                                    fontSize: 17,
                                    fontWeight: FontWeight.w700,
                                    height: 1.25,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  '${widget.game.romSizeMB} MB',
                                  style: GoogleFonts.spaceGrotesk(
                                    color: AppTheme.textMuted,
                                    fontSize: 11,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ).animate().fadeIn(duration: 300.ms).slideY(begin: 0.05),

                      const SizedBox(height: 18),

                      // ROM action row (Import from Storage)
                      InkWell(
                        onTap: _pickRomFile,
                        borderRadius: BorderRadius.circular(12),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                            color: AppTheme.chassisCard,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: _isRomAvailable
                                  ? Colors.green.withValues(alpha: 0.3)
                                  : AppTheme.accentAmber.withValues(alpha: 0.4),
                              width: 1.2,
                            ),
                          ),
                          child: Row(
                            children: [
                              Icon(
                                _isRomAvailable ? Icons.check_circle_outline_rounded : Icons.file_upload_outlined,
                                color: _isRomAvailable ? Colors.green : AppTheme.accentAmber,
                                size: 18,
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  _isRomAvailable
                                      ? 'File Game Terpasang (Klik untuk ganti)'
                                      : 'Pilih File Game (.gba/.sfc/.nes/.zip)',
                                  style: GoogleFonts.spaceGrotesk(
                                    color: _isRomAvailable ? AppTheme.textSecondary : AppTheme.accentAmber,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                              const Icon(
                                Icons.chevron_right_rounded,
                                color: AppTheme.textMuted,
                                size: 18,
                              ),
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 18),
                      // Description — only if content exists
                      if (widget.game.description.isNotEmpty) ...[
                        const _SectionLabel(label: 'Tentang Game'),
                        const SizedBox(height: 8),
                        Text(
                          widget.game.description,
                          style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.textSecondary,
                            fontSize: 12,
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 18),
                      ],

                      // Tips — only if content exists
                      if (widget.game.tips.isNotEmpty) ...[
                        const _SectionLabel(label: 'Tips & Trik'),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppTheme.accentAmber.withValues(alpha: 0.07),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppTheme.accentAmber.withValues(alpha: 0.2),
                            ),
                          ),
                          child: Text(
                            widget.game.tips,
                            style: GoogleFonts.spaceGrotesk(
                              color: AppTheme.textSecondary,
                              fontSize: 12,
                              height: 1.5,
                            ),
                          ),
                        ),
                        const SizedBox(height: 18),
                      ],

                      // Save slots
                      if (!_loadingSaves) ...[
                        const _SectionLabel(label: 'Slot Simpanan'),
                        const SizedBox(height: 8),
                        Row(
                          children: List.generate(
                            3,
                            (i) => Expanded(
                              child: Padding(
                                padding: EdgeInsets.only(right: i < 2 ? 8 : 0),
                                child: _SaveSlotChip(
                                  slot: _saveSlots[i],
                                  onLoad: () => _handlePlayTap(
                                    loadSlot: _saveSlots[i].slot,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],

                      const SizedBox(height: 24),

                      // Primary CTA — Play
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _isLaunching ? null : () => _handlePlayTap(),
                          icon: _isLaunching
                              ? const SizedBox(
                                  width: 18,
                                  height: 18,
                                  child: CircularProgressIndicator(strokeWidth: 2, color: AppTheme.chassisVoid),
                                )
                              : const Icon(Icons.play_arrow_rounded, size: 22),
                          label: Text(
                            _isLaunching
                                ? 'MENYIAPKAN GAME...'
                                : (_isRomAvailable ? 'MAINKAN SEKARANG' : 'PILIH GAME & MAINKAN'),
                          ),
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            backgroundColor: _isRomAvailable ? AppTheme.accentAmber : Colors.amber.shade700,
                            foregroundColor: AppTheme.chassisVoid,
                            textStyle: GoogleFonts.spaceGrotesk(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              letterSpacing: 0.5,
                            ),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                          ),
                        ).animate().fadeIn(delay: 150.ms).slideY(begin: 0.1),
                      ),

                      // Secondary CTA — Continue
                      if (hasAnySave && mostRecent.isNotEmpty && _isRomAvailable) ...[
                        const SizedBox(height: 10),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: _isLaunching
                                ? null
                                : () => _handlePlayTap(
                                      loadSlot: mostRecent.first.slot,
                                    ),
                            icon: const Icon(
                              Icons.restore_rounded,
                              size: 18,
                            ),
                            label: Text(
                              'LANJUTKAN MAIN (SLOT ${mostRecent.first.slot})',
                            ),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: AppTheme.accentAmber,
                              side: const BorderSide(
                                color: AppTheme.accentAmber,
                                width: 1.5,
                              ),
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              textStyle: GoogleFonts.spaceGrotesk(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                letterSpacing: 0.5,
                              ),
                            ),
                          ).animate().fadeIn(delay: 200.ms).slideY(begin: 0.1),
                        ),
                      ],

                      // Delete from library button — only for user-added games
                      if (widget.onDelete != null) ...[
                        const SizedBox(height: 14),
                        SizedBox(
                          width: double.infinity,
                          child: OutlinedButton.icon(
                            onPressed: () {
                              Navigator.of(context).pop();
                              widget.onDelete!();
                            },
                            icon: const Icon(Icons.delete_outline_rounded, size: 16),
                            label: const Text('Hapus Game dari Koleksi'),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.redAccent,
                              side: const BorderSide(color: Colors.redAccent, width: 1),
                              padding: const EdgeInsets.symmetric(vertical: 10),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              textStyle: GoogleFonts.spaceGrotesk(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Text(
      label.toUpperCase(),
      style: GoogleFonts.spaceGrotesk(
        color: AppTheme.accentAmber,
        fontSize: 10,
        fontWeight: FontWeight.w700,
        letterSpacing: 1.5,
      ),
    );
  }
}

class _SaveSlotChip extends StatelessWidget {
  final SaveSlotInfo slot;
  final VoidCallback onLoad;

  const _SaveSlotChip({required this.slot, required this.onLoad});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: slot.exists ? onLoad : null,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: slot.exists
              ? AppTheme.accentAmber.withValues(alpha: 0.1)
              : AppTheme.chassisCard,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: slot.exists
                ? AppTheme.accentAmber.withValues(alpha: 0.4)
                : AppTheme.borderHard,
          ),
        ),
        child: Column(
          children: [
            Icon(
              slot.exists ? Icons.save_rounded : Icons.save_outlined,
              size: 18,
              color: slot.exists ? AppTheme.accentAmber : AppTheme.textMuted,
            ),
            const SizedBox(height: 4),
            Text(
              'Slot ${slot.slot}',
              style: GoogleFonts.spaceGrotesk(
                color: slot.exists ? AppTheme.textPrimary : AppTheme.textMuted,
                fontSize: 11,
                fontWeight: FontWeight.w600,
              ),
            ),
            if (slot.exists && slot.savedAt != null)
              Text(
                _formatDate(slot.savedAt!),
                style: GoogleFonts.spaceGrotesk(
                  color: AppTheme.textMuted,
                  fontSize: 9,
                ),
                textAlign: TextAlign.center,
              ),
          ],
        ),
      ),
    );
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) return 'Today';
    if (diff.inDays == 1) return 'Yesterday';
    return '${dt.day}/${dt.month}/${dt.year}';
  }
}
