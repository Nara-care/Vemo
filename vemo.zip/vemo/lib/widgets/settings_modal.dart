import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../theme/app_theme.dart';
import '../services/audio_service.dart';
import '../services/haptic_service.dart';
import '../services/user_library_service.dart';
import '../services/native_emulator_service.dart';
import 'vera_dialog_faq.dart';
import '../screens/visual_controller_editor_screen.dart';

/// Settings modal with audio BGM volume control, visual filters, haptic triggers, and controller layout customizer.
class SettingsModal extends StatefulWidget {
  const SettingsModal({super.key});

  static Future<void> show(BuildContext context) async {
    HapticFeedback.lightImpact();
    // Auto-pause native emulator engine if active during settings/FAQ view
    await NativeEmulatorService().pause();
    if (!context.mounted) return;
    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      enableDrag: false,
      builder: (_) => const SettingsModal(),
    );
    // Resume native emulator engine if in active gameplay
    if (AudioService().isInGameplay) {
      await NativeEmulatorService().resume();
    }
  }

  @override
  State<SettingsModal> createState() => _SettingsModalState();
}

class _SettingsModalState extends State<SettingsModal> {
  final AudioService _audio = AudioService();
  final HapticService _haptic = HapticService();
  int _videoFilterMode = 0; // 0: Smooth HD, 1: Retro Scanlines, 2: Crisp Pixel
  bool _enable3dHw = true;
  int _internalResolutionScale = 1; // 1x, 2x, 4x

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _haptic.init().then((_) {
      if (mounted) setState(() {});
    });
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _videoFilterMode = prefs.getInt('video_filter_mode') ?? 0;
      _enable3dHw = prefs.getBool('enable_3d_hw') ?? true;
      _internalResolutionScale = prefs.getInt('internal_resolution_scale') ?? 1;
    });
  }

  Future<void> _setVideoFilter(int mode) async {
    setState(() => _videoFilterMode = mode);
    _haptic.triggerClick();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('video_filter_mode', mode);
  }

  Future<void> _update3dHwConfig({bool? enableHw, int? scale}) async {
    final newHw = enableHw ?? _enable3dHw;
    final newScale = scale ?? _internalResolutionScale;
    setState(() {
      _enable3dHw = newHw;
      _internalResolutionScale = newScale;
    });
    _haptic.triggerClick();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('enable_3d_hw', newHw);
    await prefs.setInt('internal_resolution_scale', newScale);
    await NativeEmulatorService().configureEngine(
      enableHw: newHw,
      resolutionScale: newScale,
      graphicsApi: 0,
      enableVrr: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.chassisElevated,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(
          color: AppTheme.borderHard,
          width: 1.5,
        ),
        boxShadow: const [VemoShadows.tactileModal],
      ),
      padding: EdgeInsets.fromLTRB(
        20,
        16,
        20,
        MediaQuery.of(context).viewInsets.bottom + 32,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Drag Handle
            Container(
              width: 36,
              height: 4,
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(
                color: AppTheme.borderHard,
                borderRadius: BorderRadius.circular(2),
              ),
            ),

            // Title
            Row(
              children: [
                const Icon(
                  Icons.tune_rounded,
                  color: AppTheme.accentAmber,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Text(
                  'Pengaturan',
                  style: GoogleFonts.spaceGrotesk(
                    color: AppTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // ─── Lobby Audio & BGM Section ──────────────────────────────────
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.chassisCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppTheme.borderHard,
                  width: 1.2,
                ),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                              color: AppTheme.accentAmber.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(
                              Icons.music_note_rounded,
                              color: AppTheme.accentAmber,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Musik Menu (BGM)',
                                style: GoogleFonts.spaceGrotesk(
                                  color: AppTheme.textPrimary,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                              Text(
                                'Retro Synth Wave',
                                style: GoogleFonts.spaceGrotesk(
                                  color: AppTheme.accentAmber,
                                  fontSize: 11,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      // Mute Switch
                      ValueListenableBuilder<bool>(
                        valueListenable: _audio.isMutedNotifier,
                        builder: (context, isMuted, _) {
                          return Switch(
                            value: !isMuted,
                            activeColor: AppTheme.accentAmber,
                            activeTrackColor: AppTheme.accentAmber.withValues(alpha: 0.3),
                            inactiveThumbColor: AppTheme.textMuted,
                            inactiveTrackColor: AppTheme.chassisVoid,
                            onChanged: (_) => _audio.toggleMute(),
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  const Divider(color: Color(0x15FFFFFF), height: 1),
                  const SizedBox(height: 10),
                  // Volume Slider with live percentage
                  ValueListenableBuilder<double>(
                    valueListenable: _audio.volumeNotifier,
                    builder: (context, volume, _) {
                      final percent = (volume * 100).round();
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Volume Suara: $percent%',
                                style: GoogleFonts.spaceGrotesk(
                                  color: AppTheme.textSecondary,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              if (percent != 25)
                                GestureDetector(
                                  onTap: () {
                                    HapticFeedback.selectionClick();
                                    _audio.setVolume(0.25);
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                    decoration: BoxDecoration(
                                      color: AppTheme.accentAmber.withValues(alpha: 0.12),
                                      borderRadius: BorderRadius.circular(6),
                                      border: Border.all(
                                        color: AppTheme.accentAmber.withValues(alpha: 0.3),
                                        width: 1,
                                      ),
                                    ),
                                    child: Text(
                                      'Reset 25%',
                                      style: GoogleFonts.spaceGrotesk(
                                        color: AppTheme.accentAmber,
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          SliderTheme(
                            data: SliderTheme.of(context).copyWith(
                              activeTrackColor: AppTheme.accentAmber,
                              inactiveTrackColor: AppTheme.chassisVoid,
                              thumbColor: AppTheme.accentAmber,
                              overlayColor: AppTheme.accentAmber.withValues(alpha: 0.2),
                              trackHeight: 4,
                            ),
                            child: Slider(
                              value: volume,
                              min: 0.0,
                              max: 1.0,
                              divisions: 20,
                              onChanged: (val) => _audio.setVolume(val),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),

            const SizedBox(height: 14),

            // ─── Haptic Vibration Section ──────────────────────────────────
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.chassisCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppTheme.borderHard,
                  width: 1.2,
                ),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: AppTheme.accentAmber.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(
                                Icons.vibration_rounded,
                                color: AppTheme.accentAmber,
                                size: 16,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Getaran Tombol',
                                    style: GoogleFonts.spaceGrotesk(
                                      color: AppTheme.textPrimary,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 13,
                                    ),
                                  ),
                                  Text(
                                    'Sensasi taktil saat menekan tombol gamepad',
                                    style: GoogleFonts.spaceGrotesk(
                                      color: AppTheme.textMuted,
                                      fontSize: 11,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      Switch(
                        value: _haptic.enabled,
                        activeColor: AppTheme.accentAmber,
                        activeTrackColor: AppTheme.accentAmber.withValues(alpha: 0.3),
                        inactiveThumbColor: AppTheme.textMuted,
                        inactiveTrackColor: AppTheme.chassisVoid,
                        onChanged: (val) {
                          setState(() {
                            _haptic.setEnabled(val);
                            if (val) _haptic.trigger();
                          });
                        },
                      ),
                    ],
                  ),

                  if (_haptic.enabled) ...[
                    const SizedBox(height: 10),
                    const Divider(color: Color(0x15FFFFFF), height: 1),
                    const SizedBox(height: 10),

                    // Intensity Selector
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Intensitas',
                          style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            HapticIntensity.light,
                            HapticIntensity.medium,
                            HapticIntensity.heavy,
                          ].map((mode) {
                            final isSel = _haptic.intensity == mode;
                            final label = mode == HapticIntensity.light
                                ? 'Ringan'
                                : mode == HapticIntensity.medium
                                    ? 'Sedang'
                                    : 'Kuat';
                            return Padding(
                              padding: const EdgeInsets.only(left: 4),
                              child: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _haptic.setIntensity(mode);
                                    _haptic.trigger();
                                  });
                                },
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: isSel
                                        ? AppTheme.accentAmber.withValues(alpha: 0.2)
                                        : AppTheme.chassisVoid,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: isSel ? AppTheme.accentAmber : AppTheme.borderHard,
                                      width: isSel ? 1.5 : 1,
                                    ),
                                  ),
                                  child: Text(
                                    label,
                                    style: GoogleFonts.spaceGrotesk(
                                      color: isSel ? AppTheme.accentAmber : AppTheme.textMuted,
                                      fontSize: 10.5,
                                      fontWeight: isSel ? FontWeight.w700 : FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 14),

            // ─── Video Filter Mode ──────────────────────────────────────────
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.chassisCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppTheme.borderHard,
                  width: 1.2,
                ),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: AppTheme.accentTeal.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.tv_rounded,
                          color: AppTheme.accentTeal,
                          size: 16,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Filter Visual Layar',
                              style: GoogleFonts.spaceGrotesk(
                                color: AppTheme.textPrimary,
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                              ),
                            ),
                            Text(
                              'Pilihan tampilan piksel dan efek retro TV CRT',
                              style: GoogleFonts.spaceGrotesk(
                                color: AppTheme.textMuted,
                                fontSize: 11,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Divider(color: Color(0x15FFFFFF), height: 1),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(child: _buildFilterModeChip('Smooth HD', 0)),
                      const SizedBox(width: 8),
                      Expanded(child: _buildFilterModeChip('Scanlines', 1)),
                      const SizedBox(width: 8),
                      Expanded(child: _buildFilterModeChip('Crisp Pixel', 2)),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 14),

            // ─── 3D Hardware Acceleration & Resolution Scaling ───────────────
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.chassisCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: AppTheme.borderHard,
                  width: 1.2,
                ),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: AppTheme.accentPurple.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(
                                Icons.view_in_ar_rounded,
                                color: AppTheme.accentPurple,
                                size: 16,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        '3D HW Acceleration',
                                        style: GoogleFonts.spaceGrotesk(
                                          color: AppTheme.textPrimary,
                                          fontWeight: FontWeight.w700,
                                          fontSize: 13,
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                                        decoration: BoxDecoration(
                                          color: AppTheme.accentPurple.withValues(alpha: 0.2),
                                          borderRadius: BorderRadius.circular(4),
                                          border: Border.all(color: AppTheme.accentPurple, width: 0.8),
                                        ),
                                        child: Text(
                                          'PS1 / GLES3',
                                          style: GoogleFonts.spaceGrotesk(
                                            color: AppTheme.accentPurple,
                                            fontSize: 8.5,
                                            fontWeight: FontWeight.w800,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Text(
                                    'Rendering FBO OpenGL ES 3.0 & Zero-Copy',
                                    style: GoogleFonts.spaceGrotesk(
                                      color: AppTheme.textMuted,
                                      fontSize: 11,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Switch(
                        value: _enable3dHw,
                        activeColor: AppTheme.accentPurple,
                        activeTrackColor: AppTheme.accentPurple.withValues(alpha: 0.3),
                        inactiveThumbColor: AppTheme.textMuted,
                        inactiveTrackColor: AppTheme.chassisVoid,
                        onChanged: (val) => _update3dHwConfig(enableHw: val),
                      ),
                    ],
                  ),

                  if (_enable3dHw) ...[
                    const SizedBox(height: 10),
                    const Divider(color: Color(0x15FFFFFF), height: 1),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Internal Resolution Scale',
                          style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12),
                        ),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            1, // 1x Native (240p)
                            2, // 2x HD (480p)
                            4, // 4x FHD (1080p)
                          ].map((scale) {
                            final isSel = _internalResolutionScale == scale;
                            final label = scale == 1 ? '1x Native' : (scale == 2 ? '2x HD' : '4x FHD');
                            return Padding(
                              padding: const EdgeInsets.only(left: 4),
                              child: GestureDetector(
                                onTap: () => _update3dHwConfig(scale: scale),
                                child: Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                  decoration: BoxDecoration(
                                    color: isSel
                                        ? AppTheme.accentPurple.withValues(alpha: 0.2)
                                        : AppTheme.chassisVoid,
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: isSel ? AppTheme.accentPurple : AppTheme.borderHard,
                                      width: isSel ? 1.5 : 1,
                                    ),
                                  ),
                                  child: Text(
                                    label,
                                    style: GoogleFonts.spaceGrotesk(
                                      color: isSel ? AppTheme.accentPurple : AppTheme.textMuted,
                                      fontSize: 10.5,
                                      fontWeight: isSel ? FontWeight.w700 : FontWeight.w500,
                                    ),
                                  ),
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),

            const SizedBox(height: 14),

            // ─── Button Customizer Banner (FPS HUD Editor) ────────────────
            GestureDetector(
              onTap: () {
                _haptic.triggerClick();
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const VisualControllerEditorScreen(
                      initialPlatform: 'GBA',
                    ),
                  ),
                );
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.accentAmber.withValues(alpha: 0.18),
                      AppTheme.accentTeal.withValues(alpha: 0.08),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: AppTheme.accentAmber.withValues(alpha: 0.5),
                    width: 1.2,
                  ),
                  boxShadow: const [VemoShadows.tactileSmall],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: AppTheme.accentAmber,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(
                              Icons.sports_esports_rounded,
                              color: AppTheme.chassisVoid,
                              size: 18,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Tata Letak Tombol',
                                      style: GoogleFonts.spaceGrotesk(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 13,
                                      ),
                                    ),
                                    const SizedBox(width: 6),
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                                      decoration: BoxDecoration(
                                        color: AppTheme.accentAmber.withValues(alpha: 0.2),
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(color: AppTheme.accentAmber, width: 0.8),
                                      ),
                                      child: Text(
                                        '3 SLOT',
                                        style: GoogleFonts.spaceGrotesk(
                                          color: AppTheme.accentAmber,
                                          fontSize: 8.5,
                                          fontWeight: FontWeight.w800,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                Text(
                                  'Visual HUD Drag Editor untuk HP, Tablet & Claw Grip',
                                  style: GoogleFonts.spaceGrotesk(
                                    color: AppTheme.textSecondary,
                                    fontSize: 11,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Icon(Icons.arrow_forward_ios_rounded, color: AppTheme.accentAmber, size: 14),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 14),

            // ─── Restore Default Bundled Games Action ──────────────────────
            GestureDetector(
              onTap: () async {
                _haptic.triggerClick();
                await UserLibraryService().restoreBundledGames();
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Row(
                        children: [
                          const Icon(Icons.check_circle_rounded, color: AppTheme.accentAmber, size: 18),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Seluruh game bawaan default berhasil dipulihkan ke Library!',
                              style: GoogleFonts.spaceGrotesk(fontSize: 12, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ),
                      backgroundColor: AppTheme.chassisCard,
                      behavior: SnackBarBehavior.floating,
                      duration: const Duration(seconds: 2),
                    ),
                  );
                }
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  color: AppTheme.chassisCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: AppTheme.accentAmber.withValues(alpha: 0.35),
                  ),
                  boxShadow: const [VemoShadows.tactileSmall],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppTheme.accentAmber.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(
                        Icons.restore_page_rounded,
                        color: AppTheme.accentAmber,
                        size: 18,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Pulihkan Game Bawaan',
                            style: GoogleFonts.spaceGrotesk(
                              color: AppTheme.textPrimary,
                              fontWeight: FontWeight.w700,
                              fontSize: 13,
                            ),
                          ),
                          Text(
                            'Kembalikan Super Mario 2, Kirby, & Crash ke Library',
                            style: GoogleFonts.spaceGrotesk(
                              color: AppTheme.textMuted,
                              fontSize: 11,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.refresh_rounded, color: AppTheme.accentAmber, size: 16),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 14),

            // App info
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: AppTheme.chassisCard,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: AppTheme.borderHard, width: 1.2),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Versi',
                        style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12),
                      ),
                      Text(
                        'v4.0.0',
                        style: GoogleFonts.spaceGrotesk(
                          color: AppTheme.accentAmber,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Divider(color: Color(0x15FFFFFF), height: 1),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Konsol Didukung',
                        style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12),
                      ),
                      Flexible(
                        child: Text(
                          'GBA · SNES · NES · MD · Arcade',
                          style: GoogleFonts.spaceGrotesk(
                            color: AppTheme.textMuted,
                            fontSize: 11,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  const Divider(color: Color(0x15FFFFFF), height: 1),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Core Engine',
                        style: GoogleFonts.spaceGrotesk(color: AppTheme.textSecondary, fontSize: 12),
                      ),
                      Flexible(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                              decoration: BoxDecoration(
                                color: AppTheme.accentTeal.withValues(alpha: 0.15),
                                borderRadius: BorderRadius.circular(4),
                                border: Border.all(color: AppTheme.accentTeal, width: 0.8),
                              ),
                              child: Text(
                                'VE-NE',
                                style: GoogleFonts.spaceGrotesk(
                                  color: AppTheme.accentTeal,
                                  fontSize: 9,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              'C++17 / AAudio / SIMD',
                              style: GoogleFonts.spaceGrotesk(
                                color: AppTheme.textMuted,
                                fontSize: 10.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 14),

            // About Vemo Card & Interactive FAQ (Lazy-loaded with isolated expansion state)
            const _AboutVemoSection(),

            const SizedBox(height: 20),

            // Footer branding
            Text(
              'Vera Creation • Dibuat dengan cinta',
              style: GoogleFonts.spaceGrotesk(
                color: AppTheme.textMuted,
                fontSize: 11,
                letterSpacing: 0.3,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterModeChip(String label, int mode) {
    final isSel = _videoFilterMode == mode;
    return GestureDetector(
      onTap: () => _setVideoFilter(mode),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          color: isSel ? AppTheme.accentTeal.withValues(alpha: 0.2) : AppTheme.chassisVoid,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isSel ? AppTheme.accentTeal : AppTheme.borderHard,
            width: isSel ? 1.5 : 1,
          ),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: GoogleFonts.spaceGrotesk(
            color: isSel ? AppTheme.accentTeal : AppTheme.textMuted,
            fontSize: 11,
            fontWeight: isSel ? FontWeight.w700 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

/// ℹ️ Isolated About Vemo Expandable Section (prevents full-screen rebuilds on toggle)
class _AboutVemoSection extends StatefulWidget {
  const _AboutVemoSection();

  @override
  State<_AboutVemoSection> createState() => _AboutVemoSectionState();
}

class _AboutVemoSectionState extends State<_AboutVemoSection> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        GestureDetector(
          onTap: () {
            HapticFeedback.mediumImpact();
            setState(() => _isExpanded = !_isExpanded);
          },
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  AppTheme.accentAmber.withValues(alpha: 0.08),
                  AppTheme.accentAmber.withValues(alpha: 0.03),
                ],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: AppTheme.accentAmber.withValues(alpha: 0.25),
              ),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                    color: AppTheme.accentAmber.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.info_outline_rounded,
                    color: AppTheme.accentAmber,
                    size: 18,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Tentang Vemo',
                        style: GoogleFonts.spaceGrotesk(
                          color: AppTheme.accentAmber,
                          fontWeight: FontWeight.w700,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        'Informasi sistem konsol retro',
                        style: GoogleFonts.spaceGrotesk(
                          color: AppTheme.textMuted,
                          fontSize: 11,
                        ),
                      ),
                    ],
                  ),
                ),
                AnimatedRotation(
                  turns: _isExpanded ? 0.25 : 0,
                  duration: const Duration(milliseconds: 250),
                  child: const Icon(
                    Icons.chevron_right_rounded,
                    color: AppTheme.accentAmber,
                  ),
                ),
              ],
            ),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeInOutCubic,
          child: _isExpanded
              ? const Padding(
                  padding: EdgeInsets.only(top: 12),
                  child: VeraInteractiveFaq(),
                )
              : const SizedBox.shrink(),
        ),
      ],
    );
  }
}
