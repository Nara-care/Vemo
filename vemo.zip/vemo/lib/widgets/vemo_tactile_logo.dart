import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// 🕹️ Clean Retro Text Logo for Vemo (Borderless, Big Pixel Font with Copyright Subtitle)
class VemoTactileLogo extends StatelessWidget {
  final double fontSize;
  final bool showSubtitle;
  final VoidCallback? onTap;

  const VemoTactileLogo({
    super.key,
    this.fontSize = 19,
    this.showSubtitle = true,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'VEMO',
            style: GoogleFonts.pressStart2p(
              color: const Color(0xFFE2B755), // Warm Retro Golden Amber
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.8,
              shadows: const [
                Shadow(
                  color: Color(0x99000000),
                  offset: Offset(0, 2),
                  blurRadius: 3,
                ),
              ],
            ),
          ),
          if (showSubtitle) ...[
            const SizedBox(height: 4),
            Text(
              '© VERA CREATION',
              style: GoogleFonts.pressStart2p(
                color: const Color(0xFF7E8799),
                fontSize: (fontSize * 0.32).clamp(5.5, 8.0),
                letterSpacing: 0.6,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
