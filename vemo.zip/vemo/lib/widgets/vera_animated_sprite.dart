import 'package:flutter/material.dart';

enum VeraLook { center, left, right }

/// 🌟 16-Bit Animated Sprite of Vera with Talking Chomp Cycle and Eye Gaze
class VeraAnimatedSprite extends StatefulWidget {
  final double size;
  final bool isTalking;
  final VeraLook lookDirection;
  final VoidCallback? onTap;

  const VeraAnimatedSprite({
    super.key,
    this.size = 160,
    this.isTalking = false,
    this.lookDirection = VeraLook.center,
    this.onTap,
  });

  @override
  State<VeraAnimatedSprite> createState() => _VeraAnimatedSpriteState();
}

class _VeraAnimatedSpriteState extends State<VeraAnimatedSprite>
    with TickerProviderStateMixin {
  late AnimationController _talkController;
  late AnimationController _lookController;
  late Animation<double> _mouthOpenAnim;
  late Animation<double> _lookAnim;

  double _currentLookOffset = 0.0; // -1.0 (kiri), 0.0 (tengah), 1.0 (kanan)

  @override
  void initState() {
    super.initState();

    // Loop Animasi Mulut Ngomong (Retro 8-Bit Chomp / Talk Cycle)
    _talkController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 180),
    );

    _mouthOpenAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _talkController, curve: Curves.easeInOut),
    );

    if (widget.isTalking) {
      _talkController.repeat(reverse: true);
    }

    // Animasi Lirik Mata Halus
    _lookController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 180),
    );
    _updateLookAnimation();
  }

  @override
  void didUpdateWidget(covariant VeraAnimatedSprite oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (widget.isTalking != oldWidget.isTalking) {
      if (widget.isTalking) {
        _talkController.repeat(reverse: true);
      } else {
        _talkController.animateTo(0.0);
      }
    }

    if (widget.lookDirection != oldWidget.lookDirection) {
      _updateLookAnimation();
    }
  }

  void _updateLookAnimation() {
    final double targetOffset = switch (widget.lookDirection) {
      VeraLook.left => -1.0,
      VeraLook.right => 1.0,
      VeraLook.center => 0.0,
    };

    _lookAnim = Tween<double>(
      begin: _currentLookOffset,
      end: targetOffset,
    ).animate(CurvedAnimation(parent: _lookController, curve: Curves.easeOutQuad))
      ..addListener(() {
        setState(() => _currentLookOffset = _lookAnim.value);
      });

    _lookController.forward(from: 0.0);
  }

  @override
  void dispose() {
    _talkController.dispose();
    _lookController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        width: widget.size,
        height: widget.size,
        color: Colors.transparent,
        child: AnimatedBuilder(
          animation: Listenable.merge([_talkController, _lookController]),
          builder: (context, _) {
            return CustomPaint(
              painter: _Vera16BitPainter(
                mouthOpen: _mouthOpenAnim.value,
                lookOffset: _currentLookOffset,
              ),
              size: Size(widget.size, widget.size),
            );
          },
        ),
      ),
    );
  }
}

class _Vera16BitPainter extends CustomPainter {
  final double mouthOpen;   // 0.0 (V tertutup) s/d 1.0 (U mangap)
  final double lookOffset;  // -1.0 (lirik kiri) s/d 1.0 (lirik kanan)

  _Vera16BitPainter({
    required this.mouthOpen,
    required this.lookOffset,
  });

  // Pre-cached Paint Objects (Zero allocation di render loop)
  static final Paint _paintWhite = Paint()..color = const Color(0xFFFFFFFF);
  static final Paint _paintSilver = Paint()..color = const Color(0xFFD0D4DC);
  static final Paint _paintDarkGray = Paint()..color = const Color(0xFF7B828E);
  static final Paint _paintMouthCavity = Paint()..color = const Color(0xFF16161C);

  @override
  void paint(Canvas canvas, Size size) {
    final double scale = size.width / 128.0;

    void drawPx(double x, double y, double w, double h, Paint paint) {
      canvas.drawRect(
        Rect.fromLTWH(x * scale, y * scale, w * scale, h * scale),
        paint,
      );
    }

    // Horizontal shift piksel untuk mata (maksimal 4px shift)
    final double eyeShift = lookOffset * 4.0;

    // ============================================================
    // 1. MATA SPIRAL KIRI (CENTER X=42, Y=30)
    // ============================================================
    // Ring Luar (Statis)
    drawPx(34, 14, 16, 3, _paintWhite);
    drawPx(28, 17, 6, 3, _paintWhite);
    drawPx(50, 17, 6, 3, _paintWhite);
    drawPx(25, 20, 3, 18, _paintWhite);
    drawPx(56, 20, 3, 14, _paintWhite);
    drawPx(28, 38, 6, 3, _paintWhite);
    drawPx(50, 34, 6, 3, _paintWhite);
    drawPx(34, 41, 16, 3, _paintWhite);

    // Ring Tengah (Bergeser saat lirik)
    drawPx(36 + (eyeShift * 0.5), 20, 12, 3, _paintSilver);
    drawPx(31 + (eyeShift * 0.5), 23, 5, 3, _paintSilver);
    drawPx(48 + (eyeShift * 0.5), 23, 5, 3, _paintSilver);
    drawPx(31 + (eyeShift * 0.5), 26, 3, 9, _paintSilver);
    drawPx(50 + (eyeShift * 0.5), 26, 3, 6, _paintSilver);
    drawPx(34 + (eyeShift * 0.5), 35, 14, 3, _paintSilver);

    // Inti Pupil (Bergeser penuh)
    drawPx(37 + eyeShift, 26, 10, 3, _paintDarkGray);
    drawPx(37 + eyeShift, 29, 3, 4, _paintDarkGray);
    drawPx(44 + eyeShift, 29, 3, 4, _paintDarkGray);
    drawPx(37 + eyeShift, 32, 10, 3, _paintDarkGray);

    // ============================================================
    // 2. MATA SPIRAL KANAN (CENTER X=86, Y=30)
    // ============================================================
    // Ring Luar (Statis)
    drawPx(78, 14, 16, 3, _paintWhite);
    drawPx(72, 17, 6, 3, _paintWhite);
    drawPx(94, 17, 6, 3, _paintWhite);
    drawPx(69, 20, 3, 14, _paintWhite);
    drawPx(100, 20, 3, 18, _paintWhite);
    drawPx(72, 34, 6, 3, _paintWhite);
    drawPx(94, 38, 6, 3, _paintWhite);
    drawPx(78, 41, 16, 3, _paintWhite);

    // Ring Tengah
    drawPx(80 + (eyeShift * 0.5), 20, 12, 3, _paintSilver);
    drawPx(75 + (eyeShift * 0.5), 23, 5, 3, _paintSilver);
    drawPx(92 + (eyeShift * 0.5), 23, 5, 3, _paintSilver);
    drawPx(75 + (eyeShift * 0.5), 26, 3, 6, _paintSilver);
    drawPx(94 + (eyeShift * 0.5), 26, 3, 9, _paintSilver);
    drawPx(80 + (eyeShift * 0.5), 35, 14, 3, _paintSilver);

    // Inti Pupil
    drawPx(81 + eyeShift, 26, 10, 3, _paintDarkGray);
    drawPx(81 + eyeShift, 29, 3, 4, _paintDarkGray);
    drawPx(88 + eyeShift, 29, 3, 4, _paintDarkGray);
    drawPx(81 + eyeShift, 32, 10, 3, _paintDarkGray);

    // ============================================================
    // 3. ANIMASI MULUT: BIBIR ATAS, GEMPITAN & BIBIR BAWAH
    // ============================================================
    final double openFactor = mouthOpen; // 0.0 s/d 1.0

    // Rongga Mulut Hitam (Tampak saat membuka)
    if (openFactor > 0.1) {
      drawPx(50, 78, 28, 20 * openFactor, _paintMouthCavity);
    }

    // --- BILAH 1 (PUTIH - BIBIR ATAS / KONTUR UTAMA) ---
    // Ujung atas rounded
    drawPx(27, 50, 4, 2, _paintWhite);
    drawPx(97, 50, 4, 2, _paintWhite);

    // Lengan Kiri Luar
    final leftOuterSteps = [
      [26.0, 52.0], [29.0, 58.0], [32.0, 64.0], [35.0, 70.0],
      [38.0, 76.0], [41.0, 82.0], [44.0, 88.0], [47.0, 94.0],
      [50.0, 100.0], [53.0, 106.0], [56.0, 112.0], [59.0, 118.0]
    ];
    for (var pt in leftOuterSteps) {
      // Saat mangap, bibir bawah ditarik melengkung U
      double morphX = pt[0] - (openFactor * (pt[1] > 90 ? 4.0 : 0.0));
      drawPx(morphX, pt[1], 4, 6, _paintWhite);
    }

    // Lengan Kanan Luar
    final rightOuterSteps = [
      [98.0, 52.0], [95.0, 58.0], [92.0, 64.0], [89.0, 70.0],
      [86.0, 76.0], [83.0, 82.0], [80.0, 88.0], [77.0, 94.0],
      [74.0, 100.0], [71.0, 106.0], [68.0, 112.0], [65.0, 118.0]
    ];
    for (var pt in rightOuterSteps) {
      double morphX = pt[0] + (openFactor * (pt[1] > 90 ? 4.0 : 0.0));
      drawPx(morphX, pt[1], 4, 6, _paintWhite);
    }

    // Apex Dasar (V lancip -> U datar membulat)
    if (openFactor < 0.3) {
      drawPx(62, 122, 4, 3, _paintWhite);
      drawPx(63, 124, 2, 2, _paintWhite);
    } else {
      // Bentuk dasar U melengkung
      drawPx(54, 120, 20, 4, _paintWhite);
      drawPx(58, 124, 12, 2, _paintWhite);
    }

    // --- BILAH 2 (SILVER - GEMPITAN BIBIR TENGAH) ---
    // Saat mangap, garis tengah membelah ke atas & ke bawah
    if (openFactor < 0.6) {
      drawPx(36, 53, 4, 2, _paintSilver);
      drawPx(88, 53, 4, 2, _paintSilver);

      for (int i = 0; i < 9; i++) {
        double xL = 35.0 + (i * 3.0);
        double xR = 89.0 - (i * 3.0);
        double y = 55.0 + (i * 6.0);
        drawPx(xL, y, 4, 6, _paintSilver);
        drawPx(xR, y, 4, 6, _paintSilver);
      }
    } else {
      // Frame Bibir Terbuka (Garis tengah split tipis di tepi atas)
      for (int i = 0; i < 6; i++) {
        double xL = 35.0 + (i * 2.8);
        double xR = 89.0 - (i * 2.8);
        double y = 55.0 + (i * 4.5);
        drawPx(xL, y, 3, 4, _paintSilver);
        drawPx(xR, y, 3, 4, _paintSilver);
      }
    }

    // --- BILAH 3 (DARK GRAY - BIBIR BAWAH / INNER TRACK) ---
    drawPx(45, 56, 4, 2, _paintDarkGray);
    drawPx(79, 56, 4, 2, _paintDarkGray);

    for (int i = 0; i < 6; i++) {
      double xL = 44.0 + (i * 3.0) + (openFactor * 2.0);
      double xR = 80.0 - (i * 3.0) - (openFactor * 2.0);
      double y = 58.0 + (i * 6.0) + (openFactor * 4.0);
      drawPx(xL, y, 4, 6, _paintDarkGray);
      drawPx(xR, y, 4, 6, _paintDarkGray);
    }
  }

  @override
  bool shouldRepaint(covariant _Vera16BitPainter oldDelegate) {
    return oldDelegate.mouthOpen != mouthOpen ||
        oldDelegate.lookOffset != lookOffset;
  }
}
