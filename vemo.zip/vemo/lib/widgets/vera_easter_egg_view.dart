import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../services/audio_service.dart';
import '../services/vera_speech_service.dart';
import 'vera_animated_sprite.dart';

/// 👾 Undertale-Style Dialogue Box with 16-Bit Vera Sprite, Natural Typing Rhythm,
/// Random Voice Pitch Modulation, and Seamless Lobby BGM Audio Ducking.
class VeraEasterEggView extends StatefulWidget {
  const VeraEasterEggView({super.key});

  @override
  State<VeraEasterEggView> createState() => _VeraEasterEggViewState();
}

class _VeraEasterEggViewState extends State<VeraEasterEggView> {
  static const String _fullDialogue =
      "HALO! AKU VERA.\n"
      "AI CO-PILOT DARI VERA CREATION.\n\n"
      "VEMO DIRANCANG DENGAN SENSASI RETRO TACTILE TERBAIK, MULUS 60 FPS, DAN DIBUAT DENGAN CINTA.\n\n"
      "SELAMAT BERPETUALANG!";

  final Random _random = Random();

  String _displayedText = "";
  bool _isTalking = false;
  bool _isFinished = false;
  VeraLook _lookDirection = VeraLook.center;
  Timer? _idleGazeTimer;
  bool _isCancelled = false;

  @override
  void initState() {
    super.initState();

    // Check if Easter Egg has already been played in this session
    if (VeraSpeechService.hasPlayedEasterEggThisSession) {
      _displayedText = _fullDialogue;
      _isFinished = true;
      _isTalking = false;
      _startIdleGaze();
    } else {
      _startNaturalDialogue(_fullDialogue);
    }
  }

  void _playVoiceBlip() {
    AudioService().playVeraBlip();
  }

  Future<void> _startNaturalDialogue(String fullText) async {
    // 1. Duck lobby BGM gently while Vera talks
    AudioService().duckLobbyBgm();

    setState(() {
      _displayedText = '';
      _isTalking = true;
      _isFinished = false;
    });

    for (int i = 0; i < fullText.length; i++) {
      if (!mounted || _isCancelled) return;

      final char = fullText[i];

      setState(() {
        _displayedText += char;
      });

      // 2. Play blip only for visible characters
      if (char != ' ' && char != '\n') {
        _playVoiceBlip();

        // Eye gaze shifts naturally during speech
        if (i % 14 == 0) {
          setState(() {
            _lookDirection = _lookDirection == VeraLook.center
                ? (_random.nextBool() ? VeraLook.left : VeraLook.right)
                : VeraLook.center;
          });
        }
      }

      // 3. Natural Undertale Rhythm (cadence with punctuation pauses)
      int delayMs = 45;
      if (char == ',') {
        delayMs = 200; // Pause at comma
        if (mounted) setState(() => _isTalking = false);
      } else if (char == '.' || char == '!' || char == '?') {
        delayMs = 380; // Longer pause at sentence end
        if (mounted) setState(() => _isTalking = false);
      } else {
        if (mounted && !_isTalking) {
          setState(() => _isTalking = true);
        }
      }

      await Future.delayed(Duration(milliseconds: delayMs));
    }

    // 4. Dialogue finished
    if (mounted && !_isCancelled) {
      setState(() {
        _isTalking = false;
        _isFinished = true;
        _lookDirection = VeraLook.center;
      });
      VeraSpeechService.hasPlayedEasterEggThisSession = true;

      // Restore lobby BGM volume back to normal user setting
      AudioService().unduckLobbyBgm();
      _startIdleGaze();
    }
  }

  void _startIdleGaze() {
    _idleGazeTimer?.cancel();
    _idleGazeTimer = Timer.periodic(const Duration(milliseconds: 2800), (timer) {
      if (!mounted) return;
      setState(() {
        if (_lookDirection == VeraLook.center) {
          _lookDirection = (_random.nextBool()) ? VeraLook.right : VeraLook.left;
        } else {
          _lookDirection = VeraLook.center;
        }
      });
    });
  }

  /// Tap to fast-forward or trigger interactive poke blip
  void _onTapDialogueOrSprite() {
    if (!_isFinished) {
      // Fast forward immediately
      _isCancelled = true;
      setState(() {
        _displayedText = _fullDialogue;
        _isTalking = false;
        _isFinished = true;
        _lookDirection = VeraLook.center;
      });
      VeraSpeechService.hasPlayedEasterEggThisSession = true;
      AudioService().unduckLobbyBgm();
      _startIdleGaze();
    } else {
      // Interactive poke reaction
      _playVoiceBlip();
      setState(() {
        _lookDirection = _lookDirection == VeraLook.center
            ? (_random.nextBool() ? VeraLook.right : VeraLook.left)
            : VeraLook.center;
      });
    }
  }

  @override
  void dispose() {
    _isCancelled = true;
    _idleGazeTimer?.cancel();
    // Always restore lobby BGM when dialogue widget is closed
    AudioService().unduckLobbyBgm();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF0C0C12),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: AppTheme.accentAmber.withValues(alpha: 0.45),
          width: 1.5,
        ),
        boxShadow: const [VemoShadows.tactileCard],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── Top Header Badge ──
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.accentAmber.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(color: AppTheme.accentAmber.withValues(alpha: 0.35)),
                ),
                child: Text(
                  'VERA • 16-BIT AI COMPANION',
                  style: GoogleFonts.pressStart2p(
                    color: AppTheme.accentAmber,
                    fontSize: 7.5,
                    letterSpacing: 0.5,
                  ),
                ),
              ),
              if (!_isFinished)
                Text(
                  '[ TAP TO SKIP ]',
                  style: GoogleFonts.pressStart2p(
                    color: AppTheme.textMuted,
                    fontSize: 6.5,
                  ),
                ),
            ],
          ),

          const SizedBox(height: 12),

          // ── Undertale RPG Layout: Sprite on Left, Dialogue Text on Right ──
          GestureDetector(
            onTap: _onTapDialogueOrSprite,
            behavior: HitTestBehavior.opaque,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: Colors.white.withValues(alpha: 0.9),
                  width: 2.5,
                ),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // 1. Vera 16-Bit Sprite
                  Container(
                    width: 76,
                    height: 76,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: const Color(0xFF14141E),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppTheme.accentAmber.withValues(alpha: 0.3),
                      ),
                    ),
                    child: VeraAnimatedSprite(
                      size: 72,
                      isTalking: _isTalking,
                      lookDirection: _lookDirection,
                    ),
                  ),

                  const SizedBox(width: 12),

                  // 2. Typewriter Text Block
                  Expanded(
                    child: Stack(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(bottom: 14),
                          child: Text(
                            _displayedText,
                            style: GoogleFonts.pressStart2p(
                              color: Colors.white,
                              fontSize: 8.5,
                              height: 1.65,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                        if (_isFinished)
                          const Positioned(
                            bottom: 0,
                            right: 0,
                            child: Icon(
                              Icons.arrow_drop_down_rounded,
                              color: AppTheme.accentAmber,
                              size: 20,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
