import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../models/game.dart';

/// A tactile cartridge game card for the library carousel & responsive grid.
/// Adheres to 0-blur hard shadows and memory downsampling (cacheWidth: 320).
class GameCard extends StatefulWidget {
  final Game game;
  final VoidCallback onTap;
  final bool isSelected;

  const GameCard({
    super.key,
    required this.game,
    required this.onTap,
    this.isSelected = false,
  });

  @override
  State<GameCard> createState() => _GameCardState();
}

class _GameCardState extends State<GameCard> {
  bool _isPressed = false;

  Widget _buildIconFallback(Color platformColor) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.chassisCard,
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            platformColor.withValues(alpha: 0.18),
            AppTheme.chassisCard,
            AppTheme.chassisVoid,
          ],
        ),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Tactile grip ridges simulating plastic cartridge
          Positioned(
            top: 14,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(4, (i) => Container(
                width: 18,
                height: 3,
                margin: const EdgeInsets.symmetric(horizontal: 2),
                decoration: BoxDecoration(
                  color: platformColor.withValues(alpha: 0.25),
                  borderRadius: BorderRadius.circular(1.5),
                ),
              )),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: platformColor.withValues(alpha: 0.12),
                  shape: BoxShape.circle,
                  border: Border.all(color: platformColor.withValues(alpha: 0.4), width: 1.5),
                ),
                child: Icon(
                  Icons.videogame_asset_rounded,
                  size: 28,
                  color: platformColor,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                widget.game.platform,
                style: GoogleFonts.spaceGrotesk(
                  color: platformColor,
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final platformColor = AppTheme.platformColor(widget.game.platform);

    return GestureDetector(
      onTapDown: (_) => setState(() => _isPressed = true),
      onTapUp: (_) {
        setState(() => _isPressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _isPressed = false),
      child: Transform.translate(
        offset: _isPressed ? const Offset(2, 2) : Offset.zero,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: 200,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            color: AppTheme.chassisCard,
            border: Border.all(
              color: widget.isSelected
                  ? AppTheme.accentAmber
                  : (_isPressed ? platformColor : AppTheme.borderHard),
              width: widget.isSelected ? 2.0 : 1.5,
            ),
            boxShadow: [
              if (_isPressed)
                VemoShadows.tactilePressed
              else if (widget.isSelected)
                VemoShadows.tactileCardActive
              else
                VemoShadows.tactileCard,
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Boxart / Cartridge Cover Art with Memory Downsampling (takes all remaining space)
              Expanded(
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(16),
                  ),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (widget.game.boxartPath.isNotEmpty)
                        Image.asset(
                          'assets/${widget.game.boxartPath}',
                          cacheWidth: 320,
                          cacheHeight: 480,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => _buildIconFallback(platformColor),
                        )
                      else
                        _buildIconFallback(platformColor),

                      // Bottom gradient shade on artwork
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        height: 46,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Colors.transparent,
                                AppTheme.chassisCard.withValues(alpha: 0.95),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Info section (Title & Platform Badge) — takes natural layout height to never overflow
              Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.game.title,
                      style: GoogleFonts.spaceGrotesk(
                        color: AppTheme.textPrimary,
                        fontSize: 11.5,
                        fontWeight: FontWeight.w700,
                        height: 1.15,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    _PlatformBadge(
                      platform: widget.game.platform,
                      color: platformColor,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    )
        .animate()
        .fadeIn(duration: 350.ms, curve: Curves.easeOut);
  }
}

class _PlatformBadge extends StatelessWidget {
  final String platform;
  final Color color;

  const _PlatformBadge({required this.platform, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2.5),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.15),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withValues(alpha: 0.4), width: 1),
      ),
      child: Text(
        platform,
        style: GoogleFonts.spaceGrotesk(
          color: color,
          fontSize: 9,
          fontWeight: FontWeight.w700,
          letterSpacing: 1.0,
        ),
      ),
    );
  }
}
