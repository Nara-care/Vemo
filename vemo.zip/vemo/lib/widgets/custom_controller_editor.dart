import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../services/controller_layout_service.dart';
import '../services/haptic_service.dart';
import '../screens/visual_controller_editor_screen.dart';

class CustomControllerEditorModal extends StatefulWidget {
  final VoidCallback onLayoutChanged;
  final String platform;

  const CustomControllerEditorModal({
    super.key,
    required this.onLayoutChanged,
    this.platform = 'GBA',
  });

  @override
  State<CustomControllerEditorModal> createState() => _CustomControllerEditorModalState();
}

class _CustomControllerEditorModalState extends State<CustomControllerEditorModal> {
  final ControllerLayoutService _layout = ControllerLayoutService();
  final HapticService _haptic = HapticService();

  late int _activeSlotIndex;
  late double _scale;
  late double _opacity;
  late bool _isTilted;
  late ControllerPreset _preset;

  @override
  void initState() {
    super.initState();
    _activeSlotIndex = _layout.activeSlotIndex;
    _scale = _layout.scale;
    _opacity = _layout.opacity;
    _isTilted = _layout.isActionTilted;
    _preset = _layout.activePreset;
  }

  void _syncWithCurrentSlot() {
    setState(() {
      _scale = _layout.scale;
      _opacity = _layout.opacity;
      _isTilted = _layout.isActionTilted;
    });
    widget.onLayoutChanged();
  }

  void _applyLocalChanges() {
    _layout.scale = _scale;
    _layout.opacity = _opacity;
    _layout.isActionTilted = _isTilted;
    _layout.activePreset = _preset;
    _layout.save();
    widget.onLayoutChanged();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      decoration: BoxDecoration(
        color: AppTheme.chassisElevated,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        border: Border.all(color: AppTheme.borderHard, width: 1.5),
        boxShadow: const [VemoShadows.tactileModal],
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Drag Handle
            Center(
              child: Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: AppTheme.borderHard,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),

            // Header Bar
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.accentAmber.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(Icons.tune_rounded, color: AppTheme.accentAmber, size: 20),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      'Tata Letak Tombol',
                      style: GoogleFonts.spaceGrotesk(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close_rounded, color: Colors.white60),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // ── Primary Action: Open Visual Drag HUD Editor (FPS Style) ─────
            GestureDetector(
              onTap: () async {
                _haptic.triggerClick();
                Navigator.pop(context);
                final updated = await Navigator.push<bool>(
                  context,
                  MaterialPageRoute(
                    builder: (_) => VisualControllerEditorScreen(
                      initialPlatform: widget.platform,
                    ),
                  ),
                );
                if (updated == true) {
                  widget.onLayoutChanged();
                }
              },
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      AppTheme.accentAmber.withValues(alpha: 0.25),
                      AppTheme.accentAmber.withValues(alpha: 0.08),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: AppTheme.accentAmber, width: 1.4),
                  boxShadow: const [VemoShadows.tactileSmall],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: AppTheme.accentAmber,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Icon(
                        Icons.open_with_rounded,
                        color: AppTheme.chassisVoid,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Buka Visual Drag Editor (FPS Style)',
                            style: GoogleFonts.spaceGrotesk(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          Text(
                            'Sentuh & geser tombol langsung di atas layar',
                            style: GoogleFonts.spaceGrotesk(
                              color: AppTheme.accentAmber,
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios_rounded, color: AppTheme.accentAmber, size: 14),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // ── 3 Slot Selector ─────────────────────────────────────────────
            Text(
              'PILIH SLOT TATA LETAK (3 SLOT KUSTOM)',
              style: GoogleFonts.spaceGrotesk(
                color: AppTheme.accentAmber,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                _buildSlotSelectorChip(0, 'Slot 1 (HP)'),
                const SizedBox(width: 8),
                _buildSlotSelectorChip(1, 'Slot 2 (Tablet)'),
                const SizedBox(width: 8),
                _buildSlotSelectorChip(2, 'Slot 3 (Claw)'),
              ],
            ),
            const SizedBox(height: 16),

            // Preset Quick Selector
            Text(
              'PRESET CEPAT',
              style: GoogleFonts.spaceGrotesk(
                color: Colors.white60,
                fontSize: 10,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                _buildPresetChip('Standar', ControllerPreset.standard),
                const SizedBox(width: 8),
                _buildPresetChip('Jari Besar', ControllerPreset.bigFingers),
                const SizedBox(width: 8),
                _buildPresetChip('Arcade Datar', ControllerPreset.arcade),
              ],
            ),
            const SizedBox(height: 18),

            // Scale Slider
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Ukuran Tombol', style: GoogleFonts.spaceGrotesk(color: Colors.white70, fontSize: 13)),
                Text('${(_scale * 100).round()}%', style: GoogleFonts.spaceGrotesk(color: AppTheme.accentAmber, fontWeight: FontWeight.w700, fontSize: 13)),
              ],
            ),
            Slider(
              value: _scale.clamp(0.75, 1.40),
              min: 0.75,
              max: 1.40,
              divisions: 13,
              activeColor: AppTheme.accentAmber,
              inactiveColor: AppTheme.chassisVoid,
              onChanged: (val) {
                setState(() {
                  _scale = val;
                  _preset = ControllerPreset.custom;
                });
                _haptic.triggerClick();
                _applyLocalChanges();
              },
            ),
            const SizedBox(height: 8),

            // Opacity Slider
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Transparansi Tombol', style: GoogleFonts.spaceGrotesk(color: Colors.white70, fontSize: 13)),
                Text('${(_opacity * 100).round()}%', style: GoogleFonts.spaceGrotesk(color: AppTheme.accentAmber, fontWeight: FontWeight.w700, fontSize: 13)),
              ],
            ),
            Slider(
              value: _opacity.clamp(0.20, 1.0),
              min: 0.20,
              max: 1.0,
              divisions: 16,
              activeColor: AppTheme.accentAmber,
              inactiveColor: AppTheme.chassisVoid,
              onChanged: (val) {
                setState(() {
                  _opacity = val;
                  _preset = ControllerPreset.custom;
                });
                _haptic.triggerClick();
                _applyLocalChanges();
              },
            ),
            const SizedBox(height: 12),

            // Action Angle Toggle
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: AppTheme.chassisCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.borderHard, width: 1.2),
                boxShadow: const [VemoShadows.tactileSmall],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Kemiringan Tombol Aksi',
                        style: GoogleFonts.spaceGrotesk(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600),
                      ),
                      Text(
                        'Miring (Diagonal) vs Datar (Horizontal)',
                        style: GoogleFonts.spaceGrotesk(color: Colors.white38, fontSize: 11),
                      ),
                    ],
                  ),
                  Switch(
                    value: _isTilted,
                    activeColor: AppTheme.accentAmber,
                    onChanged: (val) {
                      setState(() {
                        _isTilted = val;
                        _preset = ControllerPreset.custom;
                      });
                      _haptic.triggerClick();
                      _applyLocalChanges();
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Reset Button
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () async {
                  _haptic.triggerClick();
                  await _layout.resetSlotToDefault(_activeSlotIndex);
                  _syncWithCurrentSlot();
                },
                icon: const Icon(Icons.restart_alt_rounded, size: 18),
                label: const Text('Reset Slot Ini ke Pengaturan Awal'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.white70,
                  side: const BorderSide(color: AppTheme.borderHard),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  textStyle: GoogleFonts.spaceGrotesk(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSlotSelectorChip(int slotIndex, String label) {
    final isSelected = _activeSlotIndex == slotIndex;
    return Expanded(
      child: GestureDetector(
        onTap: () async {
          _haptic.triggerClick();
          await _layout.switchSlot(slotIndex);
          setState(() {
            _activeSlotIndex = slotIndex;
          });
          _syncWithCurrentSlot();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isSelected ? AppTheme.accentAmber : AppTheme.chassisCard,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isSelected ? AppTheme.accentAmber : AppTheme.borderHard,
              width: 1.2,
            ),
            boxShadow: const [VemoShadows.tactileSmall],
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: GoogleFonts.spaceGrotesk(
              color: isSelected ? AppTheme.chassisVoid : Colors.white70,
              fontSize: 10.5,
              fontWeight: isSelected ? FontWeight.w800 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPresetChip(String label, ControllerPreset preset) {
    final isSelected = _preset == preset;
    return Expanded(
      child: GestureDetector(
        onTap: () async {
          _haptic.triggerClick();
          await _layout.applyPreset(preset);
          setState(() {
            _scale = _layout.scale;
            _opacity = _layout.opacity;
            _isTilted = _layout.isActionTilted;
            _preset = preset;
          });
          widget.onLayoutChanged();
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          decoration: BoxDecoration(
            color: isSelected ? AppTheme.accentAmber.withValues(alpha: 0.2) : AppTheme.chassisCard,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isSelected ? AppTheme.accentAmber : AppTheme.borderHard,
              width: 1.2,
            ),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: GoogleFonts.spaceGrotesk(
              color: isSelected ? AppTheme.accentAmber : Colors.white70,
              fontSize: 10.5,
              fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}
