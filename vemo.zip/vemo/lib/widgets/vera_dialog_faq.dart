import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_theme.dart';
import '../services/audio_service.dart';

/// 🌲 Tree-Based Dialog Node Definition
class DialogNode {
  final String id;
  final String speech;
  final List<DialogOption> options;

  const DialogNode({
    required this.id,
    required this.speech,
    required this.options,
  });
}

class DialogOption {
  final String label;
  final String targetNodeId;
  final bool isSpecialEasterEgg;

  const DialogOption({
    required this.label,
    required this.targetNodeId,
    this.isSpecialEasterEgg = false,
  });
}

/// 🌳 Base Dialog Tree for Vemo Interactive FAQ
final Map<String, DialogNode> staticDialogTree = {
  // PILAR 1: GAME & CARA MAIN
  'menu_game': const DialogNode(
    id: 'menu_game',
    speech:
        'Vemo support ROM GBA, SNES, NES, SEGA Genesis, dan Arcade. Pasang game tinggal klik tombol "+ Tambah Game" di menu utama.',
    options: [
      DialogOption(
        label: 'Format file & tempat unduh ROM?',
        targetNodeId: 'game_format',
      ),
      DialogOption(
        label: 'File masih .zip perlu diekstrak?',
        targetNodeId: 'game_zip',
      ),
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'game_format': const DialogNode(
    id: 'game_format',
    speech:
        'Format support: .gba, .sfc, .nes, .md, .bin, dan .zip. Kamu bisa download ROM gratis di situs arsip seperti retrostic.com.',
    options: [
      DialogOption(
        label: 'File .zip perlu diekstrak manual?',
        targetNodeId: 'game_zip',
      ),
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'game_zip': const DialogNode(
    id: 'game_zip',
    speech:
        'Nggak perlu diekstrak. Engine Vemo punya decompressor internal yang otomatis buka file .zip secara instan saat game di-load.',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),

  // PILAR 2: KONTROL & LAYAR
  'menu_control': const DialogNode(
    id: 'menu_control',
    speech:
        'Posisi dan ukuran tombol kontroler bisa kamu ubah bebas. Tampilan layar juga bisa diubah ke mode CRT TV tabung.',
    options: [
      DialogOption(
        label: 'Cara ubah posisi & ukuran tombol?',
        targetNodeId: 'control_layout',
      ),
      DialogOption(
        label: 'Efek CRT Scanlines bikin lag?',
        targetNodeId: 'control_crt',
      ),
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'control_layout': const DialogNode(
    id: 'control_layout',
    speech:
        'Buka menu "Tata Letak Tombol". Kamu bisa drag tombol, resize skala, dan sesuaikan transparansi tombol on-screen.',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'control_crt': const DialogNode(
    id: 'control_crt',
    speech:
        'Tenang, shader Scanlines Vemo ultra-ringan dan di-render native lewat GPU tanpa bikin frame drop.',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),

  // PILAR 3: SIMPANAN & KENDALA
  'menu_trouble': const DialogNode(
    id: 'menu_trouble',
    speech:
        'Vemo jalan 100% offline tanpa login dan tanpa akun. Ada kendala pas main atau mau tanya cara simpan?',
    options: [
      DialogOption(
        label: 'Cara Save & Load game?',
        targetNodeId: 'trouble_save',
      ),
      DialogOption(
        label: 'Kenapa layar hitam / game nggak jalan?',
        targetNodeId: 'trouble_blackscreen',
      ),
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'trouble_save': const DialogNode(
    id: 'trouble_save',
    speech:
        'Pas main, klik tombol "SLOTS" di menu bawah. Pilih slot untuk Save State, atau klik Load untuk lanjut bermain.',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'trouble_blackscreen': const DialogNode(
    id: 'trouble_blackscreen',
    speech:
        'Cek format file ROM kamu. Kalau format sudah sesuai tapi tetap blank, besar kemungkinan file ROM tersebut corrupt saat diunduh.',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),

  // PILAR 4: RAHASIA KELANCARAN & ENGINE VE-NE
  'menu_performance': const DialogNode(
    id: 'menu_performance',
    speech:
        'Rahasia kelancaran Vemo ada di arsitektur mesin intinya. Vemo ditenagai oleh VE-NE (Vera Native Engine), bare-metal runtime C++ dengan vektor SIMD 128-bit dan AAudio hardware pipeline.',
    options: [
      DialogOption(
        label: 'Kenapa game bisa 60 FPS tanpa lag?',
        targetNodeId: 'performance_fps',
      ),
      DialogOption(
        label: 'Kenapa audio & tombol begitu instan?',
        targetNodeId: 'performance_audio',
      ),
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'performance_fps': const DialogNode(
    id: 'performance_fps',
    speech:
        'Engine VE-NE menembakkan piksel game langsung ke GPU lewat vektor ARM NEON SIMD dan Hybrid Frame Pacer. Rendering terkunci di 60 FPS murni, bebas micro-stutter, dan HP tetap dingin!',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
  'performance_audio': const DialogNode(
    id: 'performance_audio',
    speech:
        'VE-NE menghubungkan audio ke chip suara Android lewat AAudio burst tuning dan ring buffer lock-free. Latensi suara dipangkas di bawah 10ms tanpa suara kresek atau delay tombol!',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),

  // 秘密 RARE EASTER EGG: SIAPA ITU VERA CREATION? (HANYA 1 KALI PER SESI APLIKASI)
  'easter_egg_creator': const DialogNode(
    id: 'easter_egg_creator',
    speech:
        'Ssst... Vera Creation itu tim sahabat sekaligus arsitek di balik duniaku. Mereka yang ngajarin aku punya jiwa dan cinta di setiap pixel Vemo. Dibuat dengan cinta untuk semua pecinta game retro!',
    options: [
      DialogOption(
        label: '« Kembali ke Menu Utama',
        targetNodeId: 'root',
      ),
    ],
  ),
};

/// ⚡ High-Performance Pre-Tokenized Text Segment
class _TextSegment {
  final String text;
  final bool isKeyword;
  final int startIndex;
  final int endIndex;

  const _TextSegment({
    required this.text,
    required this.isKeyword,
    required this.startIndex,
    required this.endIndex,
  });
}

/// 👾 Tree-Based Interactive FAQ Component with Zero-GC & Low-Latency Sound Engine
class VeraInteractiveFaq extends StatefulWidget {
  const VeraInteractiveFaq({super.key});

  /// Session guard: Ensures the special Creator Easter Egg only triggers at most 1 time per app launch
  static bool hasTriggeredCreatorEasterEggThisSession = false;

  @override
  State<VeraInteractiveFaq> createState() => _VeraInteractiveFaqState();
}

class _VeraInteractiveFaqState extends State<VeraInteractiveFaq> {
  final Random _rnd = Random();

  String _currentSpeech = '';
  List<DialogOption> _currentOptions = [];
  List<_TextSegment> _cachedSegments = [];

  int _displayedCharCount = 0;
  int _mouthFrame = 0;
  int _lookOffset = 0;
  Timer? _typewriterTimer;

  final ValueNotifier<int> _charCountNotifier = ValueNotifier<int>(0);
  final ValueNotifier<int> _mouthFrameNotifier = ValueNotifier<int>(0);
  final ValueNotifier<int> _lookOffsetNotifier = ValueNotifier<int>(0);
  final ValueNotifier<bool> _isTalkingNotifier = ValueNotifier<bool>(false);

  int _lastOptionTapTimestamp = 0;
  bool _hasReturnedToRoot = false;

  // Cached static TextStyles to avoid allocations on every tick
  static final TextStyle _normalStyle = GoogleFonts.pressStart2p(
    fontSize: 8.5,
    color: Colors.white,
    height: 1.8,
    letterSpacing: 0.6,
  );

  static final TextStyle _highlightStyle = GoogleFonts.pressStart2p(
    fontSize: 8.5,
    color: const Color(0xFFFFAE33), // Warm golden amber
    fontWeight: FontWeight.bold,
    height: 1.8,
    letterSpacing: 0.6,
  );

  // Pre-compiled keyword regex pattern with length-descending sort and escaped tokens
  static final List<String> _rawKeywords = [
    'Vera Native Engine',
    'Vera Creation',
    'Tata Letak Tombol',
    'Hybrid Frame Pacer',
    '+ Tambah Game',
    'SEGA Genesis',
    'Save State',
    '100% offline',
    'retrostic.com',
    'ARM NEON',
    'Scanlines',
    'AAudio',
    '60 FPS',
    'Arcade',
    'Vera Creation',
    'VE-NE',
    'SLOTS',
    '.gba',
    '.sfc',
    '.nes',
    '.bin',
    '.zip',
    '.md',
    'Vemo',
    'Vera',
    'SNES',
    'GBA',
    'NES',
    'Save',
    'Load',
    'ROM',
    'GPU',
    'SIMD',
  ]..sort((a, b) => b.length.compareTo(a.length));

  static final RegExp _keywordRegex = RegExp(
    _rawKeywords.map((k) => RegExp.escape(k)).join('|'),
    caseSensitive: false,
  );

  @override
  void initState() {
    super.initState();
    _loadNode('root', isInitial: true);
  }

  /// Pre-computes text segments once per node load for instant 60fps rendering
  void _precomputeSegments(String fullText) {
    _cachedSegments = [];
    int cursor = 0;

    final matches = _keywordRegex.allMatches(fullText);
    for (final match in matches) {
      if (match.start < cursor) {
        continue;
      }
      if (match.start > cursor) {
        _cachedSegments.add(_TextSegment(
          text: fullText.substring(cursor, match.start),
          isKeyword: false,
          startIndex: cursor,
          endIndex: match.start,
        ));
      }

      _cachedSegments.add(_TextSegment(
        text: fullText.substring(match.start, match.end),
        isKeyword: true,
        startIndex: match.start,
        endIndex: match.end,
      ));

      cursor = match.end;
    }

    if (cursor < fullText.length) {
      _cachedSegments.add(_TextSegment(
        text: fullText.substring(cursor),
        isKeyword: false,
        startIndex: cursor,
        endIndex: fullText.length,
      ));
    }
  }

  void _loadNode(String nodeId, {bool isInitial = false}) {
    _typewriterTimer?.cancel();
    AudioService().stopVeraBlip();

    if (nodeId == 'easter_egg_creator') {
      VeraInteractiveFaq.hasTriggeredCreatorEasterEggThisSession = true;
    }

    if (nodeId == 'root') {
      if (isInitial) {
        _currentSpeech =
            'Halo! Aku Vera dari tim Vera Creation. Mau bahas bagian mana soal Vemo?';
        _currentOptions = [
          const DialogOption(
            label: '1. Game & Cara Main',
            targetNodeId: 'menu_game',
          ),
          const DialogOption(
            label: '2. Kontrol & Layar',
            targetNodeId: 'menu_control',
          ),
          const DialogOption(
            label: '3. Simpanan & Kendala',
            targetNodeId: 'menu_trouble',
          ),
          const DialogOption(
            label: '4. Rahasia Kecepatan (VE-NE)',
            targetNodeId: 'menu_performance',
          ),
        ];
      } else {
        final shouldTriggerRareEasterEgg =
            !VeraInteractiveFaq.hasTriggeredCreatorEasterEggThisSession &&
            (_rnd.nextInt(5) == 0);

        if (shouldTriggerRareEasterEgg) {
          VeraInteractiveFaq.hasTriggeredCreatorEasterEggThisSession = true;
          _currentSpeech =
              'Tadi tim Vera Creation sempat nitip catatan performa... eh, kamu udah balik ke menu utama? Mau bahas apa lagi?';
          _currentOptions = [
            const DialogOption(
              label: '1. Game & Cara Main',
              targetNodeId: 'menu_game',
            ),
            const DialogOption(
              label: '2. Kontrol & Layar',
              targetNodeId: 'menu_control',
            ),
            const DialogOption(
              label: '3. Simpanan & Kendala',
              targetNodeId: 'menu_trouble',
            ),
            const DialogOption(
              label: '4. Rahasia Kecepatan (VE-NE)',
              targetNodeId: 'menu_performance',
            ),
            const DialogOption(
              label: '5. Siapa itu Vera Creation?',
              targetNodeId: 'easter_egg_creator',
              isSpecialEasterEgg: true,
            ),
          ];
        } else {
          _currentSpeech = 'Ada lagi yang mau ditanyakan ke Vera?';
          _currentOptions = [
            const DialogOption(
              label: '1. Game & Cara Main',
              targetNodeId: 'menu_game',
            ),
            const DialogOption(
              label: '2. Kontrol & Layar',
              targetNodeId: 'menu_control',
            ),
            const DialogOption(
              label: '3. Simpanan & Kendala',
              targetNodeId: 'menu_trouble',
            ),
            const DialogOption(
              label: '4. Rahasia Kecepatan (VE-NE)',
              targetNodeId: 'menu_performance',
            ),
          ];
        }
      }
    } else {
      final node = staticDialogTree[nodeId]!;
      _currentSpeech = node.speech;
      _currentOptions = node.options;
    }

    _precomputeSegments(_currentSpeech);
    setState(() {}); // Rebuild static options list once per node navigation
    _startTypewriter(_currentSpeech);
  }

  void _startTypewriter(String fullText) {
    _typewriterTimer?.cancel();
    AudioService().stopVeraBlip();
    _displayedCharCount = 0;
    _charCountNotifier.value = 0;
    _mouthFrame = 0;
    _mouthFrameNotifier.value = 0;
    _lookOffset = 0;
    _lookOffsetNotifier.value = 0;
    _isTalkingNotifier.value = true;

    AudioService().duckLobbyBgm();

    // Stable 32ms cadence (~30 ticks/sec) for crisp typewriter without UI thread lag
    _typewriterTimer = Timer.periodic(const Duration(milliseconds: 32), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }

      if (_displayedCharCount < fullText.length) {
        final char = fullText[_displayedCharCount];
        _displayedCharCount++;
        _charCountNotifier.value = _displayedCharCount;

        // Sound blip on visible characters (with internal AudioService throttle)
        if (_displayedCharCount % 3 == 0 && char != ' ' && char != '\n') {
          AudioService().playVeraBlip();
          _mouthFrame = (_mouthFrame == 0) ? 2 : (_mouthFrame == 2 ? 1 : 0);
          _mouthFrameNotifier.value = _mouthFrame;
        }

        // Subtle eye darting
        if (_displayedCharCount % 36 == 0) {
          _lookOffset = _rnd.nextBool() ? (_rnd.nextBool() ? 1 : -1) : 0;
          _lookOffsetNotifier.value = _lookOffset;
        }
      } else {
        timer.cancel();
        AudioService().stopVeraBlip();
        _isTalkingNotifier.value = false;
        _mouthFrameNotifier.value = 0;
        _lookOffsetNotifier.value = 0;
        AudioService().unduckLobbyBgm();
      }
    });
  }

  void _selectOption(String targetNodeId) {
    final now = DateTime.now().millisecondsSinceEpoch;
    if (now - _lastOptionTapTimestamp < 120) return; // 120ms debounce
    _lastOptionTapTimestamp = now;

    _typewriterTimer?.cancel();
    AudioService().stopVeraBlip();

    if (_isTalkingNotifier.value) {
      // Fast forward on tap while talking
      _displayedCharCount = _currentSpeech.length;
      _charCountNotifier.value = _displayedCharCount;
      _isTalkingNotifier.value = false;
      _mouthFrameNotifier.value = 0;
      _lookOffsetNotifier.value = 0;
      AudioService().unduckLobbyBgm();
    }

    HapticFeedback.lightImpact();
    if (targetNodeId == 'root') {
      _hasReturnedToRoot = true;
    }
    _loadNode(targetNodeId, isInitial: !_hasReturnedToRoot && targetNodeId == 'root');
  }

  /// Instant Zero-GC Formatted Span Builder
  List<TextSpan> _buildFormattedSpans(int charCount) {
    if (charCount <= 0) return const [];

    final spans = <TextSpan>[];
    for (final seg in _cachedSegments) {
      if (charCount <= seg.startIndex) break;

      final visibleLength = (charCount - seg.startIndex).clamp(0, seg.text.length);
      spans.add(TextSpan(
        text: seg.text.substring(0, visibleLength),
        style: seg.isKeyword ? _highlightStyle : _normalStyle,
      ));

      if (charCount < seg.endIndex) break;
    }

    return spans;
  }

  @override
  void deactivate() {
    _typewriterTimer?.cancel();
    AudioService().stopVeraBlip();
    AudioService().unduckLobbyBgm();
    super.deactivate();
  }

  @override
  void dispose() {
    _typewriterTimer?.cancel();
    _charCountNotifier.dispose();
    _mouthFrameNotifier.dispose();
    _lookOffsetNotifier.dispose();
    _isTalkingNotifier.dispose();
    AudioService().stopVeraBlip();
    AudioService().unduckLobbyBgm();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF12151D),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFF232A3B), width: 1.5),
          boxShadow: const [VemoShadows.tactileCard],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header Badge
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1D2331),
                    borderRadius: BorderRadius.circular(5),
                    border: Border.all(color: const Color(0xFFE2B755).withValues(alpha: 0.3)),
                  ),
                  child: Text(
                    "VERA • DEV LOG & FAQ",
                    style: GoogleFonts.pressStart2p(
                      fontSize: 7.5,
                      fontWeight: FontWeight.bold,
                      color: const Color(0xFFE2B755),
                      letterSpacing: 0.8,
                    ),
                  ),
                ),
                ValueListenableBuilder<bool>(
                  valueListenable: _isTalkingNotifier,
                  builder: (_, isTalking, __) {
                    if (!isTalking) return const SizedBox.shrink();
                    return Text(
                      "[ SKIP ]",
                      style: GoogleFonts.pressStart2p(
                        fontSize: 7,
                        color: AppTheme.textMuted,
                      ),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Dialog Box (Pitch Black #000000 + Stable Layout Boundary)
            GestureDetector(
              onTap: () {
                if (_isTalkingNotifier.value) {
                  _typewriterTimer?.cancel();
                  AudioService().stopVeraBlip();
                  _displayedCharCount = _currentSpeech.length;
                  _charCountNotifier.value = _displayedCharCount;
                  _isTalkingNotifier.value = false;
                  _mouthFrameNotifier.value = 0;
                  _lookOffsetNotifier.value = 0;
                  AudioService().unduckLobbyBgm();
                } else {
                  AudioService().playVeraBlip();
                  _lookOffset = _lookOffset == 0 ? (_rnd.nextBool() ? 1 : -1) : 0;
                  _lookOffsetNotifier.value = _lookOffset;
                }
              },
              child: RepaintBoundary(
                child: Container(
                  constraints: const BoxConstraints(minHeight: 84),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF000000),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: const Color(0xFF323B52), width: 1.5),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      RepaintBoundary(
                        child: SizedBox(
                          width: 52,
                          height: 52,
                          child: ListenableBuilder(
                            listenable: Listenable.merge([_mouthFrameNotifier, _lookOffsetNotifier]),
                            builder: (_, __) {
                              return CustomPaint(
                                painter: _VeraSpritePainter(
                                  mouthFrame: _mouthFrameNotifier.value,
                                  lookOffset: _lookOffsetNotifier.value,
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: RepaintBoundary(
                          child: ValueListenableBuilder<int>(
                            valueListenable: _charCountNotifier,
                            builder: (_, charCount, __) {
                              return Text.rich(
                                TextSpan(
                                  children: _buildFormattedSpans(charCount),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 14),

            // Menu Pilihan Cabang (USSD Vertical Stack — isolated from typewriter ticks)
            RepaintBoundary(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: _currentOptions.map((opt) {
                  final isBack = opt.targetNodeId == 'root';
                  final isEasterEgg = opt.isSpecialEasterEgg;

                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Material(
                      color: isEasterEgg
                          ? const Color(0xFF2A2415)
                          : isBack
                              ? const Color(0xFF191D26)
                              : const Color(0xFF1C2230),
                      borderRadius: BorderRadius.circular(8),
                      child: InkWell(
                        onTap: () => _selectOption(opt.targetNodeId),
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: isEasterEgg
                                  ? const Color(0xFFE2B755)
                                  : isBack
                                      ? const Color(0xFF2E3545)
                                      : const Color(0xFF3B465E),
                              width: isEasterEgg ? 1.5 : 1,
                            ),
                          ),
                          child: Row(
                            children: [
                              Text(
                                isBack ? "« " : "> ",
                                style: GoogleFonts.pressStart2p(
                                  fontSize: 8.5,
                                  color: isEasterEgg
                                      ? const Color(0xFFFFD56B)
                                      : isBack
                                          ? const Color(0xFF8C96A8)
                                          : const Color(0xFFE2B755),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  opt.label,
                                  style: GoogleFonts.pressStart2p(
                                    fontSize: 8.5,
                                    height: 1.6,
                                    letterSpacing: 0.4,
                                    color: isEasterEgg
                                        ? const Color(0xFFFFD56B)
                                        : isBack
                                            ? const Color(0xFFAEB8C9)
                                            : Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 🎨 16-Bit Vera Sprite CustomPainter with 3 Discrete Mouth Frames & Look Offset
class _VeraSpritePainter extends CustomPainter {
  final int mouthFrame; // 0: Tutup V, 1: Half, 2: Buka U
  final int lookOffset; // -1: kiri, 0: tengah, 1: kanan

  _VeraSpritePainter({required this.mouthFrame, required this.lookOffset});

  static final Paint _white = Paint()..color = const Color(0xFFFFFFFF);
  static final Paint _silver = Paint()..color = const Color(0xFFD0D4DC);
  static final Paint _gray = Paint()..color = const Color(0xFF7B828E);

  @override
  void paint(Canvas canvas, Size size) {
    final double s = size.width / 128.0;

    void px(double x, double y, double w, double h, Paint p) {
      canvas.drawRect(Rect.fromLTWH(x * s, y * s, w * s, h * s), p);
    }

    final double shift = lookOffset * 3.0;

    // --- MATA KIRI ---
    px(34, 14, 16, 3, _white);
    px(28, 17, 6, 3, _white);
    px(50, 17, 6, 3, _white);
    px(25, 20, 3, 18, _white);
    px(56, 20, 3, 14, _white);
    px(28, 38, 6, 3, _white);
    px(50, 34, 6, 3, _white);
    px(34, 41, 16, 3, _white);

    px(36 + (shift * 0.5), 20, 12, 3, _silver);
    px(31 + (shift * 0.5), 23, 5, 3, _silver);
    px(48 + (shift * 0.5), 23, 5, 3, _silver);
    px(31 + (shift * 0.5), 26, 3, 9, _silver);
    px(50 + (shift * 0.5), 26, 3, 6, _silver);
    px(34 + (shift * 0.5), 35, 14, 3, _silver);

    px(37 + shift, 26, 10, 3, _gray);
    px(37 + shift, 29, 3, 4, _gray);
    px(44 + shift, 29, 3, 4, _gray);
    px(37 + shift, 32, 10, 3, _gray);

    // --- MATA KANAN ---
    px(78, 14, 16, 3, _white);
    px(72, 17, 6, 3, _white);
    px(94, 17, 6, 3, _white);
    px(69, 20, 3, 14, _white);
    px(100, 20, 3, 18, _white);
    px(72, 34, 6, 3, _white);
    px(94, 38, 6, 3, _white);
    px(78, 41, 16, 3, _white);

    px(80 + (shift * 0.5), 20, 12, 3, _silver);
    px(75 + (shift * 0.5), 23, 5, 3, _silver);
    px(92 + (shift * 0.5), 23, 5, 3, _silver);
    px(75 + (shift * 0.5), 26, 3, 6, _silver);
    px(94 + (shift * 0.5), 26, 3, 9, _silver);
    px(80 + (shift * 0.5), 35, 14, 3, _silver);

    px(81 + shift, 26, 10, 3, _gray);
    px(81 + shift, 29, 3, 4, _gray);
    px(88 + shift, 29, 3, 4, _gray);
    px(81 + shift, 32, 10, 3, _gray);

    // --- MULUT (3 STATE FRAME DISKRET) ---
    px(27, 50, 4, 2, _white);
    px(97, 50, 4, 2, _white);

    // Lengan Kiri Luar
    final lSteps = [
      [26.0, 52.0], [29.0, 58.0], [32.0, 64.0], [35.0, 70.0],
      [38.0, 76.0], [41.0, 82.0], [44.0, 88.0], [47.0, 94.0],
      [50.0, 100.0], [53.0, 106.0], [56.0, 112.0], [59.0, 118.0]
    ];
    for (var p in lSteps) {
      double x = mouthFrame == 2 ? (p[1] > 90 ? p[0] - 3 : p[0]) : p[0];
      px(x, p[1], 4, 6, _white);
    }

    // Lengan Kanan Luar
    final rSteps = [
      [98.0, 52.0], [95.0, 58.0], [92.0, 64.0], [89.0, 70.0],
      [86.0, 76.0], [83.0, 82.0], [80.0, 88.0], [77.0, 94.0],
      [74.0, 100.0], [71.0, 106.0], [68.0, 112.0], [65.0, 118.0]
    ];
    for (var p in rSteps) {
      double x = mouthFrame == 2 ? (p[1] > 90 ? p[0] + 3 : p[0]) : p[0];
      px(x, p[1], 4, 6, _white);
    }

    // Apex Bawah
    if (mouthFrame == 0) {
      // V Lancip Tertutup
      px(62, 122, 4, 3, _white);
      px(63, 124, 2, 2, _white);
    } else if (mouthFrame == 1) {
      // Half Open
      px(60, 121, 8, 4, _white);
    } else {
      // U Terbuka Penuh
      px(54, 120, 20, 4, _white);
      px(58, 124, 12, 2, _white);
    }

    // Bilah Tengah (Silver)
    if (mouthFrame < 2) {
      px(36, 53, 4, 2, _silver);
      px(88, 53, 4, 2, _silver);
      for (int i = 0; i < 9; i++) {
        px(35.0 + (i * 3.0), 55.0 + (i * 6.0), 4, 6, _silver);
        px(89.0 - (i * 3.0), 55.0 + (i * 6.0), 4, 6, _silver);
      }
    }

    // Bilah Dalam (Dark Gray)
    px(45, 56, 4, 2, _gray);
    px(79, 56, 4, 2, _gray);
    for (int i = 0; i < 6; i++) {
      px(44.0 + (i * 3.0), 58.0 + (i * 6.0), 4, 6, _gray);
      px(80.0 - (i * 3.0), 58.0 + (i * 6.0), 4, 6, _gray);
    }
  }

  @override
  bool shouldRepaint(covariant _VeraSpritePainter oldDelegate) {
    return oldDelegate.mouthFrame != mouthFrame ||
        oldDelegate.lookOffset != lookOffset;
  }
}
