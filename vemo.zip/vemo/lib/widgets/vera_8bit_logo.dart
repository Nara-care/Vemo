import 'package:flutter/material.dart';

class Vera8BitLogo extends StatelessWidget {
  final double size;
  const Vera8BitLogo({super.key, this.size = 120});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      color: Colors.black, // Latar solid 1:1
      padding: EdgeInsets.all(size * 0.15), // Jarak pandang / margin
      child: CustomPaint(
        painter: _VeraPixelPainter(),
      ),
    );
  }
}

class _VeraPixelPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final white = Paint()..color = const Color(0xFFFFFFFF);
    final lightGray = Paint()..color = const Color(0xFFD8D8D0);
    final midGray = Paint()..color = const Color(0xFF8A8A8A);

    final u = size.width / 16; // Satuan 1 block piksel (grid 16x16)

    void drawPx(num x, num y, Paint paint) {
      canvas.drawRect(Rect.fromLTWH(x.toDouble() * u, y.toDouble() * u, u, u), paint);
    }

    // --- Spiral Kiri ---
    drawPx(2, 1, white); drawPx(3, 0, white); drawPx(4, 0, white); drawPx(5, 1, white);
    drawPx(1, 2, white); drawPx(1, 3, white); drawPx(2, 4, white);
    drawPx(3, 2, lightGray); drawPx(4, 2, lightGray);
    drawPx(3, 3, midGray);

    // --- Spiral Kanan ---
    drawPx(10, 1, white); drawPx(11, 0, white); drawPx(12, 0, white); drawPx(13, 1, white);
    drawPx(14, 2, white); drawPx(14, 3, white); drawPx(13, 4, white);
    drawPx(11, 2, lightGray); drawPx(12, 2, lightGray);
    drawPx(12, 3, midGray);

    // --- Garis V Luar ---
    for (int i = 0; i <= 9; i++) {
      drawPx(2 + (i * 0.6), 5.0 + i, white);
      drawPx(13 - (i * 0.6), 5.0 + i, white);
    }

    // --- Garis V Dalam ---
    for (int i = 0; i <= 6; i++) {
      drawPx(4 + (i * 0.55), 5.0 + i, lightGray);
      drawPx(11 - (i * 0.55), 5.0 + i, lightGray);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
