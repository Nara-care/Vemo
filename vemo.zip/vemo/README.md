```text
 ██╗   ██╗███████╗███╗   ███╗ ██████╗ 
 ██║   ██║██╔════╝████╗ ████║██╔═══██╗
 ██║   ██║█████╗  ██╔████╔██║██║   ██║
 ╚██╗ ██╔╝██╔══╝  ██║╚██╔╝██║██║   ██║
  ╚████╔╝ ███████╗██║ ╚═╝ ██║╚██████╔╝
   ╚═══╝  ╚══════╝╚═╝     ╚═╝ ╚═════╝ 
   V E R A   E M U L A T O R   ( V E M O )
  [ Powered by VE-NE 3D/2D Hardware Engine ]
```

# 🎮 VEMO (Vera Retro Emulator)
*Vera Creation • Dibuat dengan cinta*

> **Engine Inti:** Ditenagai oleh **VE-NE (Vera Native Engine)** — Universal High-Performance Bare-Metal AV & 3D Hardware Accelerated Runtime.

VEMO adalah aplikasi konsol retro *all-in-one* mandiri untuk Android yang menggabungkan antarmuka modern **Flutter Hardware-Accelerated** dengan keperkasaan mesin native **VE-NE (C++17 / OpenGL ES 3.0 / AAudio / ARM NEON SIMD)** untuk menghasilkan pengalaman bermain **60 FPS murni bebas lag, audio tanpa jeda, dan grafis 3D resolusi tinggi**.

---

## ⚡ Keunggulan Arsitektur VE-NE di VEMO
- **128-Bit ARM NEON SIMD Vectorization**: Konversi warna frame game 8 piksel per siklus CPU ($7\times$ speedup) membuat rendering super ringan dan HP tetap dingin.
- **Ultra-Low-Latency AAudio Dynamic Pipeline**: Penyetelan ukuran buffer hardware $2\times\text{burst}$ memotong latensi suara hingga $< 10\text{ ms}$ tanpa distorsi / crackling.
- **Hybrid Deadline Frame Pacer**: Sinkronisasi ganda (Kernel coarse sleep + microspin assembly ARM64 `yield`) mengunci frame rate dengan presisi tinggi (jitter $< 0.05\text{ ms}$).
- **Zero-Copy Memory Mapping**: Alokasi instan file ROM menggunakan POSIX `mmap()` langsung ke virtual memory tanpa penggandaan beban RAM.

---

## 🕹️ Konsol yang Didukung
1. **Sony PlayStation 1 / PS1** (`libpcsx_rearmed.so` / `libduckstation.so` / `libbeetle_psx_hw.so`) — *3D Hardware Accelerated & Upscaling*
2. **Nintendo Entertainment System / NES & FDS** (`libfceumm.so`)
3. **Super Nintendo / SNES & Super Famicom** (`libsnes9x.so`)
4. **Game Boy Advance / GBA** (`libmgba.so`)
5. **Game Boy & Game Boy Color / GB & GBC** (`libmgba.so`)
6. **Sega Genesis / Mega Drive** (`libgenesis_plus_gx.so`)
7. **Sega Master System & Game Gear** (`libgenesis_plus_gx.so`)

### 🚀 Roadmap Konsol Mendatang
- **Nintendo 64 / N64** (`libmupen64plus_next.so`)
- **Sony PlayStation Portable / PSP** (`libppsspp.so`)
- **PC Engine / TurboGrafx-16** (`libbeetle_pce_fast.so`)
- **Arcade & Neo Geo** (`libfbneo.so`)

---

## ⚙️ Fitur Utama
- **Native 60 FPS Emulation Loop**: Menghubungkan core Libretro C++ langsung ke `SurfaceTexture` hardware Android tanpa overhead browser atau WebView.
- **Instant Save & Load States**: 3 Slot penyimpanan instan berbasis binary RAM snapshot langsung ke penyimpanan HP.
- **Adaptive Retro Chassis**: Mode Portrait (Chassis Game Boy) dan Mode Landscape (Glassmorphism Widescreen) dengan tombol responsif.
- **Offline & Standalone**: Bebas iklan, 100% offline, dan mendukung impor file ROM (.nes, .gba, .sfc, .md) dari penyimpanan HP.

---

## 📂 Struktur Proyek
```
vemo/
├── android/               # Native Android (Kotlin JNA Bridge & JNI Libs)
│   ├── app/src/main/cpp/  # vemo_native_engine.cpp (Powered by VE-NE Core)
│   └── app/src/main/jniLibs/arm64-v8a/  # Libretro Cores (C++ .so)
├── assets/                # Boxart, BGM audio, dan ROMs bawaan
├── docs/                  # Master Plan, QC Log & Spesifikasi Teknis VEMO
├── lib/
│   ├── data/              # Library game bawaan & metadata
│   ├── models/            # Model data Game & SaveSlot
│   ├── screens/           # LibraryScreen & EmulatorScreen
│   ├── services/          # NativeEmulatorService, AudioService, SaveService, RomService
│   ├── theme/             # Glassmorphism design system & Retro colors
│   └── widgets/           # GameCard, GameDetailDrawer, SettingsModal, VeraDialogFAQ
└── pubspec.yaml           # Konfigurasi dependensi Flutter
```

---

## 📄 Dokumentasi Teknis & Rencana Pengembangan
Lihat cetak biru lengkap di [docs/VEMO_4_MASTER_PLAN.md](docs/VEMO_4_MASTER_PLAN.md) dan audit log sinkronisasi di [docs/QC_AND_CLEANUP_LOG.md](docs/QC_AND_CLEANUP_LOG.md).
