import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:vemo/models/game.dart';
import 'package:vemo/services/bios_service.dart';
import 'package:vemo/services/rom_service.dart';

void main() {
  group('Game Model Platform & Aspect Ratio Tests', () {
    test('Game.fromRomFile parses SNES correctly', () {
      final game = Game.fromRomFile(
        id: 'snes_test',
        title: 'Super Mario World',
        filePath: '/storage/emulated/0/ROMs/Super Mario World.sfc',
        fileSizeBytes: 1024 * 512,
      );
      expect(game.platform, 'SNES');
      expect(game.core, 'snes9x');
      expect(game.aspectRatio, '4/3');
      expect(game.numericAspectRatio, closeTo(4 / 3, 0.001));
    });

    test('Game.fromRomFile parses NES correctly', () {
      final game = Game.fromRomFile(
        id: 'nes_test',
        title: 'Mega Man 2',
        filePath: '/storage/emulated/0/ROMs/Mega Man 2.nes',
        fileSizeBytes: 1024 * 256,
      );
      expect(game.platform, 'NES');
      expect(game.core, 'fceumm');
      expect(game.aspectRatio, '4/3');
    });

    test('Game.fromRomFile parses GBA correctly', () {
      final game = Game.fromRomFile(
        id: 'gba_test',
        title: 'Pokemon Emerald',
        filePath: '/storage/emulated/0/ROMs/Pokemon Emerald.gba',
        fileSizeBytes: 1024 * 1024 * 16,
      );
      expect(game.platform, 'GBA');
      expect(game.core, 'mgba');
      expect(game.aspectRatio, '3/2');
      expect(game.numericAspectRatio, closeTo(3 / 2, 0.001));
    });

    test('Game.fromRomFile parses Genesis / Mega Drive correctly', () {
      final game = Game.fromRomFile(
        id: 'gen_test',
        title: 'Sonic the Hedgehog',
        filePath: '/storage/emulated/0/ROMs/Sonic the Hedgehog.gen',
        fileSizeBytes: 1024 * 1024,
      );
      expect(game.platform, 'GENESIS');
      expect(game.core, 'genesis_plus_gx');
      expect(game.aspectRatio, '4/3');
    });

    test('Game.fromRomFile parses PS1 formats correctly and throws on unsupported formats', () {
      final ps1Game = Game.fromRomFile(
        id: 'ps1_test',
        title: 'Final Fantasy VII',
        filePath: '/storage/emulated/0/ROMs/Final Fantasy VII.cue',
        fileSizeBytes: 1024 * 1024 * 500,
      );
      expect(ps1Game.platform, 'PS1');
      expect(ps1Game.core, 'pcsx_rearmed');
      expect(ps1Game.aspectRatio, '4/3');

      expect(
        () => Game.fromRomFile(
          id: 'pce_test',
          title: 'Castlevania',
          filePath: '/storage/emulated/0/ROMs/Castlevania.pce',
          fileSizeBytes: 1024 * 512,
        ),
        throwsA(isA<UnsupportedRomException>()),
      );
    });
  });

  group('BIOS Service V1 Catalogue Tests', () {
    test('Known BIOS list contains verified GBA and Sega CD entries', () {
      expect(BiosService.knownBiosList.length, 2);
      expect(BiosService.knownBiosList.any((b) => b.console == 'GBA'), isTrue);
      expect(BiosService.knownBiosList.any((b) => b.console == 'GENESIS'), isTrue);
    });
  });

  group('ROM Validation & Header Magic Tests', () {
    test('RomService.validateRomHeader validates valid NES iNES magic bytes', () {
      final nesBytes = Uint8List.fromList([0x4E, 0x45, 0x53, 0x1A, 0x01, 0x01, 0x00, 0x00]);
      expect(RomService.validateRomHeader(nesBytes, 'nes'), isTrue);
      expect(RomService.validateRomHeader(Uint8List.fromList([0x00, 0x00, 0x00, 0x00]), 'nes'), isFalse);
    });

    test('RomService.validateRomHeader validates valid GBA magic byte at offset 0xB2', () {
      final gbaBytes = Uint8List(256);
      gbaBytes[0xB2] = 0x96;
      expect(RomService.validateRomHeader(gbaBytes, 'gba'), isTrue);
      gbaBytes[0xB2] = 0x00;
      expect(RomService.validateRomHeader(gbaBytes, 'gba'), isFalse);
    });

    test('RomService.validateRomHeader validates valid Sega Genesis magic bytes', () {
      final genesisBytes = Uint8List(512);
      // 'SEGA' at offset 0x100
      genesisBytes[0x100] = 0x53; // S
      genesisBytes[0x101] = 0x45; // E
      genesisBytes[0x102] = 0x47; // G
      genesisBytes[0x103] = 0x41; // A
      expect(RomService.validateRomHeader(genesisBytes, 'gen'), isTrue);
      expect(RomService.validateRomHeader(genesisBytes, 'md'), isTrue);
    });
  });
}
