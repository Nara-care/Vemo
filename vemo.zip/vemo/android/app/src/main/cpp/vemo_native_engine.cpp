/*
 * ============================================================================
 * VEMO NATIVE COMPATIBILITY ADAPTER — VE-NE CONSUMER
 * ============================================================================
 * Brand: Vera Creation • Dibuat dengan cinta
 * Role: First-Party Client / Consumer of Standalone VE-NE Native Engine
 * Architecture: Pure Thin JNI Adapter interacting ONLY via Public VE-NE C ABI
 * ============================================================================
 */

#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <string>
#include <mutex>
#include <atomic>
#include <chrono>

// ONLY Public VE-NE Headers (No Internal Headers!)
#include "vene/vene.h"
#include "vene/types.h"

#define LOG_TAG "VemoAdapter"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

struct VemoClientContext {
    std::mutex mutex;
    vene_engine_handle_t engine_handle = nullptr;

    std::string system_dir = "/data/data/com.veracreation.vemo/files";
    std::string save_dir = "/data/data/com.veracreation.vemo/files/saves";

    std::atomic<uint32_t> touch_buttons{0};
    std::atomic<uint32_t> physical_buttons{0};
    std::atomic<float> analog_lx{0.0f};
    std::atomic<float> analog_ly{0.0f};
    std::atomic<float> analog_rx{0.0f};
    std::atomic<float> analog_ry{0.0f};

    void EnsureEngine() {
        if (!engine_handle) {
            vene_config_t config{};
            config.target_fps = 60;
            config.audio_sample_rate = 44100;
            config.audio_channels = 2;
            config.pixel_format = VENE_PIXEL_FORMAT_RGBA8888;
            config.enable_headless_mode = false;

            vene_result_t res = ve_engine_create(&engine_handle, &config);
            if (res == VENE_SUCCESS && engine_handle) {
                ve_engine_set_directories(engine_handle, system_dir.c_str(), save_dir.c_str());
                LOGI("[VemoClient] VE-NE Engine created via Public C ABI (handle=%p).", engine_handle);
            } else {
                LOGE("[VemoClient] Failed to create VE-NE Engine instance (err=%d).", res);
            }
        }
    }

    void DispatchInput() {
        if (!engine_handle) return;
        vene_controller_state_t input{};
        input.buttons = touch_buttons.load(std::memory_order_relaxed) |
                        physical_buttons.load(std::memory_order_relaxed);
        input.lx = analog_lx.load(std::memory_order_relaxed);
        input.ly = analog_ly.load(std::memory_order_relaxed);
        input.rx = analog_rx.load(std::memory_order_relaxed);
        input.ry = analog_ry.load(std::memory_order_relaxed);
        input.timestamp_nanos = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()
        ).count();

        ve_engine_send_input(engine_handle, &input);
    }
};

static VemoClientContext g_client;

} // anonymous namespace

// ─── Pure JNI Forwarding Adapter to VE-NE C ABI ────────────────────────────

extern "C" {

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeInit(
    JNIEnv *env, jobject thiz,
    jstring system_dir_jstr,
    jstring save_dir_jstr
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);

    if (system_dir_jstr) {
        const char *sys_dir = env->GetStringUTFChars(system_dir_jstr, nullptr);
        g_client.system_dir = sys_dir;
        env->ReleaseStringUTFChars(system_dir_jstr, sys_dir);
    }
    if (save_dir_jstr) {
        const char *sv_dir = env->GetStringUTFChars(save_dir_jstr, nullptr);
        g_client.save_dir = sv_dir;
        env->ReleaseStringUTFChars(save_dir_jstr, sv_dir);
    }

    g_client.EnsureEngine();
    if (g_client.engine_handle) {
        ve_engine_set_directories(g_client.engine_handle, g_client.system_dir.c_str(), g_client.save_dir.c_str());
    }
    LOGI("[VemoClient] nativeInit: system=%s, save=%s", g_client.system_dir.c_str(), g_client.save_dir.c_str());
}

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeSetSurface(
    JNIEnv *env, jobject thiz,
    jobject surface
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    g_client.EnsureEngine();

    ANativeWindow* window = nullptr;
    if (surface) {
        window = ANativeWindow_fromSurface(env, surface);
    }
    if (g_client.engine_handle) {
        ve_engine_set_surface(g_client.engine_handle, window);
        LOGI("[VemoClient] nativeSetSurface attached window=%p via C ABI.", window);
    }
    if (window) {
        ANativeWindow_release(window);
    }
}

JNIEXPORT jboolean JNICALL
Java_com_veracreation_vemo_MainActivity_nativeLoadRom(
    JNIEnv *env, jobject thiz,
    jstring rom_path_jstr,
    jstring core_jstr,
    jstring native_lib_dir_jstr
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    g_client.EnsureEngine();
    if (!g_client.engine_handle) return JNI_FALSE;

    // 0. Stop previous session
    ve_session_stop(g_client.engine_handle);

    const char *rom_path = env->GetStringUTFChars(rom_path_jstr, nullptr);
    const char *core = env->GetStringUTFChars(core_jstr, nullptr);
    const char *native_lib_dir = native_lib_dir_jstr ? env->GetStringUTFChars(native_lib_dir_jstr, nullptr) : "";

    // 1. Resolve core library filename
    std::string clean_name = core;
    if (clean_name.rfind("lib", 0) == 0) clean_name = clean_name.substr(3);
    if (clean_name.length() >= 3 && clean_name.substr(clean_name.length() - 3) == ".so") {
        clean_name = clean_name.substr(0, clean_name.length() - 3);
    }
    std::string so_filename = "lib" + clean_name + ".so";
    std::string core_full_path = so_filename;
    if (native_lib_dir && strlen(native_lib_dir) > 0) {
        core_full_path = std::string(native_lib_dir) + "/" + so_filename;
    }

    LOGI("[VemoClient] Loading core via C ABI: %s", core_full_path.c_str());
    vene_result_t core_res = ve_session_load_core(g_client.engine_handle, core_full_path.c_str());
    if (core_res != VENE_SUCCESS) {
        core_res = ve_session_load_core(g_client.engine_handle, so_filename.c_str());
    }

    if (core_res != VENE_SUCCESS) {
        LOGE("[VemoClient] ve_session_load_core failed (err=%d)", core_res);
        env->ReleaseStringUTFChars(rom_path_jstr, rom_path);
        env->ReleaseStringUTFChars(core_jstr, core);
        if (native_lib_dir_jstr) env->ReleaseStringUTFChars(native_lib_dir_jstr, native_lib_dir);
        return JNI_FALSE;
    }

    // 2. Load Content ROM via C ABI
    LOGI("[VemoClient] Loading ROM via C ABI: %s", rom_path);
    vene_result_t content_res = ve_session_load_content(g_client.engine_handle, rom_path);

    env->ReleaseStringUTFChars(rom_path_jstr, rom_path);
    env->ReleaseStringUTFChars(core_jstr, core);
    if (native_lib_dir_jstr) env->ReleaseStringUTFChars(native_lib_dir_jstr, native_lib_dir);

    if (content_res != VENE_SUCCESS) {
        LOGE("[VemoClient] ve_session_load_content failed (err=%d)", content_res);
        ve_session_stop(g_client.engine_handle);
        return JNI_FALSE;
    }

    // 3. Start engine in PAUSED state (Kotlin unpauses after SRAM restore)
    ve_session_start(g_client.engine_handle);
    ve_session_pause(g_client.engine_handle);

    LOGI("[VemoClient] ROM loaded and session started in PAUSED state.");
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeSendKey(
    JNIEnv *env, jobject thiz,
    jint key_code,
    jboolean is_pressed
) {
    if (key_code < 0 || key_code >= 32) return;
    if (is_pressed) {
        g_client.touch_buttons.fetch_or(1 << key_code, std::memory_order_relaxed);
    } else {
        g_client.touch_buttons.fetch_and(~(1 << key_code), std::memory_order_relaxed);
    }
    g_client.DispatchInput();
}

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeSendControllerState(
    JNIEnv *env, jobject thiz,
    jint physical_buttons,
    jfloat lx, jfloat ly,
    jfloat rx, jfloat ry
) {
    g_client.physical_buttons.store(static_cast<uint32_t>(physical_buttons), std::memory_order_relaxed);
    g_client.analog_lx.store(lx, std::memory_order_relaxed);
    g_client.analog_ly.store(ly, std::memory_order_relaxed);
    g_client.analog_rx.store(rx, std::memory_order_relaxed);
    g_client.analog_ry.store(ry, std::memory_order_relaxed);
    g_client.DispatchInput();
}

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeSendAnalog(
    JNIEnv *env, jobject thiz,
    jint stick,
    jint axis,
    jfloat value
) {
    if (stick == 0) {
        if (axis == 0) g_client.analog_lx.store(value, std::memory_order_relaxed);
        else g_client.analog_ly.store(value, std::memory_order_relaxed);
    } else if (stick == 1) {
        if (axis == 0) g_client.analog_rx.store(value, std::memory_order_relaxed);
        else g_client.analog_ry.store(value, std::memory_order_relaxed);
    }
    g_client.DispatchInput();
}

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeSetPaused(
    JNIEnv *env, jobject thiz,
    jboolean is_paused
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    if (!g_client.engine_handle) return;

    if (is_paused) {
        ve_session_pause(g_client.engine_handle);
    } else {
        vene_session_state_t state = ve_engine_get_state(g_client.engine_handle);
        if (state == VENE_STATE_PAUSED) {
            ve_session_resume(g_client.engine_handle);
        } else if (state == VENE_STATE_READY || state == VENE_STATE_CORE_READY) {
            ve_session_start(g_client.engine_handle);
        }
    }
}

JNIEXPORT jboolean JNICALL
Java_com_veracreation_vemo_MainActivity_nativeSaveState(
    JNIEnv *env, jobject thiz,
    jstring path_jstr
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    if (!g_client.engine_handle || !path_jstr) return JNI_FALSE;

    const char *path = env->GetStringUTFChars(path_jstr, nullptr);
    vene_result_t res = ve_session_save_state(g_client.engine_handle, path);
    env->ReleaseStringUTFChars(path_jstr, path);

    return (res == VENE_SUCCESS) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_veracreation_vemo_MainActivity_nativeLoadState(
    JNIEnv *env, jobject thiz,
    jstring path_jstr
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    if (!g_client.engine_handle || !path_jstr) return JNI_FALSE;

    const char *path = env->GetStringUTFChars(path_jstr, nullptr);
    vene_result_t res = ve_session_load_state(g_client.engine_handle, path);
    env->ReleaseStringUTFChars(path_jstr, path);

    return (res == VENE_SUCCESS) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_veracreation_vemo_MainActivity_nativeSaveSRAM(
    JNIEnv *env, jobject thiz,
    jstring path_jstr
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    if (!g_client.engine_handle || !path_jstr) return JNI_FALSE;

    const char *path = env->GetStringUTFChars(path_jstr, nullptr);
    vene_result_t res = ve_session_save_sram(g_client.engine_handle, path);
    env->ReleaseStringUTFChars(path_jstr, path);

    return (res == VENE_SUCCESS) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_veracreation_vemo_MainActivity_nativeLoadSRAM(
    JNIEnv *env, jobject thiz,
    jstring path_jstr
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    if (!g_client.engine_handle || !path_jstr) return JNI_FALSE;

    const char *path = env->GetStringUTFChars(path_jstr, nullptr);
    vene_result_t res = ve_session_load_sram(g_client.engine_handle, path);
    env->ReleaseStringUTFChars(path_jstr, path);

    return (res == VENE_SUCCESS) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeReset(
    JNIEnv *env, jobject thiz
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    if (g_client.engine_handle) {
        ve_session_reset(g_client.engine_handle);
    }
}

JNIEXPORT void JNICALL
Java_com_veracreation_vemo_MainActivity_nativeStop(
    JNIEnv *env, jobject thiz
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    if (g_client.engine_handle) {
        ve_session_stop(g_client.engine_handle);
        ve_engine_destroy(g_client.engine_handle);
        g_client.engine_handle = nullptr;
        LOGI("[VemoClient] VE-NE Engine stopped & destroyed via C ABI.");
    }
}

JNIEXPORT jboolean JNICALL
Java_com_veracreation_vemo_MainActivity_nativeConfigureEngine(
    JNIEnv *env, jobject thiz,
    jboolean enable_hw,
    jint resolution_scale,
    jint graphics_api,
    jboolean enable_vrr
) {
    std::lock_guard<std::mutex> lock(g_client.mutex);
    g_client.EnsureEngine();
    if (!g_client.engine_handle) return JNI_FALSE;

    VeneEngineConfig config{};
    config.enable_hw_acceleration = enable_hw;
    config.internal_resolution_scale = resolution_scale;
    config.graphics_api = graphics_api;
    config.enable_vrr_pacing = enable_vrr;

    vene_result_t res = vene_engine_configure(g_client.engine_handle, &config);
    LOGI("[VemoClient] nativeConfigureEngine: hw=%d, scale=%dx, api=%d, vrr=%d -> res=%d",
         enable_hw, resolution_scale, graphics_api, enable_vrr, res);
    return (res == VENE_SUCCESS) ? JNI_TRUE : JNI_FALSE;
}

} // extern "C"

