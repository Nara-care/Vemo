package com.veracreation.vemo

import android.util.Log
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.view.TextureRegistry
import java.io.File
import kotlin.math.abs

class MainActivity : FlutterActivity() {
    private val TAG = "VemoNative"
    private val CHANNEL = "com.veracreation.vemo/emulator"

    private var textureEntry: TextureRegistry.SurfaceTextureEntry? = null
    private var surface: Surface? = null
    private var currentRomPath: String? = null
    private var currentSrmPath: String? = null

    companion object {
        init {
            try {
                System.loadLibrary("vemo_native_engine")
                Log.i("VemoNative", "Successfully loaded libvemo_native_engine.so")
            } catch (e: UnsatisfiedLinkError) {
                Log.e("VemoNative", "Failed to load libvemo_native_engine.so: ${e.message}")
            }
        }

        // Libretro Joypad Button IDs
        private const val RETRO_B = 0
        private const val RETRO_Y = 1
        private const val RETRO_SELECT = 2
        private const val RETRO_START = 3
        private const val RETRO_UP = 4
        private const val RETRO_DOWN = 5
        private const val RETRO_LEFT = 6
        private const val RETRO_RIGHT = 7
        private const val RETRO_A = 8
        private const val RETRO_X = 9
        private const val RETRO_L = 10
        private const val RETRO_R = 11
        private const val RETRO_L2 = 12
        private const val RETRO_R2 = 13
        private const val RETRO_L3 = 14
        private const val RETRO_R3 = 15
    }

    // ─── Native C++ Engine JNI Interface ──────────────────────────────────────
    private external fun nativeInit(systemDir: String, saveDir: String)
    private external fun nativeSetSurface(surface: Surface?)
    private external fun nativeLoadRom(romPath: String, coreName: String, nativeLibDir: String): Boolean
    private external fun nativeSendKey(keyCode: Int, isPressed: Boolean)
    private external fun nativeSendAnalog(stick: Int, axis: Int, value: Float)
    private external fun nativeSendControllerState(buttons: Int, lx: Float, ly: Float, rx: Float, ry: Float)
    private external fun nativeSetPaused(isPaused: Boolean)
    private external fun nativeSaveState(path: String): Boolean
    private external fun nativeLoadState(path: String): Boolean
    private external fun nativeSaveSRAM(path: String): Boolean
    private external fun nativeLoadSRAM(path: String): Boolean
    private external fun nativeReset()
    private external fun nativeStop()
    private external fun nativeConfigureEngine(enableHw: Boolean, resolutionScale: Int, graphicsApi: Int, enableVrr: Boolean): Boolean

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        // Initialize Native engine with system and saves paths
        val filesDir = applicationContext.filesDir.absolutePath
        val savesDir = File(filesDir, "saves").apply { mkdirs() }.absolutePath
        try {
            nativeInit(filesDir, savesDir)
        } catch (e: Throwable) {
            Log.e(TAG, "nativeInit error", e)
        }

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "createTexture" -> {
                    try {
                        releaseSurfaceTexture()

                        val entry = flutterEngine.renderer.createSurfaceTexture()
                        textureEntry = entry
                        val surfaceTexture = entry.surfaceTexture()
                        
                        val width = call.argument<Int>("width") ?: 256
                        val height = call.argument<Int>("height") ?: 224
                        surfaceTexture.setDefaultBufferSize(width, height)

                        val newSurface = Surface(surfaceTexture)
                        surface = newSurface
                        nativeSetSurface(newSurface)

                        Log.i(TAG, "SurfaceTexture created with TextureID: ${entry.id()} (${width}x${height})")
                        result.success(entry.id())
                    } catch (e: Throwable) {
                        Log.e(TAG, "Failed to create SurfaceTexture", e)
                        result.error("TEXTURE_ERROR", e.message, null)
                    }
                }

                "loadRom" -> {
                    val romPath = call.argument<String>("romPath")
                    val core = call.argument<String>("core")
                    val gameId = call.argument<String>("gameId")

                    if (romPath == null || core == null) {
                        result.error("INVALID_ARGS", "romPath and core must not be null", null)
                        return@setMethodCallHandler
                    }

                    // Determine SRM path for Battery Save (prefer gameId, fallback to rom name)
                    val romFile = File(romPath)
                    val srmFileName = if (!gameId.isNullOrEmpty()) {
                        "${gameId}.srm"
                    } else {
                        "${romFile.nameWithoutExtension}.srm"
                    }
                    val srmFile = File(savesDir, srmFileName)

                    val nativeLibDir = applicationInfo.nativeLibraryDir
                    val success = try {
                        val loaded = nativeLoadRom(romPath, core, nativeLibDir)
                        if (loaded) {
                            currentRomPath = romPath
                            currentSrmPath = srmFile.absolutePath
                            if (srmFile.exists()) {
                                nativeLoadSRAM(srmFile.absolutePath)
                            }
                            // Emulation thread was spawned in paused state; unpause now that SRAM is ready.
                            nativeSetPaused(false)
                        } else {
                            currentRomPath = null
                            currentSrmPath = null
                        }
                        loaded
                    } catch (e: Throwable) {
                        Log.e(TAG, "Error in nativeLoadRom", e)
                        currentRomPath = null
                        currentSrmPath = null
                        false
                    }

                    Log.i(TAG, "nativeLoadRom result: $success for core: $core (SRAM: $srmFileName)")
                    result.success(success)
                }

                "sendKey" -> {
                    val keyCode = call.argument<Int>("keyCode") ?: 0
                    val isPressed = call.argument<Boolean>("isPressed") ?: false
                    nativeSendKey(keyCode, isPressed)
                    result.success(true)
                }

                "sendAnalog" -> {
                    val stick = call.argument<Int>("stick") ?: 0 // 0=Left, 1=Right
                    val axis = call.argument<Int>("axis") ?: 0   // 0=X, 1=Y
                    val value = (call.argument<Double>("value") ?: 0.0).toFloat()
                    nativeSendAnalog(stick, axis, value)
                    result.success(true)
                }

                "saveState" -> {
                    val path = call.argument<String>("path")
                    if (path != null) {
                        val ok = nativeSaveState(path)
                        result.success(ok)
                    } else {
                        result.success(false)
                    }
                }

                "loadState" -> {
                    val path = call.argument<String>("path")
                    if (path != null) {
                        val ok = nativeLoadState(path)
                        result.success(ok)
                    } else {
                        result.success(false)
                    }
                }

                "saveSram" -> {
                    val path = call.argument<String>("path") ?: currentSrmPath
                    if (path != null && currentRomPath != null) {
                        val ok = nativeSaveSRAM(path)
                        result.success(ok)
                    } else {
                        result.success(false)
                    }
                }

                "loadSram" -> {
                    val path = call.argument<String>("path") ?: currentSrmPath
                    if (path != null) {
                        val ok = nativeLoadSRAM(path)
                        result.success(ok)
                    } else {
                        result.success(false)
                    }
                }

                "reset" -> {
                    try {
                        nativeReset()
                        Log.i(TAG, "Emulation reset via JNI")
                        result.success(true)
                    } catch (e: Throwable) {
                        Log.e(TAG, "Error resetting emulation", e)
                        result.success(false)
                    }
                }

                "setVideoFilter" -> {
                    // Video filter mode handled gracefully in hardware texture & Flutter shader
                    result.success(true)
                }

                "configureEngine" -> {
                    val enableHw = call.argument<Boolean>("enableHw") ?: true
                    val resolutionScale = call.argument<Int>("resolutionScale") ?: 1
                    val graphicsApi = call.argument<Int>("graphicsApi") ?: 0
                    val vrr = call.argument<Boolean>("enableVrr") ?: true
                    try {
                        val ok = nativeConfigureEngine(enableHw, resolutionScale, graphicsApi, vrr)
                        Log.i(TAG, "Engine 3D/HW configured: hw=$enableHw, scale=${resolutionScale}x, api=$graphicsApi -> ok=$ok")
                        result.success(ok)
                    } catch (e: Throwable) {
                        Log.e(TAG, "Error configuring 3D HW engine", e)
                        result.success(false)
                    }
                }

                "pause" -> {
                    currentSrmPath?.let { srmPath ->
                        if (currentRomPath != null) {
                            nativeSaveSRAM(srmPath)
                        }
                    }
                    nativeSetPaused(true)
                    Log.i(TAG, "Emulation paused & SRAM auto-flushed via JNI")
                    result.success(true)
                }

                "resume" -> {
                    nativeSetPaused(false)
                    Log.i(TAG, "Emulation resumed via JNI")
                    result.success(true)
                }

                "stop" -> {
                    stopEmulation()
                    result.success(true)
                }

                else -> result.notImplemented()
            }
        }
    }

    private fun stopEmulation() {
        try {
            currentSrmPath?.let { srmPath ->
                if (currentRomPath != null) {
                    nativeSaveSRAM(srmPath)
                }
            }
            nativeStop()
        } catch (e: Throwable) {
            Log.e(TAG, "Error stopping emulation", e)
        }
        releaseSurfaceTexture()
        currentRomPath = null
        currentSrmPath = null
    }

    private fun releaseSurfaceTexture() {
        nativeSetSurface(null)
        surface?.release()
        surface = null
        textureEntry?.release()
        textureEntry = null
    }

    // ─── Physical Gamepad & Bluetooth Controller Input Handling ──────────────
    private var lastPhysicalButtons = 0
    private var lastKeyPhysicalButtons = 0
    private var lastHatButtons = 0
    private var lastLx = 0f
    private var lastLy = 0f
    private var lastRx = 0f
    private var lastRy = 0f

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val isGamepad = (event.source and InputDevice.SOURCE_GAMEPAD == InputDevice.SOURCE_GAMEPAD) ||
                        (event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK)

        if (isGamepad && currentRomPath != null) {
            val isPressed = event.action == KeyEvent.ACTION_DOWN
            val retroKey = when (event.keyCode) {
                KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER -> RETRO_A
                KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BACK -> RETRO_B
                KeyEvent.KEYCODE_BUTTON_X -> RETRO_X
                KeyEvent.KEYCODE_BUTTON_Y -> RETRO_Y
                KeyEvent.KEYCODE_BUTTON_L1 -> RETRO_L
                KeyEvent.KEYCODE_BUTTON_R1 -> RETRO_R
                KeyEvent.KEYCODE_BUTTON_L2 -> RETRO_L2
                KeyEvent.KEYCODE_BUTTON_R2 -> RETRO_R2
                KeyEvent.KEYCODE_BUTTON_THUMBL -> RETRO_L3
                KeyEvent.KEYCODE_BUTTON_THUMBR -> RETRO_R3
                KeyEvent.KEYCODE_BUTTON_START -> RETRO_START
                KeyEvent.KEYCODE_BUTTON_SELECT -> RETRO_SELECT
                KeyEvent.KEYCODE_DPAD_UP -> RETRO_UP
                KeyEvent.KEYCODE_DPAD_DOWN -> RETRO_DOWN
                KeyEvent.KEYCODE_DPAD_LEFT -> RETRO_LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT -> RETRO_RIGHT
                else -> null
            }
            if (retroKey != null) {
                if (isPressed) {
                    lastKeyPhysicalButtons = lastKeyPhysicalButtons or (1 shl retroKey)
                } else {
                    lastKeyPhysicalButtons = lastKeyPhysicalButtons and (1 shl retroKey).inv()
                }
                val totalButtons = lastKeyPhysicalButtons or lastHatButtons
                if (totalButtons != lastPhysicalButtons) {
                    lastPhysicalButtons = totalButtons
                    nativeSendControllerState(totalButtons, lastLx, lastLy, lastRx, lastRy)
                }
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun applyDeadzone(value: Float, deadzone: Float = 0.15f): Float {
        val absVal = abs(value)
        if (absVal < deadzone) return 0f
        val normalized = (absVal - deadzone) / (1f - deadzone)
        return if (value < 0f) -normalized else normalized
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if ((event.source and InputDevice.SOURCE_JOYSTICK == InputDevice.SOURCE_JOYSTICK) && currentRomPath != null) {
            if (event.action == MotionEvent.ACTION_MOVE) {
                // Left Stick with Deadzone Normalization
                val lx = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_X))
                val ly = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Y))

                // Right Stick with Deadzone Normalization (Z & RZ)
                val rx = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Z))
                val ry = applyDeadzone(event.getAxisValue(MotionEvent.AXIS_RZ))

                // D-Pad Hat switches
                val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
                val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
                var hatButtons = 0
                if (hatX < -0.5f) hatButtons = hatButtons or (1 shl RETRO_LEFT)
                if (hatX > 0.5f) hatButtons = hatButtons or (1 shl RETRO_RIGHT)
                if (hatY < -0.5f) hatButtons = hatButtons or (1 shl RETRO_UP)
                if (hatY > 0.5f) hatButtons = hatButtons or (1 shl RETRO_DOWN)

                lastHatButtons = hatButtons
                val totalButtons = lastKeyPhysicalButtons or hatButtons

                // Epsilon change filter (0.005f) to prevent micro-noise JNI flooding
                val EPSILON = 0.005f
                val analogChanged = abs(lx - lastLx) > EPSILON || abs(ly - lastLy) > EPSILON ||
                                    abs(rx - lastRx) > EPSILON || abs(ry - lastRy) > EPSILON
                val buttonsChanged = totalButtons != lastPhysicalButtons

                if (analogChanged || buttonsChanged) {
                    lastLx = lx
                    lastLy = ly
                    lastRx = rx
                    lastRy = ry
                    lastPhysicalButtons = totalButtons
                    nativeSendControllerState(totalButtons, lx, ly, rx, ry)
                }

                return true
            }
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun onDestroy() {
        stopEmulation()
        super.onDestroy()
    }
}
