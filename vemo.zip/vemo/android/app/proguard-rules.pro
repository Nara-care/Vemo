# Flutter-specific ProGuard rules for Vemo
# ─────────────────────────────────────────

# Keep Flutter embedding classes
-keep class io.flutter.** { *; }
-keep class io.flutter.embedding.** { *; }
-keep class io.flutter.plugin.** { *; }

# flutter_inappwebview — keep native bridge classes
-keep class com.pichillilorenzo.flutter_inappwebview.** { *; }
-keep class com.pichillilorenzo.flutter_inappwebview.types.** { *; }
-keepclassmembers class com.pichillilorenzo.flutter_inappwebview.** {
    @android.webkit.JavascriptInterface <methods>;
}

# shared_preferences — keep data classes
-keep class io.flutter.plugins.sharedpreferences.** { *; }

# path_provider — keep data classes
-keep class io.flutter.plugins.pathprovider.** { *; }

# google_fonts — keep font loader
-keep class io.flutter.plugins.googlemobileads.** { *; }

# Keep all annotations
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes Exceptions

# Don't warn about Kotlin reflection (not used)
-dontwarn kotlin.reflect.**
-dontwarn kotlin.jvm.**

# Suppress missing Play Core deferred component classes in Flutter engine
-dontwarn com.google.android.play.core.**
-ignorewarnings

# WebView bridge — prevent stripping of @JavascriptInterface methods
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
